import re

with open('App.jsx', 'r', encoding='utf-8') as f:
    content = f.read()

# Fix TourPointer scroll condition
content = content.replace("if (step.arrow === 'down' && step.title && step.title.includes('STEP')) {",
"if (step.arrow === 'up' && step.title && step.title.includes('STEP') && (step.title.includes(' 3:') || step.title.includes('10:') || step.title.includes('16:') || step.title.includes('20:'))) {")

# Fix arrows pointing wrong way
content = content.replace("id: 'astro-div1',\n        title: 'STEP 3: 01. SGP4 / SDP4 Propagator',\n        desc: 'Let\\'s explore Division 1. Click on the highlighted \"01. SGP4 / SDP4\" division button.',\n        arrow: 'down',\n        position: { top: 320, left: 'calc(50% - 250px)' }", 
"id: 'astro-div1',\n        title: 'STEP 3: 01. SGP4 / SDP4 Propagator',\n        desc: 'Let\\'s explore Division 1. Click on the highlighted \"01. SGP4 / SDP4\" division button.',\n        arrow: 'up',\n        position: { top: 180, left: 'calc(50% - 250px)' }")

content = content.replace("id: 'astro-div2',\n        title: 'STEP 10: 02. Foster\\'s Collision Probability',\n        desc: 'Now let\\'s evaluate collision risk! Click on the highlighted \"02. Foster\\'s Pc\" division button at the top. (Scroll up if needed)',\n        arrow: 'down',\n        position: { top: 320, left: 'calc(50% - 100px)' }",
"id: 'astro-div2',\n        title: 'STEP 10: 02. Foster\\'s Collision Probability',\n        desc: 'Now let\\'s evaluate collision risk! Click on the highlighted \"02. Foster\\'s Pc\" division button at the top. (Scroll up if needed)',\n        arrow: 'up',\n        position: { top: 180, left: 'calc(50% - 100px)' }")

content = content.replace("id: 'astro-div3',\n        title: 'STEP 16: 03. Delta-V Optimizer',\n        desc: 'Next, let\\'s plan avoidance maneuvers. Click on the highlighted \"03. Delta-V Optimizer\" division button at the top.',\n        arrow: 'down',\n        position: { top: 320, left: 'calc(50% + 50px)' }",
"id: 'astro-div3',\n        title: 'STEP 16: 03. Delta-V Optimizer',\n        desc: 'Next, let\\'s plan avoidance maneuvers. Click on the highlighted \"03. Delta-V Optimizer\" division button at the top.',\n        arrow: 'up',\n        position: { top: 180, left: 'calc(50% + 50px)' }")

content = content.replace("id: 'astro-div4',\n        title: 'STEP 20: 04. Orbital Decay Predictor',\n        desc: 'Finally, let\\'s predict atmospheric reentry. Click on the highlighted \"04. Reentry Predictor\" division button at the top.',\n        arrow: 'down',\n        position: { top: 320, left: 'calc(50% + 200px)' }",
"id: 'astro-div4',\n        title: 'STEP 20: 04. Orbital Decay Predictor',\n        desc: 'Finally, let\\'s predict atmospheric reentry. Click on the highlighted \"04. Reentry Predictor\" division button at the top.',\n        arrow: 'up',\n        position: { top: 180, left: 'calc(50% + 200px)' }")


# ALSO FIX INDIVIDUAL TOURS (they also had arrow down and top 320 for the division click step)
# For Delta-V
content = content.replace("id: 'deltav-div3',\n        title: 'STEP 2: Delta-V Optimizer',\n        desc: 'Click on the highlighted \"03. Delta-V Optimizer\" division button to explore Maneuver Planning.',\n        arrow: 'down',\n        position: { top: 320, left: 'calc(50% + 50px)' }",
"id: 'deltav-div3',\n        title: 'STEP 2: Delta-V Optimizer',\n        desc: 'Click on the highlighted \"03. Delta-V Optimizer\" division button to explore Maneuver Planning.',\n        arrow: 'up',\n        position: { top: 180, left: 'calc(50% + 50px)' }")

# For Reentry
content = content.replace("id: 'reentry-div4',\n        title: 'STEP 2: Orbital Decay Predictor',\n        desc: 'Click on the highlighted \"04. Reentry Predictor\" division button to explore decay rates.',\n        arrow: 'down',\n        position: { top: 320, left: 'calc(50% + 200px)' }",
"id: 'reentry-div4',\n        title: 'STEP 2: Orbital Decay Predictor',\n        desc: 'Click on the highlighted \"04. Reentry Predictor\" division button to explore decay rates.',\n        arrow: 'up',\n        position: { top: 180, left: 'calc(50% + 200px)' }")

# For SGP4
content = content.replace("id: 'astro-div1',\n        title: 'STEP 3: 01. SGP4 / SDP4 Propagator',\n        desc: 'Click on the highlighted \"01. SGP4 / SDP4\" division button at the top.',\n        arrow: 'down',\n        position: { top: 320, left: 'calc(50% - 250px)' }",
"id: 'astro-div1',\n        title: 'STEP 3: 01. SGP4 / SDP4 Propagator',\n        desc: 'Click on the highlighted \"01. SGP4 / SDP4\" division button at the top.',\n        arrow: 'up',\n        position: { top: 180, left: 'calc(50% - 250px)' }")


with open('App.jsx', 'w', encoding='utf-8') as f:
    f.write(content)
