import './RiskBadge.css'

const CFG = {
  GREEN:  { label:'Nominal',  cls:'rb-green'  },
  YELLOW: { label:'Caution',  cls:'rb-yellow' },
  RED:    { label:'Critical', cls:'rb-red'    },
}

export default function RiskBadge({ level }) {
  const c = CFG[level] || CFG.GREEN
  return (
    <span className={`rb ${c.cls}`}>
      <span className="rb-dot" />
      {c.label}
    </span>
  )
}
