import { useState, useEffect } from 'react'
import './TopBar.css'

export default function TopBar({ status, onSimulate, simRunning, alertEvent }) {
  const [time, setTime] = useState('')

  useEffect(() => {
    const tick = () => {
      const now = new Date()
      setTime(
        now.toLocaleTimeString('en-US', {
          hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'UTC'
        }) + ' UTC'
      )
    }
    tick()
    const id = setInterval(tick, 1000)
    return () => clearInterval(id)
  }, [])

  const hasAlert = alertEvent?.riskLevel === 'RED'

  return (
    <header className={`topbar ${hasAlert ? 'topbar--alert' : ''}`}>
      {/* Left — brand */}
      <div className="topbar-brand">
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" className="brand-icon">
          <circle cx="10" cy="10" r="2.5" fill="currentColor" />
          <ellipse cx="10" cy="10" rx="9" ry="4" stroke="currentColor" strokeWidth="1" fill="none" opacity="0.5" />
          <ellipse cx="10" cy="10" rx="4" ry="9" stroke="currentColor" strokeWidth="1" fill="none" opacity="0.35" />
          <circle cx="10" cy="1.3" r="1.5" fill="var(--blue)" />
          <circle cx="18.7" cy="10" r="1.5" fill="var(--green)" />
        </svg>
        <span className="brand-name">
          <span style={{ color: 'var(--green)' }}>SENTINEL</span>
          <span className="brand-sep">×</span>
          <span style={{ color: 'var(--blue)' }}>NEXUS</span>
        </span>
        <span className="brand-sub">Autonomous Space Defense</span>
      </div>

      {/* Center — stats */}
      <div className="topbar-stats">
        <div className="tstat">
          <span className="tstat-val mono">{status.objectsTracked.toLocaleString()}</span>
          <span className="tstat-label">Objects Tracked</span>
        </div>
        <div className="tstat-divider" />
        <div className="tstat">
          <span className="tstat-val mono">{status.activeConjunctions}</span>
          <span className="tstat-label">Conjunctions</span>
        </div>
        <div className="tstat-divider" />
        <div className="tstat">
          <span className="tstat-val mono" style={{ color: 'var(--green)' }}>{status.sentinelUptime}</span>
          <span className="tstat-label">Uptime</span>
        </div>
        <div className="tstat-divider" />
        <div className="tstat">
          <span className="tstat-val mono" style={{ color: 'var(--blue)' }}>{status.agentsOnline}</span>
          <span className="tstat-label">NEXUS Agents</span>
        </div>
      </div>

      {/* Right — clock + action */}
      <div className="topbar-right">
        <div className="topbar-live">
          <span className="dot dot--red" style={{ width: '5px', height: '5px' }} />
          <span className="mono" style={{ fontSize: '11px', color: 'var(--text-2)', letterSpacing: '0.04em' }}>{time}</span>
        </div>
        <button
          id="btn-simulate"
          className={`sim-btn ${simRunning ? 'sim-btn--active' : ''}`}
          onClick={onSimulate}
          disabled={simRunning}
        >
          {simRunning ? (
            <>
              <span className="sim-spinner" />
              Responding...
            </>
          ) : (
            'Simulate Crisis'
          )}
        </button>
      </div>
    </header>
  )
}
