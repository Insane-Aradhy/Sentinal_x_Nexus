/**
 * AsteroidBelt.jsx — 3D Asteroid Renderer
 * ════════════════════════════════════════
 * Renders all NEOs as color-coded glowing spheres in the 3D scene.
 * Uses individual meshes (not instanced) for easy interactivity.
 * Each asteroid pulses based on its risk level and can be
 * hovered/clicked to select it.
 */
import { useRef, useState, useMemo, useCallback } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { Html } from '@react-three/drei'
import * as THREE from 'three'

// ── Single Asteroid Mesh ───────────────────────────────────────────────
function AsteroidDot({
  neo,
  isSelected,
  isHovered,
  onSelect,
  onHover,
  onUnhover,
}) {
  const meshRef = useRef()
  const glowRef = useRef()
  const { x, y, z } = neo._pos3D

  // Determine visual size based on diameter
  const baseSize = Math.max(0.15, Math.min(neo._diamAvg * 200, 0.6))
  const riskColor = new THREE.Color(neo._riskColor)

  // Pulse animation for hazardous asteroids
  useFrame((state) => {
    if (!meshRef.current) return

    // Pulse effect
    if (neo._riskLevel === 'hazardous') {
      const pulse = 1 + Math.sin(state.clock.elapsedTime * 3 + neo._index) * 0.3
      meshRef.current.scale.setScalar(pulse)
    }

    // Selected glow
    if (glowRef.current) {
      if (isSelected) {
        const ringPulse = 1 + Math.sin(state.clock.elapsedTime * 2) * 0.15
        glowRef.current.scale.setScalar(ringPulse)
        glowRef.current.visible = true
      } else {
        glowRef.current.visible = isHovered
      }
    }
  })

  return (
    <group position={[x, y, z]}>
      {/* Main asteroid dot */}
      <mesh
        ref={meshRef}
        onClick={(e) => { e.stopPropagation(); onSelect(neo) }}
        onPointerOver={(e) => { e.stopPropagation(); onHover(neo) }}
        onPointerOut={(e) => { e.stopPropagation(); onUnhover() }}
      >
        <sphereGeometry args={[baseSize, 12, 12]} />
        <meshBasicMaterial
          color={riskColor}
          transparent
          opacity={isSelected ? 1 : 0.85}
        />
      </mesh>

      {/* Selection / hover ring */}
      <mesh ref={glowRef} visible={false}>
        <ringGeometry args={[baseSize * 1.8, baseSize * 2.5, 24]} />
        <meshBasicMaterial
          color={riskColor}
          transparent
          opacity={0.4}
          side={THREE.DoubleSide}
          depthWrite={false}
        />
      </mesh>

      {/* Glow sphere behind */}
      <mesh>
        <sphereGeometry args={[baseSize * 2, 12, 12]} />
        <meshBasicMaterial
          color={riskColor}
          transparent
          opacity={neo._riskLevel === 'hazardous' ? 0.12 : 0.06}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </mesh>

      {/* HTML tooltip on hover */}
      {isHovered && !isSelected && (
        <Html
          center
          distanceFactor={40}
          style={{ pointerEvents: 'none' }}
        >
          <div className="neo-3d-tooltip">
            <div className="neo-3d-tooltip-name">{neo.name}</div>
            <div className="neo-3d-tooltip-data">
              {neo._missKm < 1_000_000
                ? `${(neo._missKm / 1000).toFixed(0)}k km`
                : `${(neo._missKm / 1_000_000).toFixed(2)}M km`
              } · {neo._velKmS.toFixed(1)} km/s
            </div>
          </div>
        </Html>
      )}
    </group>
  )
}

// ── Connecting Lines (selected asteroid to Earth) ──────────────────────
function ConnectionLine({ from, to, color }) {
  const geometry = useMemo(() => {
    const points = [
      new THREE.Vector3(from.x, from.y, from.z),
      new THREE.Vector3(to.x, to.y, to.z),
    ]
    return new THREE.BufferGeometry().setFromPoints(points)
  }, [from, to])

  return (
    <line geometry={geometry}>
      <lineBasicMaterial
        color={color}
        transparent
        opacity={0.3}
        depthWrite={false}
        linewidth={1}
      />
    </line>
  )
}

// ── Trajectory Line (JPL Horizons Orbit Path) ──────────────────────────
function TrajectoryLine({ points, color }) {
  const geometry = useMemo(() => {
    return new THREE.BufferGeometry().setFromPoints(
      points.map(p => new THREE.Vector3(p.x, p.y, p.z))
    )
  }, [points])

  return (
    <line geometry={geometry}>
      <lineBasicMaterial
        color={color}
        transparent
        opacity={0.6}
        depthWrite={false}
        linewidth={2}
      />
    </line>
  )
}

// ═══════════════════════════════════════════════════════════════════════
// MAIN AsteroidBelt COMPONENT
// ═══════════════════════════════════════════════════════════════════════
export default function AsteroidBelt({
  neos = [],
  selectedNeo,
  trajectoryPoints,
  onSelectNeo,
  earthPosition,
}) {
  const [hoveredNeo, setHoveredNeo] = useState(null)

  const handleSelect = useCallback((neo) => {
    onSelectNeo?.(neo)
  }, [onSelectNeo])

  const handleHover = useCallback((neo) => {
    setHoveredNeo(neo)
    document.body.style.cursor = 'pointer'
  }, [])

  const handleUnhover = useCallback(() => {
    setHoveredNeo(null)
    document.body.style.cursor = 'default'
  }, [])

  if (!neos || neos.length === 0) return null

  return (
    <group>
      {neos.map((neo) => {
        const isSelected = selectedNeo?.id === neo.id
        // If this is the selected asteroid AND we have its true Horizons trajectory,
        // snap its visual position exactly to the start of the trajectory (today)!
        const displayNeo = (isSelected && trajectoryPoints && trajectoryPoints.length > 0)
          ? { ...neo, _pos3D: trajectoryPoints[0] }
          : neo

        return (
          <AsteroidDot
            key={displayNeo.id || displayNeo.neo_reference_id || displayNeo._index}
            neo={displayNeo}
            isSelected={isSelected}
            isHovered={hoveredNeo?.id === displayNeo.id}
            onSelect={handleSelect}
            onHover={handleHover}
            onUnhover={handleUnhover}
          />
        )
      })}

      {/* JPL Horizons True Orbital Trajectory Line */}
      {selectedNeo && trajectoryPoints && trajectoryPoints.length > 0 && (
        <TrajectoryLine
          points={trajectoryPoints}
          color={selectedNeo._riskColor}
        />
      )}

      {/* Connection line from selected asteroid to Earth */}
      {selectedNeo && earthPosition && (
        <ConnectionLine
          from={(selectedNeo.id && trajectoryPoints && trajectoryPoints.length > 0) ? trajectoryPoints[0] : selectedNeo._pos3D}
          to={earthPosition}
          color={selectedNeo._riskColor}
        />
      )}
    </group>
  )
}
