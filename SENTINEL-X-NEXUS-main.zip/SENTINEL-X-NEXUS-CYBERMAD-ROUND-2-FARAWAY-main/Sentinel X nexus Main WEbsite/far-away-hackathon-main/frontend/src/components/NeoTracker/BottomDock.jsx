import './NeoTracker.css'

export default function BottomDock() {
  return (
    <div className="neo-bottom-dock neo-fade-in neo-fade-in-d3">
      {/* ── Defense Assets ── */}
      <div className="neo-dock-section">
        <div className="neo-dock-title">DEFENSE ASSETS</div>
        <div className="neo-dock-cards">
          
          <div className="neo-asset-card">
            <div className="neo-asset-icon">🛰️</div>
            <div className="neo-asset-info">
              <div className="neo-asset-name">ORBIT-22B</div>
              <div className="neo-asset-status" style={{ color: '#10B981' }}>• Active (GEO-2)</div>
              <div className="neo-asset-bar-bg"><div className="neo-asset-bar-fill" style={{ width: '100%', background: '#10B981' }}/></div>
            </div>
          </div>

          <div className="neo-asset-card">
            <div className="neo-asset-icon">🛰️</div>
            <div className="neo-asset-info">
              <div className="neo-asset-name">ORBIT-17A</div>
              <div className="neo-asset-status" style={{ color: '#FFB800' }}>• Charging (LEO-6)</div>
              <div className="neo-asset-bar-bg"><div className="neo-asset-bar-fill pulse" style={{ width: '65%', background: '#FFB800' }}/></div>
            </div>
          </div>

        </div>
      </div>

      {/* ── Global Vitals ── */}
      <div className="neo-dock-section">
        <div className="neo-dock-title">GLOBAL VITALS</div>
        <div className="neo-vital-stats">
          <div className="neo-vital-stat">
            <div className="neo-vital-val" style={{ color: '#00F0FF' }}>70%</div>
            <div className="neo-vital-lbl">Global Energy</div>
          </div>
          <div className="neo-vital-stat">
            <div className="neo-vital-val" style={{ color: '#10B981' }}>3 / 4</div>
            <div className="neo-vital-lbl">Shields Active</div>
          </div>
          <div className="neo-vital-stat">
            <div className="neo-vital-val" style={{ color: '#FFB800' }}>5 / 7</div>
            <div className="neo-vital-lbl">Interceptors Ready</div>
          </div>
        </div>
      </div>

    </div>
  )
}
