/**
 * NeoTracker.jsx — External Dashboards Hub
 * ════════════════════════════════════════════════
 * This section now serves as the launchpad for the three
 * external web applications (CosmoDash, Deep Space Mission, etc.)
 */
import { useState } from 'react'
import './NeoTracker.css'

export default function NeoTracker() {
  const [showNote, setShowNote] = useState(true)
  const dashboards = [
    {
      id: 'cosmo',
      title: 'CosmoDash Analytics',
      desc: 'Real-time telemetry and API-driven astronomy data integration.',
      icon: '🔭',
      color: '#ec4899', // Pink
      url: 'https://build-cosmodash-glassmorphism-dashboard-pow6seclq.vercel.app/'
    },
    {
      id: 'deepspace',
      title: 'Deep Space Mission',
      desc: 'Advanced orbital mission tracking and deep space metrics.',
      icon: '🚀',
      color: '#fbbf24', // Golden
      url: 'https://deep-space-mission-dashboard-hry1l1pw0.vercel.app'
    },
    {
      id: 'third',
      title: 'Exoplanet Exploration',
      desc: 'Explore distant worlds and discover new exoplanetary systems.',
      icon: '🪐',
      color: '#4ade80', // Green
      url: 'https://exoplanet-exploration-web-portal-ott3k9icy.vercel.app'
    }
  ]

  const handleLaunch = (url) => {
    window.open(url, '_blank')
  }

  return (
    <div className="neo-tracker-page" style={{ 
      background: 'radial-gradient(circle at center, #0a0a1a 0%, #030308 100%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '100px 40px 40px 40px',
      overflowY: 'auto',
      minHeight: '100vh'
    }}>
      
      {/* ── Top HUD ── */}
      <div className="neo-top-hud neo-fade-in" style={{ position: 'absolute', top: 20, left: 20, right: 20 }}>
        <div className="neo-hud-title">
          <span className="neo-hud-icon">🌌</span>
          <div className="neo-hud-label">
            <span className="neo-hud-name">External Systems Hub</span>
            <span className="neo-hud-sub">Launchpad for Sub-Systems</span>
          </div>
        </div>
      </div>

      <div style={{
        textAlign: 'center',
        marginBottom: '30px',
        animation: 'fadeIn 1s ease-out',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center'
      }}>
        <h1 style={{ color: '#fff', fontSize: '2.5rem', marginBottom: '10px', textShadow: '0 0 20px rgba(255,255,255,0.2)' }}>
          NEXUS SUB-SYSTEMS
        </h1>
        <p style={{ color: '#8892b0', fontSize: '1.1rem', maxWidth: '600px', marginBottom: '20px' }}>
          Select a dedicated dashboard module to launch its external instance. These systems are independently hosted for maximum performance.
        </p>
        
        {showNote && (
          <div style={{
            background: 'rgba(251, 191, 36, 0.1)',
            border: '1px solid rgba(251, 191, 36, 0.3)',
            borderRadius: '8px',
            padding: '12px 16px',
            maxWidth: '700px',
            display: 'flex',
            alignItems: 'flex-start',
            gap: '12px',
            textAlign: 'left',
            position: 'relative'
          }}>
            <span style={{ fontSize: '20px', marginTop: '-2px' }}>⭐</span>
            <div style={{ flex: 1 }}>
              <strong style={{ color: '#fbbf24', fontSize: '0.95rem', display: 'block', marginBottom: '4px' }}>HACKATHON NOTE FOR JUDGES:</strong>
              <span style={{ color: '#d1d5db', fontSize: '0.85rem', lineHeight: '1.4' }}>
                To maximize our platform's utility and demonstrate scalable micro-frontend architecture, <strong>all three of the external dashboards linked below were custom-built from scratch by our team during this 24-hour marathon.</strong> Each functions as a standalone application fetching live data.
              </span>
            </div>
            <button 
              onClick={() => setShowNote(false)}
              style={{
                background: 'transparent', border: 'none', color: '#9ca3af', cursor: 'pointer', fontSize: '18px', padding: '0 4px'
              }}
            >
              ×
            </button>
          </div>
        )}
      </div>

      <div style={{
        display: 'flex',
        gap: '30px',
        flexWrap: 'wrap',
        justifyContent: 'center',
        maxWidth: '1200px'
      }}>
        {dashboards.map((board) => (
          <div key={board.id} className="hub-card" style={{
            width: '320px',
            padding: '30px',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            textAlign: 'center',
            cursor: 'pointer',
            transition: 'all 0.3s ease',
            border: `1px solid rgba(255,255,255,0.1)`,
            borderTop: `2px solid ${board.color}`,
            borderRadius: '16px',
            background: 'rgba(12,14,25,0.7)',
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
            marginTop: '40px',
            flexShrink: 0
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-10px)'
            e.currentTarget.style.boxShadow = `0 15px 30px ${board.color}44`
            e.currentTarget.style.borderColor = board.color
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)'
            e.currentTarget.style.boxShadow = '0 8px 32px rgba(0,0,0,0.5)'
            e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)'
          }}
          onClick={() => handleLaunch(board.url)}
          >
            <div style={{
              fontSize: '4rem',
              marginBottom: '20px',
              textShadow: `0 0 30px ${board.color}`
            }}>
              {board.icon}
            </div>
            <h2 style={{ color: '#fff', margin: '0 0 15px 0', fontSize: '1.4rem' }}>{board.title}</h2>
            <p style={{ color: '#94a3b8', fontSize: '0.95rem', lineHeight: '1.5', flexGrow: 1 }}>
              {board.desc}
            </p>
            <button style={{
              marginTop: '25px',
              width: '100%',
              padding: '12px',
              background: 'rgba(255,255,255,0.05)',
              border: `1px solid ${board.color}66`,
              color: board.color,
              fontWeight: 'bold',
              borderRadius: '6px',
              cursor: 'pointer',
              textTransform: 'uppercase',
              letterSpacing: '1px',
              transition: 'all 0.2s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = `${board.color}22`
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(255,255,255,0.05)'
            }}>
              Launch System ↗
            </button>
          </div>
        ))}
      </div>
      
    </div>
  )
}
