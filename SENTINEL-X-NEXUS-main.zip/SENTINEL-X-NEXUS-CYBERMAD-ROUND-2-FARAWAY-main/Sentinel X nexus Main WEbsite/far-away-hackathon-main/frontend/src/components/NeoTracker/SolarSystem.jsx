/**
 * SolarSystem.jsx — 3D Heliocentric Solar System Scene
 * ═════════════════════════════════════════════════════
 * Renders the Sun (emissive glow), Earth, Mars, and their
 * orbital rings using @react-three/fiber. The planets slowly
 * orbit the Sun. Uses a simplified AU-to-scene scale.
 *
 * Scale: 1 AU ≈ 30 scene units (for visual clarity)
 */
import { useRef, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import { Html } from '@react-three/drei'
import * as THREE from 'three'
import Satellites from './Satellites'

const AU = 30                       // 1 AU in scene units
const EARTH_ORBIT_R  = 1.0 * AU     // 30 units
const MARS_ORBIT_R   = 1.524 * AU   // ~45.7 units
const VENUS_ORBIT_R  = 0.723 * AU   // ~21.7 units

// ── Sun Component ──────────────────────────────────────────────────────
function Sun() {
  const meshRef = useRef()
  const glowRef = useRef()

  useFrame((state) => {
    // Subtle pulse on the sun glow
    if (glowRef.current) {
      const s = 1 + Math.sin(state.clock.elapsedTime * 0.5) * 0.05
      glowRef.current.scale.set(s, s, s)
    }
  })

  return (
    <group>
      {/* Label */}
      <Html center distanceFactor={25} zIndexRange={[100, 0]}>
        <div className="neo-planet-label" style={{ color: '#ffaa22' }}>SUN</div>
      </Html>

      {/* Core sun sphere */}
      <mesh ref={meshRef}>
        <sphereGeometry args={[2.5, 48, 48]} />
        <meshBasicMaterial color="#ffaa22" />
      </mesh>

      {/* Outer glow shell */}
      <mesh ref={glowRef}>
        <sphereGeometry args={[3.5, 32, 32]} />
        <meshBasicMaterial
          color="#ffcc44"
          transparent
          opacity={0.15}
          side={THREE.BackSide}
        />
      </mesh>

      {/* Second glow layer */}
      <mesh>
        <sphereGeometry args={[5, 32, 32]} />
        <meshBasicMaterial
          color="#ff8800"
          transparent
          opacity={0.06}
          side={THREE.BackSide}
        />
      </mesh>

      {/* Point light from the Sun */}
      <pointLight color="#ffcc88" intensity={2} distance={300} decay={0.5} />
      <pointLight color="#ffffff" intensity={0.5} distance={500} decay={0.3} />
    </group>
  )
}

// ── Orbit Ring ─────────────────────────────────────────────────────────
function OrbitRing({ radius, color = '#ffffff', opacity = 0.08, segments = 128 }) {
  const points = useMemo(() => {
    const pts = []
    for (let i = 0; i <= segments; i++) {
      const angle = (i / segments) * Math.PI * 2
      pts.push(new THREE.Vector3(
        Math.cos(angle) * radius,
        0,
        Math.sin(angle) * radius
      ))
    }
    return pts
  }, [radius, segments])

  const geometry = useMemo(() => {
    return new THREE.BufferGeometry().setFromPoints(points)
  }, [points])

  return (
    <line geometry={geometry}>
      <lineBasicMaterial
        color={color}
        transparent
        opacity={opacity}
        depthWrite={false}
      />
    </line>
  )
}

// ── Planet ──────────────────────────────────────────────────────────────
function Planet({ orbitRadius, size, color, speed, startAngle = 0, name, glowColor, onPositionUpdate, children }) {
  const groupRef = useRef()
  const meshRef  = useRef()

  useFrame((state) => {
    if (groupRef.current) {
      const angle = startAngle + state.clock.elapsedTime * speed
      groupRef.current.position.x = Math.cos(angle) * orbitRadius
      groupRef.current.position.z = Math.sin(angle) * orbitRadius

      // Report position to parent (for Earth tracking)
      if (onPositionUpdate) {
        onPositionUpdate({
          x: groupRef.current.position.x,
          y: 0,
          z: groupRef.current.position.z,
        })
      }
    }
    // Slow self-rotation
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.002
    }
  })

  return (
    <group ref={groupRef}>
      {/* Label */}
      <Html center distanceFactor={15} zIndexRange={[100, 0]}>
        <div className="neo-planet-label" style={{ color: color, transform: 'translateY(-20px)' }}>{name.toUpperCase()}</div>
      </Html>

      {/* Planet body */}
      <mesh ref={meshRef}>
        <sphereGeometry args={[size, 32, 32]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={0.15}
          roughness={0.7}
          metalness={0.1}
        />
      </mesh>

      {/* Atmosphere glow */}
      <mesh>
        <sphereGeometry args={[size * 1.15, 32, 32]} />
        <meshBasicMaterial
          color={glowColor}
          transparent
          opacity={0.15}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
        />
      </mesh>

      {/* Children (e.g. Satellites orbiting this planet) */}
      {children}
    </group>
  )
}

// ── Grid plane (ecliptic reference) ────────────────────────────────────
function EclipticGrid() {
  return (
    <gridHelper
      args={[200, 40, 'rgba(255,255,255,0.03)', 'rgba(255,255,255,0.015)']}
      position={[0, -0.5, 0]}
    >
      <meshBasicMaterial
        attach="material"
        color="#1a1a3a"
        transparent
        opacity={0.08}
      />
    </gridHelper>
  )
}

// ── Main Solar System Component ────────────────────────────────────────
export default function SolarSystem({ onEarthPosition }) {
  return (
    <group>
      {/* Ecliptic grid */}
      <EclipticGrid />

      {/* Sun */}
      <Sun />

      {/* Orbit rings */}
      <OrbitRing radius={VENUS_ORBIT_R} color="#ffaa44" opacity={0.06} />
      <OrbitRing radius={EARTH_ORBIT_R} color="#4488ff" opacity={0.12} />
      <OrbitRing radius={MARS_ORBIT_R}  color="#ff4422" opacity={0.08} />

      {/* Venus */}
      <Planet
        name="Venus"
        orbitRadius={VENUS_ORBIT_R}
        size={0.7}
        color="#e8c56d"
        glowColor="#ffdd88"
        speed={0.08}
        startAngle={2.1}
      />

      {/* Earth */}
      <Planet
        name="Earth"
        orbitRadius={EARTH_ORBIT_R}
        size={0.85}
        color="#4488ff"
        glowColor="#66aaff"
        speed={0.05}
        startAngle={0}
        onPositionUpdate={onEarthPosition}
      >
        <Satellites />
      </Planet>

      {/* Mars */}
      <Planet
        name="Mars"
        orbitRadius={MARS_ORBIT_R}
        size={0.6}
        color="#cc4422"
        glowColor="#ff6644"
        speed={0.03}
        startAngle={3.8}
      />

      {/* Ambient light for baseline visibility */}
      <ambientLight intensity={0.08} color="#667799" />
    </group>
  )
}

// Export constants for other components
export { AU, EARTH_ORBIT_R, MARS_ORBIT_R, VENUS_ORBIT_R }
