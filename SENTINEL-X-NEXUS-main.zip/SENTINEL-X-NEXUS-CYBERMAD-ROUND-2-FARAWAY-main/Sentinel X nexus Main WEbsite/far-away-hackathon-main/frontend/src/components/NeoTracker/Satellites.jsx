import { useState, useEffect, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Html } from '@react-three/drei'
import * as THREE from 'three'

// The Earth radius is ~6371 km. Our scene Earth size is 0.85
const KM_TO_UNITS = 0.85 / 6371

export default function Satellites() {
  const [sats, setSats] = useState([])

  useEffect(() => {
    // Note: In production, this would use a dynamic host/port based on environment
    const ws = new WebSocket('ws://localhost:8000/ws')
    
    ws.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data)
        if (payload.type === 'satellite_positions' && Array.isArray(payload.data)) {
          setSats(payload.data)
        }
      } catch(e) {
        console.error("Satellite WS parse error", e)
      }
    }
    
    return () => {
      if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
        ws.close()
      }
    }
  }, [])

  return (
    <group>
      {sats.map(sat => (
        <SatelliteDot key={sat.norad_id} sat={sat} />
      ))}
    </group>
  )
}

function SatelliteDot({ sat }) {
  const meshRef = useRef()
  
  // Safely extract coordinates (fallback to 0 if missing)
  const pos = sat?.position || { x: 0, y: 0, z: 0 }
  
  // Convert ECI km to three.js scene units
  // ECI Z is through poles (our Y), ECI X/Y is equatorial (our X/Z)
  const targetPos = new THREE.Vector3(
    pos.x * KM_TO_UNITS, 
    pos.z * KM_TO_UNITS, 
    -pos.y * KM_TO_UNITS
  )

  useFrame(() => {
    if (meshRef.current && sat?.position) {
      // Smooth interpolation between the 3-second WS updates
      meshRef.current.position.lerp(targetPos, 0.05)
    }
  })

  if (!sat || !sat.position) return null

  return (
    <mesh ref={meshRef} position={targetPos}>
      <sphereGeometry args={[0.03, 8, 8]} />
      <meshBasicMaterial color="#00ffff" />
      <Html distanceFactor={15}>
        <div style={{ 
          color: '#00ffff', 
          fontSize: '9px', 
          fontFamily: 'monospace',
          pointerEvents: 'none', 
          transform: 'translate(6px, -6px)',
          textShadow: '0 0 4px #000'
        }}>
          {sat.name}
        </div>
      </Html>
    </mesh>
  )
}
