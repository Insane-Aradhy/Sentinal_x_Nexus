/**
 * Starfield.jsx — Procedural 3D Starfield Background
 * ════════════════════════════════════════════════════
 * Renders thousands of randomly placed points to simulate
 * a deep-space star backdrop. Uses Three.js Points for
 * high performance (single draw call).
 */
import { useRef, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'

export default function Starfield({ count = 4000 }) {
  const pointsRef = useRef()

  // Generate random star positions in a large sphere
  const { positions, colors, sizes } = useMemo(() => {
    const positions = new Float32Array(count * 3)
    const colors    = new Float32Array(count * 3)
    const sizes     = new Float32Array(count)

    for (let i = 0; i < count; i++) {
      // Distribute stars uniformly in a spherical shell (radius 200–600)
      const r     = 200 + Math.random() * 400
      const theta = Math.random() * Math.PI * 2
      const phi   = Math.acos(2 * Math.random() - 1)

      positions[i * 3]     = r * Math.sin(phi) * Math.cos(theta)
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta)
      positions[i * 3 + 2] = r * Math.cos(phi)

      // Slight color variation — mostly white-blue, some warm
      const temp = Math.random()
      if (temp < 0.6) {
        // White-blue stars
        colors[i * 3]     = 0.8 + Math.random() * 0.2
        colors[i * 3 + 1] = 0.85 + Math.random() * 0.15
        colors[i * 3 + 2] = 1.0
      } else if (temp < 0.85) {
        // Warm yellow-white
        colors[i * 3]     = 1.0
        colors[i * 3 + 1] = 0.9 + Math.random() * 0.1
        colors[i * 3 + 2] = 0.7 + Math.random() * 0.2
      } else {
        // Faint reddish
        colors[i * 3]     = 1.0
        colors[i * 3 + 1] = 0.6 + Math.random() * 0.3
        colors[i * 3 + 2] = 0.5 + Math.random() * 0.3
      }

      // Vary star sizes — most small, few bright
      sizes[i] = Math.random() < 0.95
        ? 0.3 + Math.random() * 0.7
        : 1.2 + Math.random() * 1.5
    }

    return { positions, colors, sizes }
  }, [count])

  // Very slow rotation for subtle parallax
  useFrame((_, delta) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y += delta * 0.003
      pointsRef.current.rotation.x += delta * 0.001
    }
  })

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={count}
          array={colors}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-size"
          count={count}
          array={sizes}
          itemSize={1}
        />
      </bufferGeometry>
      <pointsMaterial
        vertexColors
        size={0.6}
        sizeAttenuation
        transparent
        opacity={0.85}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  )
}
