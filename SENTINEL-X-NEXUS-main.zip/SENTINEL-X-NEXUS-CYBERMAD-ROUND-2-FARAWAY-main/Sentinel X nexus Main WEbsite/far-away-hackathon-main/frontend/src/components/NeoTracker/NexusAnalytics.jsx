/**
 * NexusAnalytics.jsx — NEO Tracker Right Panel
 * ════════════════════════════════════════════
 * Displays detailed telemetry for the selected NEO.
 */
import { formatDistance, formatVelocity, formatDiameter, getRiskLabel } from '../../services/neoApi'

export default function NexusAnalytics({ neo, isVisible, onClose, trajectoryLoading, nexusPreference, onInitiateMitigation }) {
  if (!neo) {
    return (
      <div className={`neo-glass-panel right hidden-right`}>
        <div className="neo-panel-header">
          <div className="neo-panel-title">
            <span>⬡</span>
            <span>Nexus Analytics</span>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className={`neo-glass-panel right ${isVisible ? '' : 'hidden-right'}`}>
      <div className="neo-panel-header">
        <div className="neo-panel-title">
          <span>⬡</span>
          <span>Nexus Analytics</span>
        </div>
        <button className="neo-panel-close" onClick={onClose}>✕</button>
      </div>
      
      <div className="neo-panel-body neo-analytics-body">
        {/* Title Block */}
        <div className="neo-an-title-block">
          <div className="neo-an-name">{neo.name}</div>
          <div className="neo-feed-badge" style={{ color: neo._riskColor, borderColor: neo._riskColor, alignSelf: 'flex-start' }}>
            {getRiskLabel(neo._riskLevel)}
          </div>
        </div>

        {/* Horizons Sync Status */}
        <div className="neo-an-horizons-status">
          {trajectoryLoading ? (
            <div className="neo-horizons-loading">
              <span className="neo-spinner" /> Syncing JPL Horizons Ephemeris...
            </div>
          ) : (
            <div className="neo-horizons-success">
              ✓ Deep Space Trajectory Linked
            </div>
          )}
        </div>

        {/* Main Telemetry Grid */}
        <div className="neo-an-grid">
          <div className="neo-an-box">
            <div className="neo-an-lbl">MISS DISTANCE</div>
            <div className="neo-an-val" style={{ color: neo._riskColor }}>
              {formatDistance(neo._missKm)}
            </div>
            <div className="neo-an-sub">{neo._missLD.toFixed(2)} Lunar Distances</div>
          </div>
          
          <div className="neo-an-box">
            <div className="neo-an-lbl">RELATIVE VELOCITY</div>
            <div className="neo-an-val">{formatVelocity(neo._velKmS)}</div>
            <div className="neo-an-sub">{(neo._velKmS * 3600).toFixed(0)} km/h</div>
          </div>

          <div className="neo-an-box">
            <div className="neo-an-lbl">EST. DIAMETER</div>
            <div className="neo-an-val">{formatDiameter(neo._diamMin, neo._diamMax)}</div>
            <div className="neo-an-sub">Avg: {(neo._diamAvg * 1000).toFixed(1)} m</div>
          </div>

          <div className="neo-an-box">
            <div className="neo-an-lbl">ABS. MAGNITUDE (H)</div>
            <div className="neo-an-val">{neo._magnitude ? neo._magnitude.toFixed(2) : '—'}</div>
            <div className="neo-an-sub">Lower is brighter</div>
          </div>
        </div>

        {/* Approach Info */}
        <div className="neo-an-approach-info">
          <div className="neo-an-lbl">CLOSE APPROACH DATE</div>
          <div className="neo-an-val-lg">{neo._approachDate}</div>
          <div className="neo-an-sub" style={{ marginTop: 4 }}>
            Orbiting Body: <span style={{ color: '#4488ff' }}>{neo._orbitingBody}</span>
          </div>
        </div>

        {/* Preference Learning Section (Hackathon Req) */}
        <div className="neo-preference-section" style={{ marginTop: 15, padding: 10, background: 'rgba(255, 170, 34, 0.1)', border: '1px solid rgba(255, 170, 34, 0.3)', borderRadius: 4 }}>
          <div className="neo-an-lbl" style={{ color: '#fbbf24' }}>AI MITIGATION PREFERENCE</div>
          <div className="neo-an-val" style={{ fontSize: '1rem', color: '#fff' }}>{nexusPreference || 'Fuel Conservation'}</div>
          <div className="neo-an-sub" style={{ fontSize: '0.75rem' }}>Auto-calculation strategy scope: Hazardous NEOs</div>
        </div>

        {/* Mitigation Trigger */}
        {neo._riskLevel === 'hazardous' && (
          <button 
            className="neo-btn-mitigation" 
            onClick={onInitiateMitigation}
            style={{
              marginTop: 15,
              width: '100%',
              padding: '12px',
              background: 'rgba(248, 113, 113, 0.2)',
              border: '1px solid #f87171',
              color: '#f87171',
              fontWeight: 'bold',
              cursor: 'pointer',
              textTransform: 'uppercase',
              letterSpacing: '1px',
              transition: 'all 0.2s ease'
            }}
            onMouseOver={(e) => { e.currentTarget.style.background = 'rgba(248, 113, 113, 0.4)' }}
            onMouseOut={(e) => { e.currentTarget.style.background = 'rgba(248, 113, 113, 0.2)' }}
          >
            Initiate Mitigation
          </button>
        )}
      </div>
    </div>
  )
}
