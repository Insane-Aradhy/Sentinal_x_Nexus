/**
 * SentinelFeed.jsx — NEO Tracker Left Panel
 * ═════════════════════════════════════════
 * Displays a filterable, scrollable list of all upcoming
 * asteroid close approaches. Clicking an item selects it
 * in the 3D scene.
 */
import { useState, useMemo } from 'react'
import { formatDistance, formatVelocity, getRiskLabel } from '../../services/neoApi'

export default function SentinelFeed({ neos, selectedNeo, onSelectNeo, onClose }) {
  const [filter, setFilter] = useState('all') // all, hazardous, close, safe

  // Filter the list based on risk level
  const filteredNeos = useMemo(() => {
    switch (filter) {
      case 'hazardous': return neos.filter(n => n._riskLevel === 'hazardous')
      case 'close':     return neos.filter(n => n._riskLevel === 'close')
      case 'safe':      return neos.filter(n => n._riskLevel === 'safe' || n._riskLevel === 'watch')
      default:          return neos
    }
  }, [neos, filter])

  return (
    <>
      <div className="neo-panel-header">
        <div className="neo-panel-title">
          <span>🛡</span>
          <span>Sentinel Feed</span>
        </div>
        <button className="neo-panel-close" onClick={onClose}>✕</button>
      </div>

      {/* Filter Tabs */}
      <div className="neo-feed-filters">
        <button
          className={`neo-feed-filter ${filter === 'all' ? 'active' : ''}`}
          onClick={() => setFilter('all')}
        >
          All
        </button>
        <button
          className={`neo-feed-filter ${filter === 'hazardous' ? 'active haz' : ''}`}
          onClick={() => setFilter('hazardous')}
        >
          PHA
        </button>
        <button
          className={`neo-feed-filter ${filter === 'close' ? 'active close' : ''}`}
          onClick={() => setFilter('close')}
        >
          &lt;1M km
        </button>
      </div>

      <div className="neo-panel-body neo-feed-list">
        {filteredNeos.length === 0 ? (
          <div className="neo-feed-empty">No objects match this filter.</div>
        ) : (
          filteredNeos.map((neo) => {
            const isSelected = selectedNeo?.id === neo.id
            return (
              <div
                key={neo.id}
                className={`neo-feed-card ${isSelected ? 'selected' : ''}`}
                onClick={() => onSelectNeo(neo)}
                style={{ '--risk-color': neo._riskColor }}
              >
                {/* Accent line on left */}
                <div className="neo-feed-card-accent" style={{ background: neo._riskColor }} />
                
                <div className="neo-feed-card-header">
                  <span className="neo-feed-card-name">{neo.name}</span>
                  <span className="neo-feed-card-date">{neo._approachDate}</span>
                </div>
                
                <div className="neo-feed-card-metrics">
                  <div className="neo-feed-metric">
                    <span className="neo-feed-metric-lbl">MISS (KM)</span>
                    <span className="neo-feed-metric-val" style={{ color: neo._riskColor }}>
                      {formatDistance(neo._missKm)}
                    </span>
                  </div>
                  <div className="neo-feed-metric">
                    <span className="neo-feed-metric-lbl">VELOCITY</span>
                    <span className="neo-feed-metric-val">{formatVelocity(neo._velKmS)}</span>
                  </div>
                </div>

                <div className="neo-feed-card-footer">
                  <span className="neo-feed-badge" style={{ color: neo._riskColor, borderColor: neo._riskColor }}>
                    {getRiskLabel(neo._riskLevel)}
                  </span>
                  <span className="neo-feed-id">ID: {neo.id}</span>
                </div>
              </div>
            )
          })
        )}
      </div>
    </>
  )
}
