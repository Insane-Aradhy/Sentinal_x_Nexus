import React, { useMemo, useState, useEffect, useRef } from 'react';
import * as satellite from 'satellite.js';
import './OrbitalGlobe.css';

const Satellite3D = ({ color }) => (
  <svg width="36" height="36" viewBox="0 0 32 32" style={{ transform: 'translate(-50%, -50%)', filter: `drop-shadow(0 0 4px ${color})`, zIndex: 10 }}>
    <defs>
      <linearGradient id={`grad-${color.replace('#','')}`} x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ffffff" stopOpacity="0.9" />
        <stop offset="100%" stopColor={color} stopOpacity="0.8" />
      </linearGradient>
      <linearGradient id="panel-grad" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#1e3a8a" />
        <stop offset="50%" stopColor="#60a5fa" />
        <stop offset="100%" stopColor="#1e3a8a" />
      </linearGradient>
    </defs>
    
    <path d="M 2 14 L 10 10 L 14 16 L 6 20 Z" fill="url(#panel-grad)" stroke={color} strokeWidth="0.5" />
    <line x1="6" y1="12" x2="10" y2="18" stroke="#93c5fd" strokeWidth="0.5" opacity="0.5" />
    
    <path d="M 18 12 L 26 8 L 30 14 L 22 18 Z" fill="url(#panel-grad)" stroke={color} strokeWidth="0.5" />
    <line x1="22" y1="10" x2="26" y2="16" stroke="#93c5fd" strokeWidth="0.5" opacity="0.5" />

    <path d="M 10 10 L 18 8 L 22 14 L 14 16 Z" fill={`url(#grad-${color.replace('#','')})`} stroke="#ffffff" strokeWidth="0.5" />
    <path d="M 10 10 L 14 16 L 14 24 L 10 18 Z" fill={color} opacity="0.8" stroke="#ffffff" strokeWidth="0.5" />
    <path d="M 14 16 L 22 14 L 22 22 L 14 24 Z" fill={color} opacity="0.4" stroke="#ffffff" strokeWidth="0.5" />

    <line x1="16" y1="12" x2="16" y2="2" stroke="#ffffff" strokeWidth="1" />
    <circle cx="16" cy="2" r="1.5" fill="#ef4444" />
  </svg>
)

export default function OrbitalGlobe({ events = [], positions = [], alertActive = false }) {
  const [rotX, setRotX] = useState(65); 
  const [rotZ, setRotZ] = useState(30); 

  const [isDragging, setIsDragging] = useState(false);
  const [lastMouse, setLastMouse] = useState({ x: 0, y: 0 });

  // Use satellite.js to calculate TRUE SGP4 Longitude at 60 FPS
  const [livePositions, setLivePositions] = useState([]);

  useEffect(() => {
    if (!positions || positions.length === 0) return;

    let animationFrameId;
    const TIME_MULTIPLIER = 10; // Accelerated so we can observe the orbit
    
    // We base the simulation off when the component mounted
    const mountTime = Date.now();

    const updatePositions = () => {
      // Calculate true simulated time
      const simulatedTime = new Date(Date.now() + (Date.now() - mountTime) * (TIME_MULTIPLIER - 1));

      const updated = positions.map((p) => {
        try {
          if (!p.line1 || !p.line2) return null;
          const satrec = satellite.twoline2satrec(p.line1, p.line2);
          
          // Propagate main position
          const pv = satellite.propagate(satrec, simulatedTime);
          if (!pv.position) return null;
          const gm = satellite.gstime(simulatedTime);
          const gd = satellite.eciToGeodetic(pv.position, gm);
          const liveLng = satellite.degreesLong(gd.longitude);
          
          // Propagate trailing comet tails using real past time intervals
          const trails = [1, 2, 3, 4, 5].map(i => {
             // 5 seconds behind * time multiplier
             const trailTime = new Date(simulatedTime.getTime() - (i * 5000 * TIME_MULTIPLIER));
             const trailPv = satellite.propagate(satrec, trailTime);
             if(!trailPv.position) return liveLng;
             const trailGm = satellite.gstime(trailTime);
             const trailGd = satellite.eciToGeodetic(trailPv.position, trailGm);
             return satellite.degreesLong(trailGd.longitude);
          });

          return { ...p, liveLng, trails };
        } catch (e) {
          return null;
        }
      }).filter(Boolean);

      setLivePositions(updated);
      animationFrameId = requestAnimationFrame(updatePositions);
    };

    updatePositions();
    return () => cancelAnimationFrame(animationFrameId);
  }, [positions]);

  const handleMouseDown = (e) => {
    setIsDragging(true);
    setLastMouse({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e) => {
    if (!isDragging) return;
    const dx = e.clientX - lastMouse.x;
    const dy = e.clientY - lastMouse.y;
    setRotZ(z => (z + dx * 0.5) % 360);
    setRotX(x => Math.max(0, Math.min(90, x - dy * 0.5)));
    setLastMouse({ x: e.clientX, y: e.clientY });
  };

  const handleMouseUp = () => setIsDragging(false);

  const processedSats = useMemo(() => {
    const redNames = new Set();
    const yellowNames = new Set();
    events.forEach(e => {
      if (e.riskLevel === 'RED') { redNames.add(e.primaryObject.name); redNames.add(e.secondaryObject.name); }
      else if (e.riskLevel === 'YELLOW') { yellowNames.add(e.primaryObject.name); yellowNames.add(e.secondaryObject.name); }
    });

    const baseRadius = 130;
    const spacing = 50;

    return livePositions.map((p) => {
      const isRed = redNames.has(p.name);
      const isYellow = yellowNames.has(p.name);
      const color = isRed ? '#f87171' : isYellow ? '#fbbf24' : '#4ade80';
      
      let hash = 0; for(let j=0; j<p.name.length; j++) hash += p.name.charCodeAt(j);
      const ringIndex = hash % 6;
      const radius = baseRadius + ringIndex * spacing;

      return { ...p, isRed, isYellow, color, radius };
    });
  }, [livePositions, events]);

  const rings = [0, 1, 2, 3, 4, 5].map(i => 130 + i * 50);
  const bgPosX = rotZ;

  return (
    <div 
      className={`scene-viewport ${alertActive ? 'scene-alert' : ''}`}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      style={{ cursor: isDragging ? 'grabbing' : 'grab' }}
    >
      <div 
        className="world-3d" 
        style={{ transform: `rotateX(${rotX}deg) rotateZ(${rotZ}deg)` }}
      >
        {rings.map(r => (
          <div key={r} className="orbit-ring-3d" style={{ width: r*2, height: r*2, marginLeft: -r, marginTop: -r }}></div>
        ))}

        <div 
          className="earth-3d"
          style={{ 
             transform: `translate(-50%, -50%) rotateZ(${-rotZ}deg) rotateX(${-rotX}deg)`,
             backgroundPositionX: `${bgPosX}px`
          }}
        ></div>

        {processedSats.map(sat => {
          const counterRot = `rotateZ(${-sat.liveLng - rotZ}deg) rotateX(${-rotX}deg)`;
          
          return (
            <React.Fragment key={sat.name}>
              {/* Comet Trails */}
              {sat.trails.map((trailLng, i) => {
                const trailCounterRot = `rotateZ(${-trailLng - rotZ}deg) rotateX(${-rotX}deg)`;
                return (
                  <div 
                    key={`trail-${i}`}
                    className="sat-container"
                    style={{ transform: `rotateZ(${trailLng}deg) translateX(${sat.radius}px)` }}
                  >
                    <div className="sat-billboard" style={{ transform: trailCounterRot }}>
                      <div className="sat-dot" style={{ 
                        backgroundColor: sat.color, 
                        width: Math.max(1, 10 - i*1.5), 
                        height: Math.max(1, 10 - i*1.5),
                        opacity: Math.max(0, 0.8 - i*0.15),
                        boxShadow: `0 0 ${8 - i}px ${sat.color}`
                      }}></div>
                    </div>
                  </div>
                )
              })}

              {/* Main Satellite & Label */}
              <div 
                className="sat-container"
                style={{ transform: `rotateZ(${sat.liveLng}deg) translateX(${sat.radius}px)` }}
              >
                <div className="sat-billboard" style={{ transform: counterRot }}>
                  
                  {/* Flawless Isometric 3D SVG */}
                  <Satellite3D color={sat.color} />
                  
                  {(sat.isRed || sat.isYellow) && <div className="pulse-ring" style={{ borderColor: sat.color }}></div>}
                  <div className="sat-label" style={{ color: sat.color }}>{sat.name}</div>
                </div>
              </div>
            </React.Fragment>
          )
        })}
      </div>

      <div className="scene-info mono" style={{ position:'absolute', bottom: 24, left: 24, zIndex: 10, color: 'rgba(255,255,255,0.7)', pointerEvents: 'none' }}>
        <span style={{color:'var(--text-1)'}}>Precision Astrodynamics Layout</span><br/>
        <span style={{color:'var(--text-3)', fontSize:'10px'}}>True SGP4 Revolution Physics via satellite.js</span>
      </div>
    </div>
  )
}
