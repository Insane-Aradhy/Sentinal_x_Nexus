import React, { useState, useEffect, useMemo, useCallback } from 'react';
import './AsteroidTracker.css';
import {
  fetchNearEarthObjects,
  formatDistance,
  toLunarDistances,
  asteroidRiskColor,
  formatDiameter,
  formatVelocity,
} from '../services/liveData';

// ── Risk classification helpers ───────────────────────────────────────────────
function getRiskClass(neo) {
  if (neo.is_potentially_hazardous_asteroid) return 'hazard';
  const missKm = parseFloat(neo.close_approach_data?.[0]?.miss_distance?.kilometers ?? Infinity);
  if (missKm < 1_000_000)  return 'close';
  if (missKm < 5_000_000)  return 'watch';
  return 'safe';
}

function getRiskLabel(neo) {
  if (neo.is_potentially_hazardous_asteroid) return '⚠ HAZARDOUS';
  const missKm = parseFloat(neo.close_approach_data?.[0]?.miss_distance?.kilometers ?? Infinity);
  if (missKm < 1_000_000)  return '◈ CLOSE';
  if (missKm < 5_000_000)  return '◎ WATCHLIST';
  return '✓ SAFE';
}

// ── Lunar Distance Bar ────────────────────────────────────────────────────────
function LDBar({ km, color }) {
  const ld = parseFloat(toLunarDistances(km));
  // Show bar scaled to 20 LD (≈ 7.7M km) as 100%
  const pct = Math.min((ld / 20) * 100, 100);
  return (
    <div className="neo-ld-bar-wrap">
      <div className="neo-ld-bar-track">
        <div className="neo-ld-bar-fill" style={{ width: `${pct}%`, background: color }} />
      </div>
      <div className="neo-ld-bar-label">
        <span>{ld} LD</span>
        <span>20 LD max</span>
      </div>
    </div>
  );
}

// ── Expanded Detail Panel ─────────────────────────────────────────────────────
function NEODetailPanel({ neo }) {
  const approach = neo.close_approach_data?.[0] ?? {};
  const missKm   = parseFloat(approach.miss_distance?.kilometers ?? 0);
  const vel      = parseFloat(approach.relative_velocity?.kilometers_per_second ?? 0);
  const color    = asteroidRiskColor(neo);

  const allApproaches = neo.close_approach_data ?? [];

  return (
    <div className="neo-detail-panel fade-in-up">
      {/* Col 1 — Orbital */}
      <div className="neo-detail-section">
        <div className="neo-detail-section-title">Orbital Data</div>
        <div className="neo-detail-row">
          <span className="neo-detail-key">Miss distance</span>
          <span className="neo-detail-val" style={{ color }}>{formatDistance(missKm)}</span>
        </div>
        <div className="neo-detail-row">
          <span className="neo-detail-key">Lunar distances</span>
          <span className="neo-detail-val">{toLunarDistances(missKm)} LD</span>
        </div>
        <div className="neo-detail-row">
          <span className="neo-detail-key">Velocity</span>
          <span className="neo-detail-val">{vel.toFixed(2)} km/s</span>
        </div>
        <div className="neo-detail-row">
          <span className="neo-detail-key">km/h</span>
          <span className="neo-detail-val">{(vel * 3600).toLocaleString(undefined, {maximumFractionDigits: 0})} km/h</span>
        </div>
        <LDBar km={missKm} color={color} />
      </div>

      {/* Col 2 — Physical */}
      <div className="neo-detail-section">
        <div className="neo-detail-section-title">Physical Properties</div>
        <div className="neo-detail-row">
          <span className="neo-detail-key">Est. diameter (km)</span>
          <span className="neo-detail-val">{formatDiameter(neo)}</span>
        </div>
        <div className="neo-detail-row">
          <span className="neo-detail-key">Est. diameter (m)</span>
          <span className="neo-detail-val">
            {(() => {
              const d = neo.estimated_diameter?.meters;
              if (!d) return '—';
              return `${d.estimated_diameter_min.toFixed(0)} – ${d.estimated_diameter_max.toFixed(0)} m`;
            })()}
          </span>
        </div>
        <div className="neo-detail-row">
          <span className="neo-detail-key">Absolute magnitude</span>
          <span className="neo-detail-val">{neo.absolute_magnitude_h ?? '—'} H</span>
        </div>
        <div className="neo-detail-row">
          <span className="neo-detail-key">Hazardous?</span>
          <span className="neo-detail-val">
            {neo.is_potentially_hazardous_asteroid
              ? <span className="neo-hazard-flag">⚠ YES</span>
              : <span style={{ color: 'var(--green)' }}>No</span>}
          </span>
        </div>
        <div className="neo-detail-row">
          <span className="neo-detail-key">Sentry object</span>
          <span className="neo-detail-val">{neo.is_sentry_object ? 'Yes' : 'No'}</span>
        </div>
      </div>

      {/* Col 3 — Mission links */}
      <div className="neo-detail-section">
        <div className="neo-detail-section-title">References</div>
        <div className="neo-detail-row">
          <span className="neo-detail-key">NASA ID</span>
          <span className="neo-detail-val" style={{ fontSize: '11px' }}>{neo.id}</span>
        </div>
        <div className="neo-detail-row">
          <span className="neo-detail-key">SPK-ID</span>
          <span className="neo-detail-val" style={{ fontSize: '11px' }}>{neo.neo_reference_id}</span>
        </div>
        <div className="neo-detail-row">
          <span className="neo-detail-key">Approach date</span>
          <span className="neo-detail-val">{neo._approachDate}</span>
        </div>
        <div className="neo-detail-row">
          <span className="neo-detail-key">Orbiting body</span>
          <span className="neo-detail-val">{approach.orbiting_body ?? '—'}</span>
        </div>
        <div className="neo-detail-row">
          <span className="neo-detail-key">Close approaches</span>
          <span className="neo-detail-val">{allApproaches.length}</span>
        </div>
      </div>

      {/* All close approach data if multiple */}
      {allApproaches.length > 1 && (
        <div className="neo-approach-list">
          <div className="neo-detail-section-title" style={{ marginBottom: '4px' }}>All Close Approaches</div>
          {allApproaches.slice(0, 6).map((ap, i) => (
            <div className="neo-approach-item" key={i}>
              <span>{ap.close_approach_date}</span>
              <span>Miss: {formatDistance(parseFloat(ap.miss_distance?.kilometers ?? 0))}</span>
              <span>Vel: {parseFloat(ap.relative_velocity?.kilometers_per_second ?? 0).toFixed(2)} km/s</span>
              <span style={{ color: 'var(--text-3)' }}>{ap.orbiting_body}</span>
            </div>
          ))}
          {allApproaches.length > 6 && (
            <div style={{ fontSize: '11px', color: 'var(--text-3)', fontFamily: 'var(--font-mono)' }}>
              + {allApproaches.length - 6} more approaches
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── NEO Row ───────────────────────────────────────────────────────────────────
function NEORow({ neo, index, isExpanded, onToggle }) {
  const approach  = neo.close_approach_data?.[0] ?? {};
  const missKm    = parseFloat(approach.miss_distance?.kilometers ?? 0);
  const riskClass = getRiskClass(neo);
  const riskLabel = getRiskLabel(neo);
  const color     = asteroidRiskColor(neo);

  return (
    <>
      <div className={`neo-row ${isExpanded ? 'expanded' : ''}`} onClick={onToggle}>
        <span className="neo-row-idx">{index + 1}</span>

        <div className="neo-row-name">
          <span className="neo-row-name-primary">{neo.name}</span>
          <span className="neo-row-name-id">{neo.neo_reference_id}</span>
        </div>

        <span className="neo-row-date">{neo._approachDate}</span>

        <span className="neo-row-miss" style={{ color }}>
          {formatDistance(missKm)}
        </span>

        <span className="neo-row-vel">
          {formatVelocity(neo)}
        </span>

        <span className="neo-row-diam">
          {formatDiameter(neo)}
        </span>

        <span className={`neo-risk-badge ${riskClass}`}>
          {riskLabel}
        </span>
      </div>

      {isExpanded && <NEODetailPanel neo={neo} />}
    </>
  );
}

// ── Stats strip ───────────────────────────────────────────────────────────────
function StatsStrip({ neos }) {
  const hazardCount = neos.filter(n => n.is_potentially_hazardous_asteroid).length;
  const closeCount  = neos.filter(n => {
    const km = parseFloat(n.close_approach_data?.[0]?.miss_distance?.kilometers ?? Infinity);
    return km < 1_000_000 && !n.is_potentially_hazardous_asteroid;
  }).length;
  const closest = neos[0];
  const closestKm = closest
    ? parseFloat(closest.close_approach_data?.[0]?.miss_distance?.kilometers ?? 0)
    : 0;

  return (
    <div className="neo-stats-strip fade-in-up delay-1">
      <div className="neo-stat-card">
        <div className="neo-stat-label">Total NEOs this week</div>
        <div className="neo-stat-value" style={{ color: 'var(--green)' }}>{neos.length}</div>
        <div className="neo-stat-sub">Near-Earth Objects</div>
      </div>

      <div className="neo-stat-card">
        <div className="neo-stat-label">Potentially Hazardous</div>
        <div className="neo-stat-value" style={{ color: hazardCount > 0 ? 'var(--red)' : 'var(--text-3)' }}>
          {hazardCount}
        </div>
        <div className="neo-stat-sub">PHA designation</div>
      </div>

      <div className="neo-stat-card">
        <div className="neo-stat-label">Within 1M km</div>
        <div className="neo-stat-value" style={{ color: closeCount > 0 ? 'var(--yellow)' : 'var(--text-3)' }}>
          {closeCount}
        </div>
        <div className="neo-stat-sub">Close approach</div>
      </div>

      <div className="neo-stat-card">
        <div className="neo-stat-label">Closest Approach</div>
        <div className="neo-stat-value" style={{ color: asteroidRiskColor(closest ?? {}), fontSize: '20px' }}>
          {closest ? formatDistance(closestKm) : '—'}
        </div>
        <div className="neo-stat-sub">{closest ? toLunarDistances(closestKm) + ' lunar distances' : 'No data'}</div>
      </div>
    </div>
  );
}

// ── Main AsteroidTracker component ────────────────────────────────────────────
export default function AsteroidTracker() {
  const [neos,        setNeos]        = useState([]);
  const [loading,     setLoading]     = useState(true);
  const [error,       setError]       = useState(null);
  const [filter,      setFilter]      = useState('all');   // all | hazard | close | safe
  const [expandedId,  setExpandedId]  = useState(null);
  const [lastFetched, setLastFetched] = useState(null);
  const [fetching,    setFetching]    = useState(false);

  const load = useCallback(async () => {
    setFetching(true);
    setError(null);
    try {
      const data = await fetchNearEarthObjects(7);
      if (data.length === 0) {
        setError('No NEO data returned. NASA DEMO_KEY has a 30 req/hr limit — wait a moment and retry.');
      } else {
        setNeos(data);
        setLastFetched(new Date());
      }
    } catch (e) {
      setError(`Failed to fetch NEO data: ${e.message}`);
    } finally {
      setLoading(false);
      setFetching(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(() => {
    switch (filter) {
      case 'hazard': return neos.filter(n => n.is_potentially_hazardous_asteroid);
      case 'close':  return neos.filter(n => {
        const km = parseFloat(n.close_approach_data?.[0]?.miss_distance?.kilometers ?? Infinity);
        return km < 1_000_000;
      });
      case 'safe':   return neos.filter(n => {
        const km = parseFloat(n.close_approach_data?.[0]?.miss_distance?.kilometers ?? Infinity);
        return km >= 5_000_000 && !n.is_potentially_hazardous_asteroid;
      });
      default:       return neos;
    }
  }, [neos, filter]);

  const toggleRow = (id) => setExpandedId(prev => prev === id ? null : id);

  // ── Date range label ────────────────────────────────────────────────────────
  const today   = new Date().toISOString().split('T')[0];
  const endDate = new Date(Date.now() + 7 * 86_400_000).toISOString().split('T')[0];

  return (
    <div className="neo-page">

      {/* ── Header ────────────────────────────────────────────────────────── */}
      <header className="neo-header fade-in-up">
        <div className="neo-eyebrow">
          <span className="pulse-ring" />
          Live NASA NeoWs Feed · Updating
        </div>
        <h1 className="neo-title">☄️ Near-Earth Object Tracker</h1>
        <p className="neo-subtitle">
          Real-time asteroid and comet data from NASA's Near Earth Object Web Service (NeoWs).
          Objects are sourced from the JPL Small-Body Database and sorted by closest approach distance.
          All data is live — fetched directly from <code style={{ color: 'var(--blue)', fontSize: '13px' }}>api.nasa.gov</code>.
        </p>
        <div className="neo-meta-row">
          <div className="neo-meta-item">WINDOW: <span>{today} → {endDate}</span></div>
          <div className="neo-meta-item">SOURCE: <span>NASA NeoWs API</span></div>
          <div className="neo-meta-item">
            LAST SYNC: <span>{lastFetched ? lastFetched.toLocaleTimeString() : '—'}</span>
          </div>
        </div>
      </header>

      {/* ── Stats strip ───────────────────────────────────────────────────── */}
      {!loading && !error && neos.length > 0 && <StatsStrip neos={neos} />}

      {/* ── Controls ──────────────────────────────────────────────────────── */}
      {!loading && !error && neos.length > 0 && (
        <div className="neo-controls fade-in-up delay-2">
          <div className="neo-filter-group">
            {[
              { key: 'all',    label: `All (${neos.length})` },
              { key: 'hazard', label: `⚠ Hazardous (${neos.filter(n => n.is_potentially_hazardous_asteroid).length})` },
              { key: 'close',  label: `◈ Close <1M km (${neos.filter(n => parseFloat(n.close_approach_data?.[0]?.miss_distance?.kilometers ?? Infinity) < 1_000_000).length})` },
              { key: 'safe',   label: `✓ Safe (${neos.filter(n => parseFloat(n.close_approach_data?.[0]?.miss_distance?.kilometers ?? Infinity) >= 5_000_000 && !n.is_potentially_hazardous_asteroid).length})` },
            ].map(({ key, label }) => (
              <button
                key={key}
                className={`neo-filter-btn ${filter === key ? `active-${key}` : ''}`}
                onClick={() => { setFilter(key); setExpandedId(null); }}
              >
                {label}
              </button>
            ))}
          </div>

          <button
            className="neo-refresh-btn"
            onClick={load}
            disabled={fetching}
          >
            <span className={fetching ? 'spin' : ''}>↻</span>
            {fetching ? 'Fetching…' : 'Refresh'}
          </button>
        </div>
      )}

      {/* ── Loading ────────────────────────────────────────────────────────── */}
      {loading && (
        <div className="neo-loading fade-in-up">
          <div className="neo-loading-orbit" />
          <span className="neo-loading-text">Querying NASA NeoWs API…</span>
        </div>
      )}

      {/* ── Error ─────────────────────────────────────────────────────────── */}
      {error && !loading && (
        <div className="neo-error fade-in-up">
          <span>⚠</span>
          <span>{error}</span>
          <button
            className="neo-refresh-btn"
            style={{ marginLeft: 'auto' }}
            onClick={load}
            disabled={fetching}
          >
            Retry
          </button>
        </div>
      )}

      {/* ── NEO Table ─────────────────────────────────────────────────────── */}
      {!loading && filtered.length > 0 && (
        <div className="neo-table-wrap fade-in-up delay-3">
          <div className="neo-table-header">
            <div className="neo-table-title">
              <span style={{ color: 'var(--yellow)' }}>◈</span>
              Close Approach Data
              <span className="neo-count-badge">{filtered.length} objects</span>
            </div>
            <span style={{ fontSize: '11px', color: 'var(--text-3)', fontFamily: 'var(--font-mono)' }}>
              Click any row for full details
            </span>
          </div>

          {/* Column headers */}
          <div className="neo-grid-head">
            <span className="neo-grid-col-head">#</span>
            <span className="neo-grid-col-head">Object Name</span>
            <span className="neo-grid-col-head">Date</span>
            <span className="neo-grid-col-head">Miss Distance</span>
            <span className="neo-grid-col-head">Velocity</span>
            <span className="neo-grid-col-head">Diameter</span>
            <span className="neo-grid-col-head">Risk</span>
          </div>

          <div className="neo-list">
            {filtered.map((neo, i) => (
              <NEORow
                key={neo.id}
                neo={neo}
                index={i}
                isExpanded={expandedId === neo.id}
                onToggle={() => toggleRow(neo.id)}
              />
            ))}
          </div>
        </div>
      )}

      {/* ── Empty state ───────────────────────────────────────────────────── */}
      {!loading && !error && filtered.length === 0 && neos.length > 0 && (
        <div className="neo-empty fade-in-up">
          No objects match this filter.
        </div>
      )}

      {/* ── Source attribution ────────────────────────────────────────────── */}
      {!loading && neos.length > 0 && (
        <div className="neo-source-strip fade-in-up">
          <span>Data source:</span>
          <a href="https://api.nasa.gov" target="_blank" rel="noreferrer">NASA NeoWs API</a>
          <span>·</span>
          <a href="https://cneos.jpl.nasa.gov" target="_blank" rel="noreferrer">JPL CNEOS</a>
          <span>·</span>
          <span>1 LD = 384,400 km · Hazardous = PHA designation by JPL</span>
        </div>
      )}
    </div>
  );
}
