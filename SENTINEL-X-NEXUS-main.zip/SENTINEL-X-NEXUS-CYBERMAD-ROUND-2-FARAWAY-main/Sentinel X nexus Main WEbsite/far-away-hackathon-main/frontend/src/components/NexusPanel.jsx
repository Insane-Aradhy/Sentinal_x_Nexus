import { useRef, useEffect } from 'react'
import './NexusPanel.css'

const AGENTS = {
  PLANNING: { sym:'⬡', col:'#a78bfa', label:'Risk & Policy'    },
  ANOMALY:  { sym:'◈', col:'#fb923c', label:'Astrodynamics'    },
  RESPONSE: { sym:'◉', col:'#38bdf8', label:'Executive'        },
  COMMS:    { sym:'◎', col:'#4ade80', label:'System Link'       },
}

const VOTE_COL = {
  APPROVE_MANEUVER:  'var(--green)',
  ESCALATE_RED:      'var(--red)',
  CONSENSUS_EXECUTE: 'var(--blue)',
}

const VOTE_LABELS = {
  APPROVE_MANEUVER:  'APPROVE MANEUVER',
  ESCALATE_RED:      'ESCALATE — RED',
  CONSENSUS_EXECUTE: 'CONSENSUS REACHED',
}

const fmtTime = iso =>
  new Date(iso).toLocaleTimeString('en-US', {
    hour12: false, hour: '2-digit', minute: '2-digit', second:'2-digit', timeZone: 'UTC'
  }) + 'Z'

/* ── Data Card: Situation Brief ── */
function SituationCard({ data }) {
  if (!data) return null
  return (
    <div className="n-datacard n-datacard--situation">
      <div className="n-dc-title">
        <span className="n-dc-icon">📡</span>
        Situation Brief
      </div>
      <div className="n-dc-grid">
        <div className="n-dc-cell">
          <span className="n-dc-val n-dc-val--red">{(data.missM * 6.684587122e-12).toExponential(4)} AU</span>
          <span className="n-dc-key">Miss Distance</span>
        </div>
        <div className="n-dc-cell">
          <span className="n-dc-val">{(data.relVel * 6.684587122e-9).toExponential(4)} AU/s</span>
          <span className="n-dc-key">Relative Velocity</span>
        </div>
        <div className="n-dc-cell">
          <span className="n-dc-val n-dc-val--yellow">{data.prob}</span>
          <span className="n-dc-key">P(collision)</span>
        </div>
        <div className="n-dc-cell">
          <span className="n-dc-val">{data.tcaMin} min</span>
          <span className="n-dc-key">Time to TCA</span>
        </div>
        <div className="n-dc-cell n-dc-cell--wide">
          <span className="n-dc-val n-dc-val--orange">{data.impactMJ} MJ</span>
          <span className="n-dc-key">Impact Energy</span>
        </div>
      </div>
    </div>
  )
}

/* ── Data Card: Maneuver Options ── */
function ManeuverCard({ data }) {
  if (!data) return null
  const { optionA, optionB } = data
  return (
    <div className="n-datacard n-datacard--maneuver">
      <div className="n-dc-title">
        <span className="n-dc-icon">🚀</span>
        Computed Maneuver Options
      </div>
      <div className="n-dc-options">
        <div className="n-dc-option n-dc-option--a">
          <span className="n-dc-opt-label">Option A — Standard</span>
          <div className="n-dc-opt-grid">
            <div><span className="n-dc-opt-val">{optionA.strategy}</span><span className="n-dc-opt-key">Strategy</span></div>
            <div><span className="n-dc-opt-val">{optionA.deltaV.toFixed(4)} m/s</span><span className="n-dc-opt-key">Δv</span></div>
            <div><span className="n-dc-opt-val">{optionA.burnS.toFixed(1)}s</span><span className="n-dc-opt-key">Burn</span></div>
            <div><span className="n-dc-opt-val">{optionA.fuelG}g</span><span className="n-dc-opt-key">Fuel</span></div>
            <div><span className="n-dc-opt-val">{(optionA.clearanceKm * 6.684587122e-9).toExponential(4)} AU</span><span className="n-dc-opt-key">Clearance</span></div>
          </div>
        </div>
        <div className="n-dc-option n-dc-option--b">
          <span className="n-dc-opt-label">Option B — Conservative</span>
          <div className="n-dc-opt-grid">
            <div><span className="n-dc-opt-val">{optionB.strategy}</span><span className="n-dc-opt-key">Strategy</span></div>
            <div><span className="n-dc-opt-val">{optionB.deltaV.toFixed(4)} m/s</span><span className="n-dc-opt-key">Δv</span></div>
            <div><span className="n-dc-opt-val">{optionB.burnS.toFixed(1)}s</span><span className="n-dc-opt-key">Burn</span></div>
            <div><span className="n-dc-opt-val">{optionB.fuelG}g</span><span className="n-dc-opt-key">Fuel</span></div>
            <div><span className="n-dc-opt-val">{(optionB.clearanceKm * 6.684587122e-9).toExponential(4)} AU</span><span className="n-dc-opt-key">Clearance</span></div>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ── Data Card: Verdict ── */
function VerdictCard({ data }) {
  if (!data) return null
  return (
    <div className="n-datacard n-datacard--verdict">
      <div className="n-dc-title">
        <span className="n-dc-icon">⚖️</span>
        Council Verdict
      </div>
      <div className="n-dc-verdict-body">
        <div className="n-dc-verdict-row">
          <span className="n-dc-verdict-k">Decision</span>
          <span className="n-dc-verdict-v n-dc-verdict-v--decision">{data.decision.replace(/_/g, ' ')}</span>
        </div>
        <div className="n-dc-verdict-row">
          <span className="n-dc-verdict-k">Target</span>
          <span className="n-dc-verdict-v">{data.target}</span>
        </div>
        <div className="n-dc-verdict-row">
          <span className="n-dc-verdict-k">Δv</span>
          <span className="n-dc-verdict-v">{data.deltaV.toFixed(4)} m/s</span>
        </div>
        <div className="n-dc-verdict-row">
          <span className="n-dc-verdict-k">Clearance</span>
          <span className="n-dc-verdict-v">{'>'}{(data.clearanceKm * 6.684587122e-9).toExponential(4)} AU</span>
        </div>
      </div>
      {data.voteTally && (
        <div className="n-dc-tally">
          <div className="n-dc-tally-title">Consolidated Vote Tally</div>
          <div className="n-dc-tally-grid">
            <div className="n-dc-tally-circle-container">
              <div className="n-dc-tally-circle active" title="System Link (COMMS): APPROVED" style={{'--ac': '#4ade80', color: '#4ade80', borderColor: '#4ade80'}}>◎</div>
              <div className="n-dc-tally-circle active" title="Astrodynamics (ANOMALY): APPROVED" style={{'--ac': '#fb923c', color: '#fb923c', borderColor: '#fb923c'}}>◈</div>
              <div className="n-dc-tally-circle active" title="Risk & Policy (PLANNING): APPROVED" style={{'--ac': '#a78bfa', color: '#a78bfa', borderColor: '#a78bfa'}}>⬡</div>
              <div className="n-dc-tally-circle active" title="Executive (RESPONSE): APPROVED" style={{'--ac': '#38bdf8', color: '#38bdf8', borderColor: '#38bdf8'}}>◉</div>
            </div>
            <div className="n-dc-tally-summary">
              <span className="n-dc-tally-consensus">
                Consensus Reached: {data.voteTally.agree}/{data.voteTally.total} Unanimous
              </span>
              <span className="n-dc-tally-details">
                Resolved via {data.voteTally.resolvedVia} after {data.voteTally.rounds} rounds ({data.voteTally.initialDisagreements} initial objection resolved).
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

/* ── Render the right data card based on type ── */
function DataCard({ dataCard }) {
  if (!dataCard) return null
  switch (dataCard.type) {
    case 'situation_brief': return <SituationCard data={dataCard} />
    case 'maneuver_options': return <ManeuverCard data={dataCard} />
    case 'verdict':          return <VerdictCard data={dataCard} />
    default: return null
  }
}

export default function NexusPanel({ messages, simRunning, alertEvent, onClose, isFullscreen, onToggleFullscreen }) {
  const debating = simRunning && alertEvent?.riskLevel === 'RED'
  const feedRef = useRef(null)

  // Auto-scroll to bottom as new messages arrive
  useEffect(() => {
    if (feedRef.current) {
      feedRef.current.scrollTop = feedRef.current.scrollHeight
    }
  }, [messages.length])

  // Helper to figure out who is currently typing
  const getNextTypingAgent = () => {
    const realMessages = messages.filter(m => !m.isRoundMarker)
    if (realMessages.length === 0) return 'COMMS'
    const last = realMessages[realMessages.length - 1]
    if (last.agentId === 'COMMS' && last.round === 1) return 'ANOMALY'
    if (last.agentId === 'ANOMALY' && last.round === 1) return 'PLANNING'
    if (last.agentId === 'PLANNING' && last.round === 1) return 'ANOMALY'
    if (last.agentId === 'ANOMALY' && last.round === 2) return 'PLANNING'
    if (last.agentId === 'PLANNING' && last.round === 2) return 'COMMS'
    if (last.agentId === 'COMMS' && last.round === 2) return 'RESPONSE'
    return null
  }

  const nextTypingAgent = debating && messages.length < 10 ? getNextTypingAgent() : null
  const typingAgentName = nextTypingAgent ? (AGENTS[nextTypingAgent]?.label || 'Council') : 'Council'
  const typingAgentColor = nextTypingAgent ? (AGENTS[nextTypingAgent]?.col || 'var(--blue)') : 'var(--blue)'

  return (
    <>
      {/* Header */}
      <div className="panel-head">
        <div className="panel-head-left">
          <span className="tag tag-blue" style={{ width:'fit-content' }}>
            <span className="dot dot-blue" style={{width:'5px',height:'5px'}} />
            Layer 2 · Beta
          </span>
          <h2 className="panel-title" style={{ color:'var(--blue)' }}>NEXUS</h2>
          <p className="panel-desc">Multi-agent council · debate &amp; consensus</p>
        </div>
        <div className="panel-head-right">
          <span className="tag tag-muted" style={{fontSize:'10px', fontWeight:700}}>β BETA</span>
          <button className="fullscreen-btn" onClick={onToggleFullscreen} aria-label="Toggle fullscreen" title={isFullscreen ? 'Exit full view' : 'Full panel view'}>
            {isFullscreen ? '⊟' : '⊞'}
          </button>
          <button className="close-btn" onClick={onClose} aria-label="Close">✕</button>
        </div>
      </div>

      {/* Agent roster */}
      <div className="n-roster">
        {Object.entries(AGENTS).map(([id, ag]) => {
          const isTyping = nextTypingAgent === id
          return (
            <div
              key={id}
              className={`n-agent ${debating ? 'n-agent--on' : ''} ${isTyping ? 'n-agent--typing' : ''}`}
              style={{ '--ac': ag.col }}
            >
              <span className="n-agent-sym">{ag.sym}</span>
              <span className="n-agent-label">{ag.label}</span>
              <span className="n-agent-dot" />
            </div>
          )
        })}
      </div>

      {/* Tab label */}
      <div className="panel-tabs">
        <div className="ptab active n" style={{cursor:'default'}}>
          Council Debate
          <span className="ptab-count">{messages.length}</span>
        </div>
      </div>

      {/* Body */}
      <div className="panel-body" ref={feedRef}>
        {/* Idle */}
        {messages.length === 0 && !simRunning && (
          <div className="n-idle">
            <div className="n-idle-rings">
              <div className="n-ring r1" />
              <div className="n-ring r2" />
              <div className="n-ring r3" />
              <span className="n-idle-sym">⬡</span>
            </div>
            <p className="n-idle-title">Council Standby</p>
            <p className="n-idle-body">
              NEXUS activates when SENTINEL escalates a RED-level event to the multi-agent council for collective decision-making.
            </p>
            <p className="n-idle-hint">
              Press <strong>Broadcast Demo Crisis</strong> to trigger a live debate
            </p>
          </div>
        )}

        {/* Messages */}
        <div className="n-feed">
          {messages.map((msg, i) => {
            if (msg.isRoundMarker) {
              return (
                <div key={msg.id || i} className="n-round-divider">
                  <span className="n-round-divider-line" />
                  <span className="n-round-divider-text">{msg.message}</span>
                  <span className="n-round-divider-line" />
                </div>
              )
            }
            const ag = AGENTS[msg.agentId] || { sym:'◆', col:'var(--text-2)', label: msg.agentId }
            return (
              <div
                key={msg.id || i}
                className={`n-bubble ${msg.vote === 'CONSENSUS_EXECUTE' ? 'n-bubble--consensus' : ''}`}
                style={{ '--ac': ag.col }}
              >
                <div className="n-bubble-head">
                  <div className="n-bubble-who">
                    <span className="n-bubble-sym" style={{color:ag.col}}>{ag.sym}</span>
                    <span className="n-bubble-name" style={{color:ag.col}}>{msg.agentName}</span>
                  </div>
                  <div className="n-bubble-meta">
                    {msg.vote && (
                      <span className="n-bubble-vote mono" style={{color: VOTE_COL[msg.vote]||'var(--text-3)'}}>
                        {VOTE_LABELS[msg.vote] || msg.vote.replace(/_/g,' ')}
                      </span>
                    )}
                    <span className="n-bubble-ts mono">{fmtTime(msg.timestamp)}</span>
                  </div>
                </div>
                <p className="n-bubble-text">{msg.message}</p>

                {/* Rich data card */}
                {msg.dataCard && <DataCard dataCard={msg.dataCard} />}

                <div className="n-bubble-foot">
                  <div className="n-conf-bar">
                    <div className="n-conf-fill" style={{width:`${msg.confidence*100}%`, background: ag.col}} />
                  </div>
                  <span className="n-conf-label mono">{Math.round(msg.confidence*100)}%</span>
                </div>
              </div>
            )
          })}

          {debating && messages.length < 10 && (
            <div className="n-typing" style={{ '--ac': typingAgentColor }}>
              <span className="n-dot" style={{ background: typingAgentColor }} />
              <span className="n-dot" style={{ background: typingAgentColor }} />
              <span className="n-dot" style={{ background: typingAgentColor }} />
              <span className="n-typing-label" style={{ color: typingAgentColor }}>
                {typingAgentName} Agent reasoning...
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="n-footer">
        "Decisions too critical for one agent — debated and resolved by the council."
      </div>
    </>
  )
}
