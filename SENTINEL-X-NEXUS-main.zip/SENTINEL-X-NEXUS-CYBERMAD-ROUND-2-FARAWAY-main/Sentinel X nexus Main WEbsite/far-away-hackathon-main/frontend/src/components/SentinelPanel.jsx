import { useState } from 'react'
import RiskBadge from './RiskBadge'
import './SentinelPanel.css'

const fmtProb = p => {
  const e = p.toExponential(2)
  return e.replace('e-', '×10⁻')
}

const fmtTime = iso =>
  new Date(iso).toLocaleTimeString('en-US', {
    hour12: false, hour: '2-digit', minute: '2-digit', timeZone: 'UTC'
  }) + 'Z'

const DECISION = {
  NOMINAL:         { color: 'var(--green)',  label: 'Nominal'          },
  MONITOR:         { color: 'var(--yellow)', label: 'Monitor'          },
  ESCALATE_NEXUS:  { color: 'var(--blue)',   label: 'Escalate to Nexus'},
  EXECUTE_MANEUVER:{ color: 'var(--red)',    label: 'Execute Maneuver' },
}

export default function SentinelPanel({ events, actions, alertEvent, onClose, isFullscreen, onToggleFullscreen }) {
  const [tab, setTab] = useState('events')

  return (
    <>
      {/* Header */}
      <div className="panel-head">
        <div className="panel-head-left">
          <span className="tag tag-green" style={{ width:'fit-content' }}>
            <span className="dot dot-green" style={{width:'5px',height:'5px'}} />
            Layer 1 · Production
          </span>
          <h2 className="panel-title" style={{ color:'var(--green)' }}>SENTINEL</h2>
          <p className="panel-desc">Autonomous single-agent collision avoidance</p>
        </div>
        <div className="panel-head-right">
          <span className="tag tag-muted mono" style={{fontSize:'9px'}}>ZERO HUMAN INPUT</span>
          <button className="fullscreen-btn" onClick={onToggleFullscreen} aria-label="Toggle fullscreen" title={isFullscreen ? 'Exit full view' : 'Full panel view'}>
            {isFullscreen ? '⊟' : '⊞'}
          </button>
          <button className="close-btn" onClick={onClose} aria-label="Close">✕</button>
        </div>
      </div>

      {/* Alert strip */}
      {alertEvent?.riskLevel === 'RED' && (
        <div className="alert-strip">
          <span className="dot dot-red" />
          <span className="alert-strip-label">
            <strong>Critical —</strong> {alertEvent.primaryObject.name} / {alertEvent.secondaryObject.name}
          </span>
          <span className="alert-strip-val mono">{(alertEvent.metrics.missDistanceKm * 6.684587122e-9).toExponential(4)} AU</span>
        </div>
      )}

      {/* Tabs */}
      <div className="panel-tabs">
        <button
          id="stab-events"
          className={`ptab ${tab === 'events' ? 'active s' : ''}`}
          onClick={() => setTab('events')}
        >
          Events <span className="ptab-count">{events.length}</span>
        </button>
        <button
          id="stab-actions"
          className={`ptab ${tab === 'actions' ? 'active s' : ''}`}
          onClick={() => setTab('actions')}
        >
          Actions <span className="ptab-count">{actions.length}</span>
        </button>
      </div>

      {/* Body */}
      <div className="panel-body">
        {tab === 'events' && (
          <div className="s-list">
            {events.map((evt, i) => (
              <div
                key={evt.eventId}
                className={`s-row s-row--${evt.riskLevel.toLowerCase()}`}
                style={{ animationDelay: `${i*40}ms` }}
              >
                <div className="s-row-top">
                  <div className="s-objects">
                    <span className="s-primary">{evt.primaryObject.name}</span>
                    <span className="s-arrow">→</span>
                    <span className="s-secondary">{evt.secondaryObject.name}</span>
                  </div>
                  <RiskBadge level={evt.riskLevel} />
                </div>
                <div className="s-metrics">
                  <div className="sm">
                    <span className="sm-k">Miss dist</span>
                    <span className="sm-v mono">{(evt.metrics.missDistanceKm * 6.684587122e-9).toExponential(4)} AU</span>
                  </div>
                  <div className="sm">
                    <span className="sm-k">P(c)</span>
                    <span className="sm-v mono">{fmtProb(evt.metrics.collisionProbability)}</span>
                  </div>
                  <div className="sm">
                    <span className="sm-k">Vel</span>
                    <span className="sm-v mono">{(evt.metrics.relativeVelocityKmS * 6.684587122e-9).toExponential(4)} AU/s</span>
                  </div>
                  <div className="sm">
                    <span className="sm-k">TCA</span>
                    <span className="sm-v mono">{fmtTime(evt.metrics.timeOfClosestApproach)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'actions' && (
          <div className="s-list">
            {actions.map((act, i) => {
              const ds = DECISION[act.decision] || { color:'var(--text-2)', label: act.decision }
              return (
                <div key={act.actionId} className="a-row" style={{ animationDelay: `${i*50}ms` }}>
                  <div className="a-row-head">
                    <span className="a-decision mono" style={{ color: ds.color }}>
                      {act.autonomous ? '⚡ ' : ''}{ds.label}
                    </span>
                    <span className="a-ts mono">{fmtTime(act.timestamp)}</span>
                  </div>
                  <p className="a-reason">{act.reasoning}</p>
                  {act.maneuverDetails && (
                    <div className="a-maneuver">
                      {act.maneuverDetails.strategy && <span className="mono">Strategy: {act.maneuverDetails.strategy}</span>}
                      {act.maneuverDetails.deltaV !== undefined && <span className="mono">ΔV {Number(act.maneuverDetails.deltaV).toFixed(3)} m/s</span>}
                      {act.maneuverDetails.burnDurationSec !== undefined && <span className="mono">Burn {Number(act.maneuverDetails.burnDurationSec).toFixed(1)} s</span>}
                      {act.maneuverDetails.fuelCostKg !== undefined && <span className="mono">Cost {Number(act.maneuverDetails.fuelCostKg).toFixed(3)} kg</span>}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>
    </>
  )
}
