/**
 * SpaceImageGallery.jsx — Live NASA Image Gallery
 * =================================================
 * Fetches REAL images from NASA APOD (Astronomy Picture of the Day) API
 * for the last 14 days. No random Unsplash photos.
 *
 * Also pulls from NASA Earth imagery (EPIC) for satellite Earth photos.
 * API key: DEMO_KEY (no sign-up needed, 30 req/hour limit)
 */

import { useState, useEffect, useCallback } from 'react';
import './SpaceImageGallery.css';

// ── NASA API config ────────────────────────────────────────────────────────
const NASA_KEY = 'Z31bIfistkx3c2bhR3upE672zwDT56hRigeO0uop'; // Free tier: 30 req/hr. Replace with your key from api.nasa.gov

// Get last N days as YYYY-MM-DD strings
function getLastNDays(n) {
  return Array.from({ length: n }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - i);
    return d.toISOString().split('T')[0];
  });
}

function formatDisplayDate(isoStr) {
  if (!isoStr) return '';
  const d = new Date(isoStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

// ── Fetch NASA APOD for last 14 days ────────────────────────────────────────
async function fetchAPOD() {
  const endDate = new Date().toISOString().split('T')[0];
  const startDate = getLastNDays(14).at(-1);
  const url = `https://api.nasa.gov/planetary/apod?api_key=${NASA_KEY}&start_date=${startDate}&end_date=${endDate}&thumbs=true`;

  const resp = await fetch(url);
  if (!resp.ok) throw new Error(`APOD API error ${resp.status}`);
  const data = await resp.json();

  // Filter only images (not videos), reverse so newest first
  return data
    .filter(item => item.media_type === 'image')
    .reverse()
    .map(item => ({
      id: `apod-${item.date}`,
      source: 'NASA APOD',
      sourceKey: 'APOD',
      title: item.title,
      date: item.date,
      displayDate: formatDisplayDate(item.date),
      imageUrl: item.url,
      hdUrl: item.hdurl || item.url,
      instrument: item.copyright ? `Photo by ${item.copyright.replace(/\n/g,' ').trim()}` : 'NASA / ESA',
      credit: item.copyright ? item.copyright.replace(/\n/g,' ').trim() : 'NASA',
      description: item.explanation,
      category: 'Deep Space',
    }));
}

// ── Fetch NASA EPIC (Earth satellite imagery) ────────────────────────────────
async function fetchEPIC() {
  // Get available dates
  const datesUrl = `https://api.nasa.gov/EPIC/api/natural/available?api_key=${NASA_KEY}`;
  const datesResp = await fetch(datesUrl);
  if (!datesResp.ok) throw new Error(`EPIC dates error ${datesResp.status}`);
  const dates = await datesResp.json();

  // Take the 3 most recent dates
  const recentDates = dates.slice(-3).reverse();

  const allImages = [];
  for (const date of recentDates) {
    const imgsUrl = `https://api.nasa.gov/EPIC/api/natural/date/${date}?api_key=${NASA_KEY}`;
    const imgsResp = await fetch(imgsUrl);
    if (!imgsResp.ok) continue;
    const imgs = await imgsResp.json();

    // Take up to 2 images per date
    for (const img of imgs.slice(0, 2)) {
      const [year, month, day] = date.split('-');
      const imageUrl = `https://epic.gsfc.nasa.gov/archive/natural/${year}/${month}/${day}/png/${img.image}.png`;
      allImages.push({
        id: `epic-${img.identifier}`,
        source: 'DSCOVR EPIC',
        sourceKey: 'EPIC',
        title: `Earth from Deep Space — ${formatDisplayDate(date)}`,
        date: date,
        displayDate: formatDisplayDate(date),
        imageUrl,
        hdUrl: imageUrl,
        instrument: 'EPIC Camera (DSCOVR satellite at L1)',
        credit: 'NASA / NOAA DSCOVR EPIC',
        description: `Full-disk Earth photograph taken by the EPIC (Earth Polychromatic Imaging Camera) aboard the DSCOVR spacecraft, positioned at the Earth-Sun Lagrange point 1 (L1), approximately 1.5 million km from Earth. Coordinates: Lat ${img.centroid_coordinates?.lat?.toFixed(2)}°, Lon ${img.centroid_coordinates?.lon?.toFixed(2)}°. This image was captured at ${img.date?.slice(11, 19)} UTC.`,
        captureTime: img.date?.slice(11, 16) + ' UTC',
        coords: img.centroid_coordinates,
        category: 'Earth Observation',
        sunAngle: img.sun_j2000_position,
      });
    }
  }
  return allImages;
}

// ── Source config ─────────────────────────────────────────────────────────────
const SOURCES = {
  ALL: {
    label: 'All Feeds',
    icon: '✦',
    color: '#60a5fa',
    desc: 'All NASA live image feeds',
  },
  APOD: {
    label: 'NASA APOD',
    icon: '⬡',
    color: '#a78bfa',
    desc: 'Astronomy Picture of the Day — curated by NASA scientists',
    badge: 'Daily Release',
  },
  EPIC: {
    label: 'DSCOVR · EPIC',
    icon: '◉',
    color: '#34d399',
    desc: 'Full-disk Earth photos from L1 orbit, 1.5M km away',
    badge: 'Earth Obs.',
  },
};

// ── Main Component ─────────────────────────────────────────────────────────────
export default function SpaceImageGallery() {
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeSource, setActiveSource] = useState('ALL');
  const [activeImage, setActiveImage] = useState(null);
  const [hdLoaded, setHdLoaded] = useState(false);
  const [loadingPhase, setLoadingPhase] = useState('Contacting NASA servers…');

  // Load all feeds
  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      setError(null);
      const results = [];

      try {
        setLoadingPhase('Fetching APOD archive…');
        const apod = await fetchAPOD();
        if (!cancelled) results.push(...apod);
      } catch (e) {
        console.warn('APOD fetch failed:', e.message);
      }

      try {
        setLoadingPhase('Loading EPIC Earth imagery…');
        const epic = await fetchEPIC();
        if (!cancelled) results.push(...epic);
      } catch (e) {
        console.warn('EPIC fetch failed:', e.message);
      }

      if (cancelled) return;

      if (results.length === 0) {
        setError('NASA API rate limit reached (DEMO_KEY: 30 req/hr). Replace NASA_KEY in SpaceImageGallery.jsx with your free key from api.nasa.gov, or try again in an hour.');
      }

      // Sort: EPIC first (Earth obs), then APOD by date desc
      results.sort((a, b) => {
        if (a.sourceKey === 'EPIC' && b.sourceKey !== 'EPIC') return -1;
        if (b.sourceKey === 'EPIC' && a.sourceKey !== 'EPIC') return 1;
        return b.date.localeCompare(a.date);
      });

      setImages(results);
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, []);

  // Keyboard nav for lightbox
  useEffect(() => {
    if (!activeImage) return;
    const filtered = images.filter(img => activeSource === 'ALL' || img.sourceKey === activeSource);
    const idx = filtered.findIndex(i => i.id === activeImage.id);
    const handler = (e) => {
      if (e.key === 'Escape') setActiveImage(null);
      if (e.key === 'ArrowRight') setActiveImage(filtered[(idx + 1) % filtered.length]);
      if (e.key === 'ArrowLeft') setActiveImage(filtered[(idx - 1 + filtered.length) % filtered.length]);
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [activeImage, images, activeSource]);

  const filtered = images.filter(img => activeSource === 'ALL' || img.sourceKey === activeSource);

  const apodCount = images.filter(i => i.sourceKey === 'APOD').length;
  const epicCount = images.filter(i => i.sourceKey === 'EPIC').length;

  const openLightbox = (img) => {
    setActiveImage(img);
    setHdLoaded(false);
  };

  return (
    <div className="gal-shell">

      {/* ── Left sidebar ── */}
      <aside className="gal-sidebar">
        <div className="gal-sidebar-top">
          <div className="gal-sidebar-eyebrow">
            <span className="gal-live-pip" />
            LIVE NASA FEEDS
          </div>
          <h2 className="gal-sidebar-title">Image Archive</h2>
          <p className="gal-sidebar-sub">Real images. No AI generation.</p>
        </div>

        <nav className="gal-source-nav">
          {Object.entries(SOURCES).map(([key, src]) => {
            const count = key === 'ALL' ? images.length : images.filter(i => i.sourceKey === key).length;
            return (
              <button
                key={key}
                className={`gal-src-btn ${activeSource === key ? 'active' : ''}`}
                style={activeSource === key ? {
                  '--src-color': src.color,
                  borderColor: src.color + '55',
                  background: src.color + '0f',
                } : { '--src-color': src.color }}
                onClick={() => setActiveSource(key)}
              >
                <div className="gal-src-top">
                  <span className="gal-src-icon" style={{ color: src.color }}>{src.icon}</span>
                  <span className="gal-src-label">{src.label}</span>
                  <span className="gal-src-count mono" style={{ color: src.color }}>{count}</span>
                </div>
                <p className="gal-src-desc">{src.desc}</p>
                {src.badge && (
                  <span className="gal-src-badge" style={{ color: src.color, borderColor: src.color + '44' }}>
                    {src.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Stats block */}
        <div className="gal-sidebar-stats">
          <div className="gal-stat-row">
            <span className="gal-stat-label">APOD images</span>
            <span className="gal-stat-val mono">{apodCount}</span>
          </div>
          <div className="gal-stat-row">
            <span className="gal-stat-label">EPIC Earth photos</span>
            <span className="gal-stat-val mono" style={{ color: '#34d399' }}>{epicCount}</span>
          </div>
          <div className="gal-stat-row">
            <span className="gal-stat-label">Coverage window</span>
            <span className="gal-stat-val mono">14 days</span>
          </div>
        </div>

        <div className="gal-sidebar-footer">
          <div className="gal-footer-api">
            <span className="gal-footer-dot" style={{ background: '#34d399' }} />
            <span>api.nasa.gov</span>
          </div>
          <p className="gal-footer-note">Images © NASA / ESA / CSA</p>
        </div>
      </aside>

      {/* ── Main content ── */}
      <main className="gal-main">

        {/* Header */}
        <header className="gal-header">
          <div className="gal-header-left">
            <h1 className="gal-title">
              {SOURCES[activeSource].label}
              <span className="gal-title-count">{filtered.length} images</span>
            </h1>
            <p className="gal-header-desc">
              {activeSource === 'ALL' && 'Live NASA data feeds — APOD daily releases and DSCOVR EPIC Earth observations from the past 14 days.'}
              {activeSource === 'APOD' && 'NASA Astronomy Picture of the Day — each image selected and annotated by professional astronomers.'}
              {activeSource === 'EPIC' && 'Full-disk Earth photographs captured by the EPIC camera on DSCOVR, orbiting at the L1 Lagrange point.'}
            </p>
          </div>
          <div className="gal-header-right">
            <div className="gal-api-badge">
              <span className="gal-live-pip" />
              <span className="mono">NASA API</span>
            </div>
          </div>
        </header>

        {/* Loading state */}
        {loading && (
          <div className="gal-loading">
            <div className="gal-spinner-wrap">
              <div className="gal-spinner" />
              <div className="gal-spinner-ring" />
            </div>
            <p className="gal-loading-text">{loadingPhase}</p>
            <p className="gal-loading-sub">Querying NASA open data APIs…</p>
          </div>
        )}

        {/* Error state */}
        {!loading && error && (
          <div className="gal-error">
            <div className="gal-error-icon">⚠</div>
            <h3 className="gal-error-title">API Rate Limit</h3>
            <p className="gal-error-msg">{error}</p>
            <a href="https://api.nasa.gov" target="_blank" rel="noopener noreferrer" className="gal-error-link">
              Get free NASA API key ↗
            </a>
          </div>
        )}

        {/* Grid */}
        {!loading && filtered.length > 0 && (
          <div className="gal-grid">
            {filtered.map((img, i) => (
              <GalleryCard
                key={img.id}
                img={img}
                index={i}
                onClick={() => openLightbox(img)}
              />
            ))}
          </div>
        )}

        {!loading && !error && filtered.length === 0 && (
          <div className="gal-empty">No images available for this feed yet.</div>
        )}
      </main>

      {/* ── Lightbox ── */}
      {activeImage && (
        <Lightbox
          img={activeImage}
          allImages={filtered}
          onClose={() => setActiveImage(null)}
          onNav={(img) => { setActiveImage(img); setHdLoaded(false); }}
          hdLoaded={hdLoaded}
          onHdLoad={() => setHdLoaded(true)}
        />
      )}
    </div>
  );
}

// ── Gallery Card ─────────────────────────────────────────────────────────────
function GalleryCard({ img, index, onClick }) {
  const [imgLoaded, setImgLoaded] = useState(false);
  const [imgError, setImgError] = useState(false);
  const src = SOURCES[img.sourceKey] || SOURCES.APOD;

  return (
    <article
      className="gal-card"
      onClick={onClick}
      style={{ '--card-color': src.color, animationDelay: `${Math.min(index * 40, 400)}ms` }}
    >
      <div className="gal-card-img-wrap">
        {!imgLoaded && !imgError && (
          <div className="gal-card-skeleton" />
        )}
        {imgError ? (
          <div className="gal-card-img-error">
            <span>Image unavailable</span>
          </div>
        ) : (
          <img
            src={img.imageUrl}
            alt={img.title}
            loading="lazy"
            className={`gal-card-img ${imgLoaded ? 'loaded' : ''}`}
            onLoad={() => setImgLoaded(true)}
            onError={() => setImgError(true)}
          />
        )}
        <div className="gal-card-overlay" />
        <div className="gal-card-top-badges">
          <span className="gal-card-src" style={{ background: src.color + 'dd', color: '#000' }}>
            {img.sourceKey}
          </span>
          {img.sourceKey === 'EPIC' && (
            <span className="gal-card-earth-badge">🌍 EARTH OBS</span>
          )}
        </div>
        <div className="gal-card-footer-overlay">
          <div className="gal-card-date mono">{img.displayDate}</div>
          {img.captureTime && <div className="gal-card-time mono">{img.captureTime}</div>}
        </div>
      </div>
      <div className="gal-card-body">
        <h3 className="gal-card-title">{img.title}</h3>
        <p className="gal-card-instrument">{img.instrument}</p>
        <p className="gal-card-desc">
          {img.description.length > 120 ? img.description.slice(0, 120) + '…' : img.description}
        </p>
      </div>
    </article>
  );
}

// ── Lightbox ──────────────────────────────────────────────────────────────────
function Lightbox({ img, allImages, onClose, onNav, hdLoaded, onHdLoad }) {
  const idx = allImages.findIndex(i => i.id === img.id);
  const src = SOURCES[img.sourceKey] || SOURCES.APOD;
  const hasPrev = idx > 0;
  const hasNext = idx < allImages.length - 1;

  return (
    <div className="gal-lightbox-overlay" onClick={onClose}>
      <div className="gal-lightbox" onClick={e => e.stopPropagation()}>

        {/* Close */}
        <button className="gal-lb-close" onClick={onClose}>✕</button>

        {/* Nav arrows */}
        {hasPrev && (
          <button className="gal-lb-nav prev" onClick={() => onNav(allImages[idx - 1])}>‹</button>
        )}
        {hasNext && (
          <button className="gal-lb-nav next" onClick={() => onNav(allImages[idx + 1])}>›</button>
        )}

        {/* Image pane */}
        <div className="gal-lb-img-pane">
          <img
            src={img.hdUrl || img.imageUrl}
            alt={img.title}
            className="gal-lb-img"
            onLoad={onHdLoad}
          />
          {img.sourceKey === 'EPIC' && img.coords && (
            <div className="gal-lb-coords mono">
              📍 {Math.abs(img.coords.lat).toFixed(2)}°{img.coords.lat >= 0 ? 'N' : 'S'} &nbsp;
              {Math.abs(img.coords.lon).toFixed(2)}°{img.coords.lon >= 0 ? 'E' : 'W'}
            </div>
          )}
        </div>

        {/* Detail pane */}
        <div className="gal-lb-detail">
          {/* Source + date header */}
          <div className="gal-lb-meta-row">
            <span className="gal-lb-src-chip" style={{ background: src.color + 'dd', color: '#000' }}>
              {img.sourceKey}
            </span>
            <span className="gal-lb-date mono">{img.displayDate}</span>
            {img.captureTime && (
              <span className="gal-lb-time mono">{img.captureTime}</span>
            )}
            <span className="gal-lb-counter mono">{idx + 1} / {allImages.length}</span>
          </div>

          <h2 className="gal-lb-title">{img.title}</h2>

          {/* Technical specs */}
          <div className="gal-lb-section">
            <div className="gal-lb-section-label">Instrument / Source</div>
            <div className="gal-lb-spec-grid">
              <div className="gal-lb-spec">
                <span className="gal-lb-spec-key">Captured by</span>
                <span className="gal-lb-spec-val mono">{img.instrument}</span>
              </div>
              <div className="gal-lb-spec">
                <span className="gal-lb-spec-key">Date</span>
                <span className="gal-lb-spec-val mono">{img.date}</span>
              </div>
              {img.captureTime && (
                <div className="gal-lb-spec">
                  <span className="gal-lb-spec-key">Time (UTC)</span>
                  <span className="gal-lb-spec-val mono">{img.captureTime}</span>
                </div>
              )}
              {img.coords && (
                <>
                  <div className="gal-lb-spec">
                    <span className="gal-lb-spec-key">Center Lat</span>
                    <span className="gal-lb-spec-val mono">{img.coords.lat?.toFixed(3)}°</span>
                  </div>
                  <div className="gal-lb-spec">
                    <span className="gal-lb-spec-key">Center Lon</span>
                    <span className="gal-lb-spec-val mono">{img.coords.lon?.toFixed(3)}°</span>
                  </div>
                </>
              )}
              <div className="gal-lb-spec">
                <span className="gal-lb-spec-key">Credit</span>
                <span className="gal-lb-spec-val">{img.credit}</span>
              </div>
              <div className="gal-lb-spec">
                <span className="gal-lb-spec-key">Category</span>
                <span className="gal-lb-spec-val">{img.category}</span>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="gal-lb-section">
            <div className="gal-lb-section-label">Scientific Notes</div>
            <p className="gal-lb-desc">{img.description}</p>
          </div>

          {/* HD link */}
          {img.hdUrl && (
            <a
              href={img.hdUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="gal-lb-hd-link"
            >
              View full-resolution image ↗
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
