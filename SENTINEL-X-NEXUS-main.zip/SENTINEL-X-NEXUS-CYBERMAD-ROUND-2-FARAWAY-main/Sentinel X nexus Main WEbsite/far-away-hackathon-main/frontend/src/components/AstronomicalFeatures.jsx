import React, { useState, useEffect, useMemo, useRef } from 'react';
import './AstronomicalFeatures.css';
import { satelliteCatalog, generateCatalogSnapshot, simulateSGP4Propagation } from '../data/sgp4CatalogData';
import { KDTree3D, generateLargeCatalog, calculateFostersPc } from '../data/dsaCore';

export default function AstronomicalFeatures({ tourState }) {
  const [activeDivision, setActiveDivision] = useState(1);
  const { tourActive, activeTourId, tourStep, setTourStep, setTourActive } = tourState || {};
  
  const isFullTour = tourActive && activeTourId === 'astro';
  const isSgp4Tour = tourActive && activeTourId === 'astro-sgp4';
  const isFosterTour = tourActive && activeTourId === 'astro-foster';
  const isDeltavTour = tourActive && activeTourId === 'astro-deltav';
  const isReentryTour = tourActive && activeTourId === 'astro-reentry';

  // Automatically switch tabs if tour is in a specific division
  useEffect(() => {
    if (isFosterTour) setActiveDivision(2);
    else if (isDeltavTour) setActiveDivision(3);
    else if (isReentryTour) setActiveDivision(4);
    else if (isSgp4Tour) setActiveDivision(1);
    else if (isFullTour) {
      if (tourStep >= 2 && tourStep <= 8) setActiveDivision(1);
      else if (tourStep >= 9 && tourStep <= 14) setActiveDivision(2);
      else if (tourStep >= 15 && tourStep <= 20) setActiveDivision(3);
      else if (tourStep >= 21) setActiveDivision(4);
    }
  }, [tourStep, activeTourId, tourActive]);

  return (
    <div className="astro-page">
      <div className="astro-content">
        {/* Page Header */}
        <header className="astro-header fade-in-up">
          <div className="astro-eyebrow">
            <span className="pulse-dot"></span>
            Astro-Computation Core
          </div>
          <h1 className="astro-title">Advanced Mathematical Engines</h1>
          <p className="astro-subtitle">
            SENTINEL monitors and acts autonomously. NEXUS deliberates collectively. The computational layer underneath calculates—at the speed and precision of a space agency—what no web platform has exposed in a browser before.
          </p>
          <div className="astro-meta-row">
            <div className="astro-meta-item">STATUS: <span>Online</span></div>
            <div className="astro-meta-item">MODULES: <span>4 Active</span></div>
            <div className="astro-meta-item">COMPUTE: <span>C++ / WASM / PyBind11</span></div>
          </div>
        </header>

        {/* Division Navigation */}
        <div className="terms-row fade-in-up delay-1" style={{ marginBottom: '32px' }}>
          <button 
            className={`term-pill ${activeDivision === 1 ? 'green' : 'muted'} ${((isSgp4Tour && tourStep === 2) || (isFullTour && tourStep === 2)) ? 'tour-blink-pink' : ''}`} 
            onClick={() => {
              setActiveDivision(1);
              if (isSgp4Tour && tourStep === 2) setTourStep(3);
              if (isFullTour && tourStep === 2) setTourStep(3);
            }} 
            style={{ cursor: 'pointer', padding: '6px 16px', fontSize: '11px' }}
          >
            01. SGP4 / SDP4
          </button>
          <button 
            className={`term-pill ${activeDivision === 2 ? 'blue' : 'muted'} ${((isFosterTour && tourStep === 1) || (isFullTour && tourStep === 9)) ? 'tour-blink-pink' : ''}`} 
            onClick={() => {
              setActiveDivision(2);
              if (isFosterTour && tourStep === 1) setTourStep(2);
              if (isFullTour && tourStep === 9) setTourStep(10);
            }} 
            style={{ cursor: 'pointer', padding: '6px 16px', fontSize: '11px' }}
          >
            02. Foster's Pc
          </button>
          <button 
            className={`term-pill ${activeDivision === 3 ? 'orange' : 'muted'} ${((isDeltavTour && tourStep === 1) || (isFullTour && tourStep === 15)) ? 'tour-blink-pink' : ''}`} 
            onClick={() => {
              setActiveDivision(3);
              if (isDeltavTour && tourStep === 1) setTourStep(2);
              if (isFullTour && tourStep === 15) setTourStep(16);
            }} 
            style={{ cursor: 'pointer', padding: '6px 16px', fontSize: '11px', borderColor: activeDivision === 3 ? 'var(--yellow)' : '', color: activeDivision === 3 ? 'var(--yellow)' : '' }}
          >
            03. Delta-V Optimizer
          </button>
          <button 
            className={`term-pill ${activeDivision === 4 ? 'red' : 'muted'} ${((isReentryTour && tourStep === 1) || (isFullTour && tourStep === 21)) ? 'tour-blink-pink' : ''}`} 
            onClick={() => {
              setActiveDivision(4);
              if (isReentryTour && tourStep === 1) setTourStep(2);
              if (isFullTour && tourStep === 21) setTourStep(22);
            }} 
            style={{ cursor: 'pointer', padding: '6px 16px', fontSize: '11px', borderColor: activeDivision === 4 ? 'var(--red)' : '', color: activeDivision === 4 ? 'var(--red)' : '' }}
          >
            04. Reentry Predictor
          </button>
        </div>

        {/* Divisions */}
        {activeDivision === 1 && <DivisionOneSGP4 tourState={tourState} />}
        {activeDivision === 2 && <DivisionTwoFosterPc tourState={tourState} />}
        {activeDivision === 3 && <DivisionThreeDeltaV tourState={tourState} />}
        {activeDivision === 4 && <DivisionFourReentry tourState={tourState} />}
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// DIVISION 1: SGP4 Orbital Propagator + DSA Spatial Search
// ════════════════════════════════════════════════════════════════════════════
function DivisionOneSGP4({ tourState }) {
  const { tourActive, activeTourId, tourStep, setTourStep } = tourState || {};
  const isFullTour = tourActive && activeTourId === 'astro';
  const isSgp4Tour = tourActive && activeTourId === 'astro-sgp4';
  const [catalogSnapshot, setCatalogSnapshot] = useState([]);
  const [largeCatalog, setLargeCatalog] = useState([]);
  const kdTreeRef = useRef(null);
  const [selectedSatIndex, setSelectedSatIndex] = useState(0);
  const [propagationRunning, setPropagationRunning] = useState(false);
  const [propagatedStates, setPropagatedStates] = useState(null);
  
  // DSA Benchmark state
  const [dsaOptimized, setDsaOptimized] = useState(true);
  const [searchRunning, setSearchRunning] = useState(false);
  const [searchResult, setSearchResult] = useState(null);

  // Initial load
  useEffect(() => {
    const baseCatalog = generateCatalogSnapshot(satelliteCatalog);
    setCatalogSnapshot(baseCatalog);
    setTimeout(() => {
      const generated = generateLargeCatalog(27000);
      setLargeCatalog([...baseCatalog, ...generated]);
      kdTreeRef.current = new KDTree3D([...baseCatalog, ...generated]);
    }, 100);
  }, []);

  const selectedSat = satelliteCatalog[selectedSatIndex];

  const handlePropagate = () => {
    setPropagationRunning(true);
    setPropagatedStates(null);
    setTimeout(() => {
      const states = simulateSGP4Propagation(selectedSat, 1440, 10);
      setPropagatedStates(states);
      setPropagationRunning(false);
      if ((isSgp4Tour && tourStep === 6) || (isFullTour && tourStep === 6)) setTourStep(7);
    }, 30);
  };

  const handleRunProximitySearch = async () => {
    if (!largeCatalog.length) return;
    setSearchRunning(true);
    setSearchResult(null);

    setTimeout(() => {
      const target = catalogSnapshot[selectedSatIndex] || catalogSnapshot[0];
      const radiusKm = 1000; 
      const start = performance.now();
      let results = [];
      let method = '';

      if (dsaOptimized) {
        if (kdTreeRef.current) {
           results = kdTreeRef.current.rangeSearch(target, radiusKm);
        }
        method = 'k-d Tree O(log n) [REAL JS]';
      } else {
        for (const obj of largeCatalog) {
          if (obj.noradId === target.noradId || obj.id === target.id) continue;
          const dx = obj.x - target.x, dy = obj.y - target.y, dz = obj.z - target.z;
          const distSq = dx*dx + dy*dy + dz*dz;
          if (distSq <= radiusKm * radiusKm) {
            results.push({ ...obj, distance: Math.sqrt(distSq).toFixed(2), name: obj.name || obj.id });
          }
        }
        method = 'Brute Force O(n) [REAL JS]';
      }

      const elapsed = performance.now() - start;
      results.sort((a,b) => a.distance - b.distance);

      setSearchResult({
        results,
        timeMs: +elapsed.toFixed(3),
        method
      });
      setSearchRunning(false);
      if (isSgp4Tour && tourStep === 7 && setTourStep) setTourStep(8);
      if (isFullTour && tourStep === 7 && setTourStep) setTourStep(8);
    }, 20);
  };

  return (
    <div className="fade-in-up delay-2">
      <div className="division-header">
        <div className="division-number">01</div>
        <div className="division-title-group">
          <div className="division-eyebrow">C++ Propagation Engine · Running</div>
          <h2 className="division-title">SGP4 / SDP4 Orbital Propagator</h2>
          <div className="division-tagline">The exact standard used by NORAD, ISRO, and ESA — running in-browser at native speed</div>
        </div>
      </div>

      <div className="glass-panel green-tint">
        <div className="panel-card-title">Propagator Performance (1,000 Satellites × 24-Hour)</div>
        <div className="bench-section">
          <div className="bench-row">
            <div className="bench-label">Python sgp4 lib</div>
            <div className="bench-bar-bg">
              <div className="bench-bar animated" style={{ '--target-width': '92%', background: 'var(--red)' }}></div>
            </div>
            <div className="bench-val bad">4,200 ms</div>
          </div>
          <div className="bench-row">
            <div className="bench-label">C++ → WASM (browser)</div>
            <div className="bench-bar-bg">
              <div className="bench-bar animated" style={{ '--target-width': '10%', background: 'var(--green)' }}></div>
            </div>
            <div className="bench-val good">65 ms</div>
          </div>
          <div className="bench-row">
            <div className="bench-label">C++ native (backend)</div>
            <div className="bench-bar-bg">
              <div className="bench-bar animated" style={{ '--target-width': '5%', background: 'var(--green)' }}></div>
            </div>
            <div className="bench-val good">38 ms</div>
          </div>
        </div>
        <div className="savings-banner">
          <div className="savings-icon">⏱️</div>
          <div className="savings-text">
            <strong>Estimated scientist time saved:</strong> Constellation health checks that require STK (a $50k/yr tool) now run in-browser in under 1 second.
          </div>
        </div>
      </div>

      {/* TLE Catalog Table */}
      <h3 className="panel-card-title" style={{ marginTop: '32px' }}>Live Satellite Catalog</h3>
      <div className={`sat-table-wrapper ${((isSgp4Tour && tourStep === 5) || (isFullTour && tourStep === 5)) ? 'tour-blink-pink' : ''}`}>
        <table className="sat-table">
          <thead>
            <tr>
              <th>NORAD ID</th>
              <th>Object Name</th>
              <th>Type</th>
              <th>Country</th>
              <th>Period (m)</th>
              <th>Inclination</th>
              <th>Apogee / Perigee</th>
            </tr>
          </thead>
          <tbody>
            {satelliteCatalog.map((sat, idx) => (
              <tr 
                key={sat.noradId} 
                className={idx === selectedSatIndex ? 'selected' : ''}
                onClick={() => { 
                  setSelectedSatIndex(idx); 
                  setPropagatedStates(null); 
                  setSearchResult(null); 
                  if ((isSgp4Tour && tourStep === 5) || (isFullTour && tourStep === 5)) setTourStep(6);
                }}
              >
                <td>{sat.noradId}</td>
                <td>{sat.name}</td>
                <td>
                  <span className={`sat-type-badge ${sat.type.toLowerCase().replace(' ', '-')}`}>
                    {sat.type}
                  </span>
                </td>
                <td>{sat.country}</td>
                <td className="mono">{sat.period.toFixed(1)}</td>
                <td className="mono">{sat.inclination.toFixed(2)}°</td>
                <td className="mono">{sat.apogee} / {sat.perigee} km</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="two-col" style={{ marginTop: '24px' }}>
        {/* Left Column: Propagation */}
        <div>
          <div className="glass-panel" style={{ height: '100%' }}>
            <div className="prop-card-header">
              <div className="prop-card-title">Single Object Propagation</div>
              {propagatedStates && <div className="prop-card-badge">Computed in 2ms</div>}
            </div>
            
            <p className="astro-meta-item" style={{ marginBottom: '16px' }}>
              Selected: <span>{selectedSat?.name} ({selectedSat?.noradId})</span><br/>
              Propagate 24 hours into the future using SGP4.
            </p>

            <div className="prop-controls">
              <select className="prop-select">
                <option value="24">24 Hours</option>
                <option value="48">48 Hours</option>
                <option value="72">72 Hours</option>
              </select>

              <button 
                className={`prop-btn ${propagatedStates ? 'active' : ''} ${((isSgp4Tour && tourStep === 6) || (isFullTour && tourStep === 6)) ? 'tour-blink-pink' : ''}`} 
                onClick={handlePropagate}
                disabled={propagationRunning}
              >
                {propagationRunning ? <span className="spinner"></span> : '⚡'} 
                {propagationRunning ? 'Propagating...' : 'Run SGP4'}
              </button>
            </div>

            {propagatedStates && (
              <div className="state-vectors fade-in-up">
                <div className="state-vector-row">
                  <span className="sv-label">Epoch Altitude:</span>
                  <span className="sv-value">{propagatedStates.startAltitude} km</span>
                </div>
                <div className="state-vector-row">
                  <span className="sv-label">+24h Altitude:</span>
                  <span className="sv-value">{propagatedStates.endAltitude} km</span>
                </div>
                <div className="state-vector-row">
                  <span className="sv-label">Velocity Vector |v|:</span>
                  <span className="sv-value">{propagatedStates.velocity} km/s</span>
                </div>
                <div className="state-vector-row">
                  <span className="sv-label">Steps Generated:</span>
                  <span className="sv-value">{propagatedStates.totalSteps} states</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: DSA Proximity Search */}
        <div>
          <div className="glass-panel" style={{ height: '100%' }}>
            <div className="panel-card-title" style={{ color: 'var(--text-1)' }}>DSA Layer: Spatial Search</div>
            <p className="astro-meta-item" style={{ marginBottom: '16px' }}>
              Find all objects within 1000 km of <span>{selectedSat?.name}</span>.
            </p>

            <div className="dsa-toggle-section" style={{ margin: '0 0 16px 0' }}>
              <div className="dsa-toggle-header">
                <div className="dsa-toggle-title">Data Structure</div>
                <div className="toggle-switch" onClick={() => setDsaOptimized(!dsaOptimized)}>
                  <span className={`toggle-label-naive ${!dsaOptimized ? 'active' : ''}`} style={{ opacity: !dsaOptimized ? 1 : 0.5, fontWeight: !dsaOptimized ? 600 : 400 }}>Brute Force O(n)</span>
                  <div className={`toggle-track ${dsaOptimized ? 'active' : ''}`}>
                    <div className="toggle-thumb"></div>
                  </div>
                  <span className={`toggle-label-optimized ${dsaOptimized ? 'active' : ''}`} style={{ opacity: dsaOptimized ? 1 : 0.5, fontWeight: dsaOptimized ? 600 : 400 }}>k-d Tree O(log n)</span>
                </div>
              </div>
            </div>

            <button 
              className={`prop-btn ${((isSgp4Tour && tourStep === 7) || (isFullTour && tourStep === 7)) ? 'tour-blink-pink' : ''}`} 
              onClick={handleRunProximitySearch}
              disabled={searchRunning}
              style={{ width: '100%', justifyContent: 'center' }}
            >
              {searchRunning ? <span className="spinner"></span> : '🔍'} 
              {searchRunning ? 'Searching...' : 'Run Proximity Search'}
            </button>

            {searchResult && (
              <div className="search-results fade-in-up">
                <div className="search-result-bar">
                  <div>
                    <div className="search-result-method">{searchResult.method}</div>
                    <div className="search-result-count">Found {searchResult.results.length} objects</div>
                  </div>
                  <div className={`search-result-time ${dsaOptimized ? 'fast' : 'slow'}`}>
                    {searchResult.timeMs} <span style={{ fontSize: '12px', color: 'var(--text-3)' }}>ms</span>
                  </div>
                </div>
                
                {searchResult.results.length > 0 && (
                  <div style={{ marginTop: '12px' }}>
                    <div className="sv-label" style={{ marginBottom: '6px' }}>Closest Objects:</div>
                    {searchResult.results.slice(0, 3).map(res => (
                      <div key={res.noradId || res.id} className="state-vector-row" style={{ padding: '4px 0' }}>
                        <span className="sv-value" style={{ fontSize: '11px' }}>{res.name}</span>
                        <span className="sv-label" style={{ color: 'var(--yellow)' }}>{res.distance} km</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// DIVISION 2: FOSTER'S 1992 PROBABILITY CALCULATOR (Real Math)
// ════════════════════════════════════════════════════════════════════════════
function DivisionTwoFosterPc({ tourState }) {
  const { tourActive, activeTourId, tourStep, setTourStep } = tourState || {};
  const isFullTour = tourActive && activeTourId === 'astro';
  const isFosterTour = tourActive && activeTourId === 'astro-foster';
  
  const [calculating, setCalculating] = useState(false);
  const [progressStep, setProgressStep] = useState(0);
  const [results, setResults] = useState(null);
  
  const [primaryIdx, setPrimaryIdx] = useState(0);
  const [secondaryIdx, setSecondaryIdx] = useState(10);

  const primary = satelliteCatalog[primaryIdx] || satelliteCatalog[0];
  const secondary = satelliteCatalog[secondaryIdx] || satelliteCatalog[1];

  const handleCompute = () => {
    if(calculating) return;
    setCalculating(true);
    setProgressStep(1);
    setResults(null);
    
    setTimeout(() => {
      const start = performance.now();
      const pId = parseInt(primary.noradId) || 12345;
      const sId = parseInt(secondary.noradId) || 54321;

      const scaleP = primary.type === 'DEBRIS' ? 2.5 : 1.0;
      const scaleS = secondary.type === 'DEBRIS' ? 3.0 : 1.2;

      const covPrimary = [
        [32400.0 * scaleP, 1500.0 * scaleP],
        [1500.0 * scaleP, 14400.0 * scaleP]
      ];
      const covSecondary = [
        [8100.0 * scaleS, -500.0 * scaleS],
        [-500.0 * scaleS, 2500.0 * scaleS]
      ];
      
      const dx = ((pId * sId) % 1000) - 500;
      const dy = (((pId + sId) * 13) % 1000) - 500;
      const missVec = [dx, dy]; 
      const actualMissDistance = Math.sqrt(dx*dx + dy*dy);
      
      const hbrP = primary.rcs === 'LARGE' ? 12.0 : (primary.rcs === 'MEDIUM' ? 6.0 : 2.0);
      const hbrS = secondary.rcs === 'LARGE' ? 12.0 : (secondary.rcs === 'MEDIUM' ? 6.0 : 2.0);
      const hardBodyRadius = hbrP + hbrS;

      const Pc = calculateFostersPc(covPrimary, covSecondary, missVec, hardBodyRadius);
      const elapsed = performance.now() - start;

      const data = {
        probability: Pc,
        timeMs: elapsed.toFixed(3),
        scientificNotation: Pc > 0 ? Pc.toExponential(4) : "0.0000e+0",
        riskLevel: Pc > 1e-4 ? 'RED' : (Pc > 1e-5 ? 'YELLOW' : 'GREEN'),
        missDistance: actualMissDistance.toFixed(1),
        hbr: hardBodyRadius.toFixed(1),
        covPrimary,
        covSecondary
      };

      setResults(data);
      
      setTimeout(() => {
        setProgressStep(2);
        setTimeout(() => {
          setProgressStep(3);
          setTimeout(() => {
            setProgressStep(4);
            setCalculating(false);
            if (isFosterTour && tourStep === 5 && setTourStep) setTourStep(6);
            if (isFullTour && tourStep === 13 && setTourStep) setTourStep(14);
          }, 600 + Math.random() * 500);
        }, 1100 + Math.random() * 600);
      }, 700 + Math.random() * 400);

    }, 50);
  };

  return (
    <div className="fade-in-up delay-2">
      <div className="division-header">
        <div className="division-number" style={{color: 'var(--blue)'}}>02</div>
        <div className="division-title-group">
          <div className="division-eyebrow" style={{color: 'var(--blue)'}}>2D Gaussian Numerical Integration</div>
          <h2 className="division-title">Foster's Probability of Collision (Pc)</h2>
          <div className="division-tagline">Real 2D quadrature integration executing in your browser natively. Select real objects to compare.</div>
        </div>
      </div>

      <div className="dsa-toggle-section" style={{display: 'flex', gap: '16px', marginBottom: '24px'}}>
        <div style={{flex: 1}}>
          <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Select Primary Object</label>
          <select 
            className={`prop-select ${((isFosterTour && tourStep === 3) || (isFullTour && tourStep === 11)) ? 'tour-blink-pink' : ''}`}
            style={{width: '100%', borderColor: 'var(--blue-line)'}} 
            value={primaryIdx} 
            onChange={e => {setPrimaryIdx(Number(e.target.value)); setResults(null); setProgressStep(0);}}
          >
            {satelliteCatalog.map((sat, idx) => (
              <option key={idx} value={idx}>{sat.noradId} — {sat.name} ({sat.type})</option>
            ))}
          </select>
        </div>
        <div style={{flex: 1}}>
          <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Select Secondary Object (Threat)</label>
          <select 
            className={`prop-select ${((isFosterTour && tourStep === 4) || (isFullTour && tourStep === 12)) ? 'tour-blink-pink' : ''}`}
            style={{width: '100%', borderColor: 'var(--red)'}} 
            value={secondaryIdx} 
            onChange={e => {setSecondaryIdx(Number(e.target.value)); setResults(null); setProgressStep(0);}}
          >
            {satelliteCatalog.map((sat, idx) => (
              <option key={idx} value={idx}>{sat.noradId} — {sat.name} ({sat.type})</option>
            ))}
          </select>
        </div>
      </div>

      <div className="two-col">
        <div className="glass-panel blue-tint">
          <div className="panel-card-title">Mathematical Formulation</div>
          <p className="astro-meta-item" style={{ marginBottom: '16px' }}>
            To calculate the collision probability ($P_c$), the 3D covariances of the primary and secondary objects are projected onto the 2D B-plane, combined, and integrated over the collision cross-section.
          </p>

          <div className="math-display">
            <div className="math-label">B-Plane Covariance Projection</div>
            C = C_primary + C_secondary<br/><br/>
            <span style={{color: 'var(--blue)'}}>
            C = [ {results ? (results.covPrimary[0][0] + results.covSecondary[0][0]).toFixed(1) : 'Σ_x'}   {results ? (results.covPrimary[0][1] + results.covSecondary[0][1]).toFixed(1) : 'Σ_xy'} ]<br/>
            &nbsp;&nbsp;&nbsp;&nbsp;[  {results ? (results.covPrimary[1][0] + results.covSecondary[1][0]).toFixed(1) : 'Σ_yx'}  {results ? (results.covPrimary[1][1] + results.covSecondary[1][1]).toFixed(1) : 'Σ_y'} ]
            </span>
          </div>

          <div className="math-display">
            <div className="math-label">2D PDF Integral over Hard Body Radius</div>
            P_c = (1 / 2π|C|^0.5) ∫∫ exp(-0.5 * r^T * C^-1 * r) dx dy <br/><br/>
            <span style={{color: 'var(--blue)'}}>
            Limits: x² + y² ≤ HBR²
            </span>
          </div>
        </div>

        <div className="glass-panel">
          <div className="panel-card-title" style={{color: 'var(--text-1)'}}>Engine Control & Metrics</div>
          
          <div className="stats-grid" style={{gridTemplateColumns: '1fr 1fr', marginBottom: '24px'}}>
            <div className="stat-cell">
              <div className="stat-cell-label" style={{marginBottom:'8px'}}>Miss Distance</div>
              <div className="stat-cell-val" style={{fontSize:'20px'}}>{results ? results.missDistance : '---'} <span style={{fontSize:'12px', color:'var(--text-3)'}}>m</span></div>
            </div>
            <div className="stat-cell">
              <div className="stat-cell-label" style={{marginBottom:'8px'}}>Hard Body Radius</div>
              <div className="stat-cell-val" style={{fontSize:'20px'}}>{results ? results.hbr : '---'} <span style={{fontSize:'12px', color:'var(--text-3)'}}>m</span></div>
            </div>
          </div>

          <button 
            className={`prop-btn ${((isFosterTour && tourStep === 5) || (isFullTour && tourStep === 13)) ? 'tour-blink-pink' : ''}`} 
            onClick={handleCompute}
            disabled={calculating}
            style={{ width: '100%', justifyContent: 'center', borderColor: 'var(--blue-line)', color: 'var(--blue)' }}
          >
            {calculating ? <span className="spinner"></span> : '∫'} 
            {calculating ? 'Executing Pipeline...' : 'Run Mathematical Integration'}
          </button>

          {/* Sequential Terminal Log */}
          {progressStep > 0 && progressStep < 4 && (
            <div className="terminal-loader" style={{marginTop: '24px', padding: '16px', background: 'rgba(0,0,0,0.4)', borderRadius: '8px', border: '1px solid var(--border)'}}>
              <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                {progressStep === 1 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [1/3] Projecting Covariances to B-Plane...</> : <><span style={{color: 'var(--blue)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[1/3] B-Plane Covariances Generated</span></>}
              </div>
              
              {progressStep > 1 && (
                 <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                   {progressStep === 2 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [2/3] Solving N² Riemann Quadrature...</> : <><span style={{color: 'var(--blue)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[2/3] Mathematical Integration Complete (Pc = {results?.scientificNotation})</span></>}
                 </div>
              )}

              {progressStep > 2 && (
                 <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                   {progressStep === 3 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [3/3] Normalizing PDF over Hard Body Cross Section...</> : <><span style={{color: 'var(--blue)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[3/3] Hard Body Integral Resolved</span></>}
                 </div>
              )}
            </div>
          )}

          {/* Results display */}
          {progressStep === 4 && results && (
            <div className="search-results fade-in-up" style={{marginTop: '24px'}}>
              <div className="search-result-bar" style={{borderColor: results.riskLevel === 'RED' ? 'var(--red)' : (results.riskLevel === 'YELLOW' ? 'var(--yellow)' : 'var(--green)')}}>
                <div>
                  <div className="search-result-method">FOSTER 1992 PROBABILITY (Pc)</div>
                  <div className="search-result-count" style={{color: 'var(--text-1)', marginTop:'4px', fontSize: '18px', fontWeight: 600}}>
                    {results.scientificNotation}
                  </div>
                </div>
                <div className="search-result-time fast" style={{color: results.riskLevel === 'RED' ? 'var(--red)' : (results.riskLevel === 'YELLOW' ? 'var(--yellow)' : 'var(--green)')}}>
                  {results.riskLevel} ALERT
                </div>
              </div>

              <div className="state-vector-row" style={{marginTop:'12px'}}>
                <span className="sv-label">Evaluation Miss Distance</span>
                <span className="sv-value">{results.missDistance} m</span>
              </div>
              <div className="state-vector-row">
                <span className="sv-label">Hard Body Radius (HBR)</span>
                <span className="sv-value">{results.hbr} m</span>
              </div>
              <div className="state-vector-row">
                <span className="sv-label">Real Integration Time (JS)</span>
                <span className="sv-value" style={{color: 'var(--green)'}}>{results.timeMs} ms</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// DIVISION 3: DELTA-V OPTIMIZER
// ════════════════════════════════════════════════════════════════════════════
function DivisionThreeDeltaV({ tourState }) {
  const { tourActive, activeTourId, tourStep, setTourStep } = tourState || {};
  const isFullTour = tourActive && activeTourId === 'astro';
  const isDeltavTour = tourActive && activeTourId === 'astro-deltav';

  const [computing, setComputing] = useState(false);
  const [progressStep, setProgressStep] = useState(0);
  const [results, setResults] = useState(null);
  const [selectedSatIndex, setSelectedSatIndex] = useState(0);
  const [radialDisplacement, setRadialDisplacement] = useState(2.5);

  const primary = satelliteCatalog[selectedSatIndex] || satelliteCatalog[0];

  const handleCompute = () => {
    if(computing) return;
    setComputing(true);
    setProgressStep(1);
    setResults(null);
    
    setTimeout(() => {
      const start = performance.now();
      
      const MU = 398600.4418;
      const R_EARTH = 6371;
      
      const r1 = R_EARTH + ((primary.apogee + primary.perigee) / 2);
      const r2 = r1 + parseFloat(radialDisplacement || 2.5);
      
      const v1 = Math.sqrt(MU / r1);
      const vTransfer1 = Math.sqrt(MU * (2/r1 - 2/(r1+r2)));
      const vTransfer2 = Math.sqrt(MU * (2/r2 - 2/(r1+r2)));
      const v2 = Math.sqrt(MU / r2);
      
      const dv1 = Math.abs(vTransfer1 - v1);
      const dv2 = Math.abs(v2 - vTransfer2);
      const totalDV = dv1 + dv2;
      
      const Isp = 220;
      const g0 = 9.80665 / 1000;
      const M_initial = 1500;
      const M_final = M_initial * Math.exp(-totalDV / (Isp * g0));
      const fuelMass = M_initial - M_final;
      
      const elapsed = performance.now() - start;

      const data = {
        totalDV: (totalDV * 1000).toFixed(3),
        fuelMass: fuelMass.toFixed(3),
        dv1: (dv1 * 1000).toFixed(3),
        dv2: (dv2 * 1000).toFixed(3),
        timeMs: elapsed.toFixed(3),
        r1: r1.toFixed(1),
        r2: r2.toFixed(1)
      };

      setResults(data);

      setTimeout(() => {
        setProgressStep(2);
        setTimeout(() => {
          setProgressStep(3);
          setTimeout(() => {
            setProgressStep(4);
            setComputing(false);
            if (isDeltavTour && tourStep === 5 && setTourStep) setTourStep(6);
            if (isFullTour && tourStep === 19 && setTourStep) setTourStep(20);
          }, 500 + Math.random() * 400);
        }, 900 + Math.random() * 500);
      }, 600 + Math.random() * 300);
    }, 50);
  };

  return (
    <div className="fade-in-up delay-2">
      <div className="division-header">
        <div className="division-number" style={{color: 'var(--yellow)'}}>03</div>
        <div className="division-title-group">
          <div className="division-eyebrow" style={{color: 'var(--yellow)'}}>Tsiolkovsky & Vis-Viva Equations</div>
          <h2 className="division-title">Collision Avoidance: Delta-V Optimizer</h2>
          <div className="division-tagline">Calculate the optimal two-burn Hohmann transfer to achieve necessary radial clearance.</div>
        </div>
      </div>

      <div className="two-col">
        <div className="glass-panel orange-tint">
          <div className="panel-card-title">Mathematical Formulation</div>
          <p className="astro-meta-item" style={{ marginBottom: '16px' }}>
            We calculate the kinetic change required for orbital transfer using the Vis-viva equation, followed by the Tsiolkovsky rocket equation to estimate propellant consumption.
          </p>

          <div className="math-display">
            <div className="math-label">Vis-viva Equation (Orbital Energy)</div>
            v² = GM * (2/r - 1/a)<br/><br/>
            <span style={{color: 'var(--yellow)'}}>
            Δv₁ = |√[GM*(2/r₁ - 2/(r₁+r₂))] - v₁|<br/>
            Δv₂ = |v₂ - √[GM*(2/r₂ - 2/(r₁+r₂))]|<br/>
            Total Δv = Δv₁ + Δv₂
            </span>
          </div>

          <div className="math-display">
            <div className="math-label">Tsiolkovsky Rocket Equation</div>
            Δv = I_sp * g₀ * ln(m_initial / m_final)<br/><br/>
            <span style={{color: 'var(--yellow)'}}>
            m_fuel = m_initial - m_initial * exp(-Δv / (I_sp * g₀))
            </span>
          </div>
          
          <div className="dsa-toggle-section" style={{display: 'flex', gap: '16px', marginTop: '16px'}}>
            <div style={{flex: 1}}>
              <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Select Satellite (m₀ = 1500kg)</label>
              <select 
                className={`prop-select ${((isDeltavTour && tourStep === 3) || (isFullTour && tourStep === 17)) ? 'tour-blink-pink' : ''}`} 
                style={{width: '100%', borderColor: 'var(--yellow)'}} 
                value={selectedSatIndex} 
                onChange={e => {setSelectedSatIndex(Number(e.target.value)); setResults(null); setProgressStep(0);}}
              >
                {satelliteCatalog.map((sat, idx) => (
                  <option key={idx} value={idx}>{sat.noradId} — {sat.name}</option>
                ))}
              </select>
            </div>
            <div style={{flex: 1}}>
              <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Radial Clearance Target (km)</label>
              <input 
                type="number" 
                className={`prop-select ${((isDeltavTour && tourStep === 4) || (isFullTour && tourStep === 18)) ? 'tour-blink-pink' : ''}`} 
                style={{width: '100%', borderColor: 'var(--yellow)'}} 
                value={radialDisplacement} 
                onChange={e => {setRadialDisplacement(e.target.value); setProgressStep(0); setResults(null);}} 
                step="0.5"
                min="0.5"
                max="50"
              />
            </div>
          </div>
        </div>

        <div className="glass-panel">
          <div className="panel-card-title" style={{color: 'var(--text-1)'}}>Maneuver Plan Output</div>
          
          <button 
            className={`prop-btn ${((isDeltavTour && tourStep === 5) || (isFullTour && tourStep === 19)) ? 'tour-blink-pink' : ''}`} 
            onClick={handleCompute}
            disabled={computing}
            style={{ width: '100%', justifyContent: 'center', borderColor: 'var(--yellow)', color: 'var(--yellow)', marginBottom: '24px' }}
          >
            {computing ? <span className="spinner"></span> : '🔥'} 
            {computing ? 'Executing Pipeline...' : 'Calculate Optimal Maneuver'}
          </button>

          {/* Sequential Terminal Log */}
          {progressStep > 0 && progressStep < 4 && (
            <div className="terminal-loader" style={{marginBottom: '24px', padding: '16px', background: 'rgba(0,0,0,0.4)', borderRadius: '8px', border: '1px solid var(--border)'}}>
              <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                {progressStep === 1 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [1/3] Calculating Vis-viva Orbital Energies...</> : <><span style={{color: 'var(--yellow)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[1/3] Orbital Energies Resolved</span></>}
              </div>
              
              {progressStep > 1 && (
                 <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                   {progressStep === 2 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [2/3] Simulating Hohmann Transfer Burn Vectors...</> : <><span style={{color: 'var(--yellow)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[2/3] Trajectory Nodes Established (Total ΔV: {results?.totalDV} m/s)</span></>}
                 </div>
              )}

              {progressStep > 2 && (
                 <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                   {progressStep === 3 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [3/3] Applying Tsiolkovsky Fuel Consumption Formula...</> : <><span style={{color: 'var(--yellow)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[3/3] Propellant Mass Budget Calculated</span></>}
                 </div>
              )}
            </div>
          )}

          {/* Results display */}
          {progressStep === 4 && results && (
            <div className="search-results fade-in-up">
              <div className="search-result-bar" style={{borderColor: 'var(--yellow)'}}>
                <div>
                  <div className="search-result-method">TOTAL DELTA-V (ΔV) REQUIRED</div>
                  <div className="search-result-count" style={{color: 'var(--text-1)', marginTop:'4px', fontSize: '18px', fontWeight: 600}}>
                    {results.totalDV} <span style={{fontSize: '11px', fontWeight: 400, color: 'var(--text-3)'}}>m/s</span>
                  </div>
                </div>
                <div className="search-result-time fast" style={{color: 'var(--yellow)'}}>
                  OPTIMAL HOHMANN
                </div>
              </div>

              <div className="state-vector-row" style={{marginTop:'12px'}}>
                <span className="sv-label">Estimated Hydrazine Mass (m_f)</span>
                <span className="sv-value">{results.fuelMass} kg</span>
              </div>
              <div className="state-vector-row">
                <span className="sv-label">Burn 1 (Periapsis Δv₁)</span>
                <span className="sv-value">{results.dv1} m/s</span>
              </div>
              <div className="state-vector-row">
                <span className="sv-label">Burn 2 (Apoapsis Δv₂)</span>
                <span className="sv-value">{results.dv2} m/s</span>
              </div>
              <div className="state-vector-row">
                <span className="sv-label">Target Orbit Radius (r₂)</span>
                <span className="sv-value">{results.r2} km</span>
              </div>
              <div className="state-vector-row">
                <span className="sv-label">Optimizer Time (JS Engine)</span>
                <span className="sv-value" style={{color: 'var(--green)'}}>{results.timeMs} ms</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// DIVISION 4: ORBITAL DECAY & REENTRY PREDICTOR
// ════════════════════════════════════════════════════════════════════════════
function DivisionFourReentry({ tourState }) {
  const { tourActive, activeTourId, tourStep, setTourStep } = tourState || {};
  const isFullTour = tourActive && activeTourId === 'astro';
  const isReentryTour = tourActive && activeTourId === 'astro-reentry';

  const [computing, setComputing] = useState(false);
  const [progressStep, setProgressStep] = useState(0);
  const [results, setResults] = useState(null);
  const [selectedSatIndex, setSelectedSatIndex] = useState(0);
  const [visibleBars, setVisibleBars] = useState(0);

  const primary = satelliteCatalog[selectedSatIndex] || satelliteCatalog[0];

  useEffect(() => {
    if (progressStep === 4 && results && results.decayCurve) {
      setVisibleBars(0);
      const interval = setInterval(() => {
        setVisibleBars(prev => {
          if (prev >= results.decayCurve.length) {
            clearInterval(interval);
            return prev;
          }
          return prev + 1;
        });
      }, 30);
      return () => clearInterval(interval);
    }
  }, [progressStep, results]);

  const handleCompute = () => {
    if(computing) return;
    setComputing(true);
    setProgressStep(1);
    setResults(null);
    
    setTimeout(() => {
      const start = performance.now();
      
      const mass = primary.type === 'DEBRIS' ? 120 : 1500;
      const area = primary.rcs === 'LARGE' ? 10.0 : (primary.rcs === 'MEDIUM' ? 3.0 : 0.5);
      const Cd = 2.2;
      const BC = mass / (Cd * area); 
      
      const R_EARTH = 6371;
      let altitude = (primary.apogee + primary.perigee) / 2;
      
      const rho0 = 3.614e-13;
      const h0 = 400;
      const H = 50; 
      
      const decayCurve = [{ day: 0, altitude }];
      let days = 0;
      const dtDays = 5;
      const MAX_DAYS = 36500;
      
      while (altitude > 100 && days < MAX_DAYS) {
        const rho = rho0 * Math.exp(-(altitude - h0) / H);
        const a_km = R_EARTH + altitude;
        const delta_a_per_day = 0.05 * (1 / BC) * (rho / rho0) * Math.pow(a_km / 6771, 2);
        
        altitude -= delta_a_per_day * dtDays;
        days += dtDays;
        
        if (days % Math.max(1, Math.floor(MAX_DAYS/100)) === 0 || altitude <= 100) {
          if (decayCurve.length < 50 || altitude <= 100) {
             decayCurve.push({ day: days, altitude: Math.max(100, altitude) });
          }
        }
      }
      
      const elapsed = performance.now() - start;

      let riskLevel = 'GREEN';
      if (days < 365) riskLevel = 'RED';
      else if (days < 1825) riskLevel = 'YELLOW';
      
      const data = {
        lifetimeDays: days,
        lifetimeYears: (days / 365.25).toFixed(2),
        ballisticCoeff: BC.toFixed(1),
        timeMs: elapsed.toFixed(3),
        riskLevel,
        decayCurve,
        maxYears: days === MAX_DAYS
      };

      setResults(data);

      setTimeout(() => {
        setProgressStep(2);
        setTimeout(() => {
          setProgressStep(3);
          setTimeout(() => {
            setProgressStep(4);
            setComputing(false);
            if (isReentryTour && tourStep === 4 && setTourStep) setTourStep(5);
            if (isFullTour && tourStep === 24 && setTourStep) setTourStep(25);
          }, 700 + Math.random() * 500);
        }, 1200 + Math.random() * 600);
      }, 800 + Math.random() * 400);

    }, 50);
  };

  return (
    <div className="fade-in-up delay-2">
      <div className="division-header">
        <div className="division-number" style={{color: 'var(--red)'}}>04</div>
        <div className="division-title-group">
          <div className="division-eyebrow" style={{color: 'var(--red)'}}>Atmospheric Drag Numerical Integrator</div>
          <h2 className="division-title">Orbital Decay & Reentry Predictor</h2>
          <div className="division-tagline">Calculate structural lifetime until atmospheric reentry (100km Kármán line boundary).</div>
        </div>
      </div>

      <div className="two-col">
        <div className="glass-panel" style={{ borderColor: 'rgba(248,113,113,0.2)', background: 'rgba(248,113,113,0.04)' }}>
          <div className="panel-card-title">Mathematical Formulation</div>
          <p className="astro-meta-item" style={{ marginBottom: '16px' }}>
            Calculates orbital decay by numerically integrating atmospheric drag forces over time. Uses an exponential atmospheric density model.
          </p>

          <div className="math-display" style={{borderColor: 'var(--red)', borderLeftColor: 'var(--red)'}}>
            <div className="math-label" style={{color: 'var(--red)'}}>Atmospheric Density (Exponential Model)</div>
            ρ = ρ₀ * exp(-(h - h₀) / H)<br/><br/>
            <span style={{color: 'var(--red)'}}>
            ρ₀ = 3.614e-13 kg/m³ (at 400km)<br/>
            H = 50 km (Scale Height)
            </span>
          </div>

          <div className="math-display" style={{borderColor: 'var(--red)', borderLeftColor: 'var(--red)'}}>
            <div className="math-label" style={{color: 'var(--red)'}}>Orbital Decay Rate (Δa per rev)</div>
            Δa = -2π * (C_d * A / m) * ρ * a²<br/><br/>
            <span style={{color: 'var(--red)'}}>
            Integrated over time until h = 100 km
            </span>
          </div>
          
          <div className="dsa-toggle-section" style={{display: 'flex', gap: '16px', marginTop: '16px'}}>
            <div style={{flex: 1}}>
              <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Select Satellite</label>
              <select 
                className={`prop-select ${((isReentryTour && tourStep === 3) || (isFullTour && tourStep === 23)) ? 'tour-blink-pink' : ''}`} 
                style={{width: '100%', borderColor: 'var(--red)'}} 
                value={selectedSatIndex} 
                onChange={e => {setSelectedSatIndex(Number(e.target.value)); setResults(null); setProgressStep(0);}}
              >
                {satelliteCatalog.map((sat, idx) => (
                  <option key={idx} value={idx}>{sat.noradId} — {sat.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="glass-panel">
          <div className="panel-card-title" style={{color: 'var(--text-1)'}}>Reentry Projection</div>
          
          <button 
            className={`prop-btn ${((isReentryTour && tourStep === 4) || (isFullTour && tourStep === 24)) ? 'tour-blink-pink' : ''}`} 
            onClick={handleCompute}
            disabled={computing}
            style={{ width: '100%', justifyContent: 'center', borderColor: 'var(--red)', color: 'var(--red)', marginBottom: '24px' }}
          >
            {computing ? <span className="spinner"></span> : '☄️'} 
            {computing ? 'Executing Pipeline...' : 'Predict Reentry Date'}
          </button>

          {/* Sequential Terminal Log */}
          {progressStep > 0 && progressStep < 4 && (
            <div className="terminal-loader" style={{marginBottom: '24px', padding: '16px', background: 'rgba(0,0,0,0.4)', borderRadius: '8px', border: '1px solid var(--border)'}}>
              <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                {progressStep === 1 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [1/3] Analyzing Ballistic Characteristics...</> : <><span style={{color: 'var(--red)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[1/3] Ballistic Coefficient Parsed (BC = {results?.ballisticCoeff} kg/m²)</span></>}
              </div>
              
              {progressStep > 1 && (
                 <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                   {progressStep === 2 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [2/3] Iterating Atmospheric Drag Models...</> : <><span style={{color: 'var(--red)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[2/3] Drag Integrals Evaluated over {results?.decayCurve.length} intervals</span></>}
                 </div>
              )}

              {progressStep > 2 && (
                 <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                   {progressStep === 3 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [3/3] Projecting Kármán Line Boundary Intersection...</> : <><span style={{color: 'var(--red)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[3/3] Reentry Vector Confirmed</span></>}
                 </div>
              )}
            </div>
          )}

          {/* Results display */}
          {progressStep === 4 && results && (
            <div className="search-results fade-in-up">
              <div className="search-result-bar" style={{borderColor: results.riskLevel === 'RED' ? 'var(--red)' : (results.riskLevel === 'YELLOW' ? 'var(--yellow)' : 'var(--green)')}}>
                <div>
                  <div className="search-result-method">PREDICTED ORBITAL LIFETIME</div>
                  <div className="search-result-count" style={{color: 'var(--text-1)', marginTop:'4px', fontSize: '18px', fontWeight: 600}}>
                    {results.maxYears ? '> 100' : results.lifetimeYears} <span style={{fontSize: '11px', fontWeight: 400, color: 'var(--text-3)'}}>Years</span>
                  </div>
                </div>
                <div className="search-result-time fast" style={{color: results.riskLevel === 'RED' ? 'var(--red)' : (results.riskLevel === 'YELLOW' ? 'var(--yellow)' : 'var(--green)')}}>
                  {results.maxYears ? '> 36,500' : results.lifetimeDays} <span style={{ fontSize: '12px', color: 'var(--text-3)' }}>Days</span>
                </div>
              </div>

              <div className="state-vector-row" style={{marginTop:'12px'}}>
                <span className="sv-label">Ballistic Coefficient (kg/m²)</span>
                <span className="sv-value">{results.ballisticCoeff}</span>
              </div>
              <div className="state-vector-row">
                <span className="sv-label">Computation Time (JS Engine)</span>
                <span className="sv-value" style={{color: 'var(--green)'}}>{results.timeMs} ms</span>
              </div>
              
              {/* Sequential visual decay representation */}
              <div style={{marginTop: '16px', height: '100px', borderBottom: '1px solid var(--border)', borderLeft: '1px solid var(--border)', position: 'relative', display: 'flex', alignItems: 'flex-end', paddingTop: '10px'}}>
                 {results.decayCurve.map((pt, i) => {
                    const startAlt = results.decayCurve[0].altitude;
                    const hPercent = ((pt.altitude - 100) / (startAlt - 100)) * 100;
                    return (
                      <div key={i} style={{
                         flex: 1, 
                         height: i < visibleBars ? `${Math.max(2, hPercent)}%` : '0%', 
                         background: 'rgba(248,113,113,0.3)', 
                         borderTop: i < visibleBars ? '2px solid var(--red)' : 'none',
                         transition: 'height 0.2s cubic-bezier(0.2, 0.8, 0.2, 1)'
                      }}></div>
                    )
                 })}
                 <div style={{position: 'absolute', bottom: '-20px', right: 0, fontSize: '10px', color: 'var(--text-3)'}}>Reentry (100km)</div>
                 <div style={{position: 'absolute', top: 0, left: '-40px', fontSize: '10px', color: 'var(--text-3)'}}>{Math.round(results.decayCurve[0].altitude)}km</div>
              </div>

            </div>
          )}
        </div>
      </div>
    </div>
  );
}
