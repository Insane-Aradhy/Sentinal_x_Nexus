import re

with open('AstronomicalFeatures.jsx', 'r', encoding='utf-8') as f:
    content = f.read()

# Replace handleRunProximitySearch logic
search_replace = '''
      setResults(data);

      setTimeout(() => {
        setProgressStep(2);
        setTimeout(() => {
          setProgressStep(3);
          setTimeout(() => {
            setProgressStep(4);
            setCalculating(false);
            
            // Advance tour AFTER calculation finishes
            if (isSgp4Tour && tourStep === 6 && setTourStep) setTourStep(7);
            if (isFullTour && tourStep === 7 && setTourStep) setTourStep(8);
            
          }, 400 + Math.random() * 300);
        }, 800 + Math.random() * 400);
      }, 500 + Math.random() * 300);
'''
content = re.sub(r"      setResults\(data\);\s*// Uneven organic timings.*?\s*}, 500 \+ Math\.random\(\) \* 300\);", search_replace.strip(), content, flags=re.DOTALL)


# Replace handleCompute (Foster's Pc)
foster_replace = '''
      setResults(data);

      setTimeout(() => {
        setProgressStep(2);
        setTimeout(() => {
          setProgressStep(3);
          setTimeout(() => {
            setProgressStep(4);
            setCalculating(false);
            
            // Advance tour AFTER calculation finishes
            if (isFosterTour && tourStep === 3 && setTourStep) setTourStep(4);
            if (isFullTour && tourStep === 13 && setTourStep) setTourStep(14);
            
          }, 600 + Math.random() * 500);
        }, 1100 + Math.random() * 600);
      }, 700 + Math.random() * 400);
'''
content = re.sub(r"      setResults\(data\);\s*// Uneven organic timings.*?\s*}, 700 \+ Math\.random\(\) \* 400\);", foster_replace.strip(), content, count=1, flags=re.DOTALL)


# Replace handleCalculate (Delta-V)
deltav_replace = '''
      setResults(data);

      setTimeout(() => {
        setProgressStep(2);
        setTimeout(() => {
          setProgressStep(3);
          setTimeout(() => {
            setProgressStep(4);
            setComputing(false);
            
            // Advance tour AFTER calculation finishes
            if (isDeltavTour && tourStep === 3 && setTourStep) setTourStep(4);
            if (isFullTour && tourStep === 17 && setTourStep) setTourStep(18);
            
          }, 500 + Math.random() * 400);
        }, 900 + Math.random() * 500);
      }, 600 + Math.random() * 300);
'''
content = re.sub(r"      setResults\(data\);\s*(if \(isFosterTour.*?)?\s*setTimeout\(\(\) => \{\s*setProgressStep\(2\).*?\s*}, 600 \+ Math\.random\(\) \* 300\);", deltav_replace.strip(), content, count=1, flags=re.DOTALL)


# Replace handlePredict (Reentry)
reentry_replace = '''
      setResults(data);

      setTimeout(() => {
        setProgressStep(2);
        setTimeout(() => {
          setProgressStep(3);
          setTimeout(() => {
            setProgressStep(4);
            setComputing(false);
            
            // Advance tour AFTER calculation finishes
            if (isReentryTour && tourStep === 3 && setTourStep) setTourStep(4);
            if (isFullTour && tourStep === 21 && setTourStep) setTourStep(22);
            
          }, 700 + Math.random() * 500);
        }, 1200 + Math.random() * 600);
      }, 800 + Math.random() * 400);
'''
content = re.sub(r"      setResults\(data\);\s*(if \(isFosterTour.*?)?(if \(isReentryTour.*?)?\s*setTimeout\(\(\) => \{\s*setProgressStep\(2\).*?\s*}, 800 \+ Math\.random\(\) \* 400\);", reentry_replace.strip(), content, count=1, flags=re.DOTALL)


# Fix the button highlight blink classes for the new steps
content = content.replace("isSgp4Tour && tourStep === 5", "isSgp4Tour && tourStep === 6")
content = content.replace("isFullTour && tourStep === 6", "isFullTour && tourStep === 7") # Proximity Search btn
content = content.replace("isFullTour && tourStep === 5", "isFullTour && tourStep === 6") # SGP4 btn

# Foster btn
content = content.replace("(isFullTour && tourStep === 10)", "(isFullTour && tourStep === 13)")

# DeltaV btn
content = content.replace("(isFullTour && tourStep === 12)", "(isFullTour && tourStep === 17)")

# Reentry btn
content = content.replace("(isFullTour && tourStep === 15)", "(isFullTour && tourStep === 21)")

with open('AstronomicalFeatures.jsx', 'w', encoding='utf-8') as f:
    f.write(content)
