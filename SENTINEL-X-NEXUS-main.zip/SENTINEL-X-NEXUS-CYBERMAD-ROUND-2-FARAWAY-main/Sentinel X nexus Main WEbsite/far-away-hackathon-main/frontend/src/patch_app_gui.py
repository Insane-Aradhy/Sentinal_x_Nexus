import re

def main():
    # ── UPDATE APP.JSX ──────────────────────────────────────────────────────────
    with open('App.jsx', 'r', encoding='utf-8') as f:
        app = f.read()

    # Complete updated TOUR_REGISTRY with all choice steps
    new_registry = """  astro: {
    theme: 'pink',
    page: 'astro',
    steps: [
      {
        id: 'astro-start',
        title: 'STEP 1: Enter Astro-Computation',
        desc: 'Click the "🧮 Astro-Computation" tab in the top navigation bar to enter the division.',
        arrow: 'up',
        position: { top: 75, left: '60%', transform: 'translateX(-50%)' },
        waitForClick: true,
      },
      {
        id: 'astro-core',
        title: 'STEP 2: Astro-Computation Core',
        desc: 'Welcome to the Astro-Computation Core! This engine calculates orbital mechanics at native speeds in-browser. We have 4 active mathematical divisions powering the platform.',
        arrow: 'up',
        position: { top: 120, left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'astro-div1',
        title: 'STEP 3: 01. SGP4 / SDP4 Propagator',
        desc: 'Let\\'s explore Division 1. Click on the highlighted "01. SGP4 / SDP4" division button.',
        arrow: 'up',
        position: { top: 180, left: 'calc(50% - 250px)' },
        waitForClick: true,
      },
      {
        id: 'astro-sgp4-desc',
        title: 'STEP 4: What is SGP4?',
        desc: 'SGP4 is the mathematical standard used by NORAD to predict satellite orbits. Our implementation computes 1,000 satellites in under 65ms. PLEASE SCROLL DOWN to view the Live Satellite Catalog.',
        arrow: 'down',
        position: { top: '40%', left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'astro-catalog',
        title: 'STEP 5: The Satellite Catalog',
        desc: 'Below is our Live Satellite Catalog, tracking thousands of real objects. PLEASE SCROLL DOWN.',
        arrow: 'down',
        position: { top: '40%', left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'astro-select',
        title: 'STEP 6: Select a Target',
        desc: 'Select any satellite from the catalog to analyze its orbit. PLEASE SCROLL DOWN if you cannot see the table.',
        arrow: 'down',
        position: { top: '40%', left: '50%', transform: 'translateX(-50%)' },
        waitForClick: true,
      },
      {
        id: 'astro-run-sgp4',
        title: 'STEP 7: Run Propagation',
        desc: 'Great choice! Now click the "Run SGP4" button. This calculates exact ECI position, velocity, and altitude 24 hours into the future instantly. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-run-search',
        title: 'STEP 8: Spatial Proximity Search',
        desc: 'Our engine uses k-d Trees to perform spatial proximity searches in O(log n) time. Click "Run Proximity Search" to find nearest objects! PLEASE SCROLL DOWN to see the button.',
        arrow: 'right',
        position: { top: 'calc(50% + 50px)', right: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-sgp4-complete',
        title: 'STEP 9: SGP4 Results',
        desc: 'The SGP4 engine has successfully computed the future state and spatial proximity! Click NEXT to proceed to Foster\\'s Pc.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      },
      {
        id: 'astro-div2',
        title: 'STEP 10: 02. Foster\\'s Collision Probability',
        desc: 'Now let\\'s evaluate collision risk! Click on the highlighted "02. Foster\\'s Pc" division button at the top.',
        arrow: 'up',
        position: { top: 180, left: 'calc(50% - 100px)' },
        waitForClick: true,
      },
      {
        id: 'astro-foster-desc',
        title: 'STEP 11: 2D Gaussian B-Plane Integration',
        desc: 'Foster\\'s Pc projects 3D covariances to the 2D B-plane and performs Riemann Quadrature integration over the combined hard-body radius. PLEASE SCROLL DOWN to view controls.',
        arrow: 'down',
        position: { top: '35%', left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'astro-foster-primary',
        title: 'STEP 12: Choose Primary Satellite (Asset)',
        desc: 'Select our primary protected satellite from the blinking dropdown. This represents our asset (e.g. ISS or active payload) under risk analysis. Click NEXT when ready.',
        arrow: 'down',
        position: { top: 220, left: 'calc(50% - 250px)' },
      },
      {
        id: 'astro-foster-secondary',
        title: 'STEP 13: Choose Secondary Threat (Debris)',
        desc: 'Select the secondary threat or debris fragment from the blinking dropdown. The engine combines positional uncertainty ellipsoids of both bodies. Click NEXT when ready.',
        arrow: 'down',
        position: { top: 220, left: 'calc(50% + 250px)' },
      },
      {
        id: 'astro-foster-run',
        title: 'STEP 14: Run Mathematical Integration',
        desc: 'Click the highlighted "Run Mathematical Integration" button to compute the collision probability (Pc) in real-time. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-foster-complete',
        title: 'STEP 15: Foster\\'s Pc Results',
        desc: 'The mathematical integration is complete! Review the calculated collision probability (Pc), Miss Distance, and Hard Body Radius. Click NEXT to proceed to Delta-V Optimizer.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      },
      {
        id: 'astro-div3',
        title: 'STEP 16: 03. Delta-V Optimizer',
        desc: 'Next, let\\'s plan avoidance maneuvers. Click on the highlighted "03. Delta-V Optimizer" division button at the top.',
        arrow: 'up',
        position: { top: 180, left: 'calc(50% + 50px)' },
        waitForClick: true,
      },
      {
        id: 'astro-deltav-desc',
        title: 'STEP 17: Vis-Viva & Tsiolkovsky Optimization',
        desc: 'Calculates the optimal two-burn Hohmann transfer to achieve radial clearance while minimizing propellant expenditure. PLEASE SCROLL DOWN to view controls.',
        arrow: 'down',
        position: { top: '40%', left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'astro-deltav-select',
        title: 'STEP 18: Select Maneuvering Satellite',
        desc: 'Select the satellite from the blinking dropdown. The optimizer requires its initial orbital radius to calculate transfer velocity bounds. Click NEXT when ready.',
        arrow: 'down',
        position: { top: 220, left: 'calc(50% - 150px)' },
      },
      {
        id: 'astro-deltav-clearance',
        title: 'STEP 19: Set Radial Clearance Target',
        desc: 'Adjust the target clearance offset (in km) using the blinking input. The engine calculates burn vectors relative to this displacement target. Click NEXT when ready.',
        arrow: 'down',
        position: { top: 220, left: 'calc(50% + 150px)' },
      },
      {
        id: 'astro-deltav-run',
        title: 'STEP 20: Calculate Optimal Maneuver',
        desc: 'Click the highlighted "Calculate Optimal Maneuver" button to simulate the burn vectors and compute required Delta-V and fuel mass. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-deltav-complete',
        title: 'STEP 21: Maneuver Plan Results',
        desc: 'Delta-V optimization complete! Review the required ΔV burn requirements, burn duration, and fuel mass. Click NEXT to proceed to Orbital Decay Predictor.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      },
      {
        id: 'astro-div4',
        title: 'STEP 22: 04. Orbital Decay Predictor',
        desc: 'Finally, let\\'s predict atmospheric reentry. Click on the highlighted "04. Reentry Predictor" division button at the top.',
        arrow: 'up',
        position: { top: 180, left: 'calc(50% + 200px)' },
        waitForClick: true,
      },
      {
        id: 'astro-reentry-desc',
        title: 'STEP 23: Atmospheric Drag Integrator',
        desc: 'Numerically integrates atmospheric drag using exponential density models until the 100km Kármán line boundary. PLEASE SCROLL DOWN.',
        arrow: 'down',
        position: { top: '40%', left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'astro-reentry-select',
        title: 'STEP 24: Select Decay Object',
        desc: 'Select the satellite from the blinking dropdown. The engine parses its ballistic characteristics (mass and cross-section area) to evaluate drag parameters. Click NEXT when ready.',
        arrow: 'down',
        position: { top: 220, left: 'calc(50% - 100px)' },
      },
      {
        id: 'astro-reentry-run',
        title: 'STEP 25: Predict Reentry Date',
        desc: 'Click "Predict Reentry Date" to evaluate structural orbital lifetime and decay curve. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-reentry-complete',
        title: 'STEP 26: Reentry Prediction Results',
        desc: 'Reentry prediction complete! Review the estimated orbital lifetime and final decay trajectory. Click NEXT to finish the tour.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      },
      {
        id: 'astro-complete',
        title: 'STEP 27: Astro-Computation Complete!',
        desc: 'You have seen all 4 mathematical divisions of Sentinel-Nexus: SGP4 Propagation, Foster\\'s Pc Integration, Delta-V Maneuver Optimization, and Reentry Prediction.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      }
    ]
  },
  'astro-sgp4': {
    theme: 'pink',
    page: 'astro',
    steps: [
      {
        id: 'astro-start',
        title: 'STEP 1: Enter Astro-Computation',
        desc: 'Click the "🧮 Astro-Computation" tab in the top navigation bar to enter the division.',
        arrow: 'up',
        position: { top: 75, left: '60%', transform: 'translateX(-50%)' },
        waitForClick: true,
      },
      {
        id: 'astro-core',
        title: 'STEP 2: Astro-Computation Core',
        desc: 'Welcome to the Astro-Computation Core! This engine calculates orbital mechanics at native speeds in-browser. We have 4 active mathematical divisions powering the platform.',
        arrow: 'up',
        position: { top: 120, left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'astro-div1',
        title: 'STEP 3: SGP4 Propagator',
        desc: 'Let\\'s explore the first feature. Click on the highlighted "01. SGP4 / SDP4" division button.',
        arrow: 'up',
        position: { top: 180, left: 'calc(50% - 250px)' },
        waitForClick: true,
      },
      {
        id: 'astro-sgp4-desc',
        title: 'STEP 4: What is SGP4?',
        desc: 'SGP4 is the mathematical standard used by NORAD to predict satellite orbits. Our implementation computes 1,000 satellites in under 65ms. PLEASE SCROLL DOWN to view the Live Satellite Catalog.',
        arrow: 'down',
        position: { top: '40%', left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'astro-catalog',
        title: 'STEP 5: The Satellite Catalog',
        desc: 'Below is our Live Satellite Catalog, tracking thousands of real objects. PLEASE SCROLL DOWN.',
        arrow: 'down',
        position: { top: '40%', left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'astro-select',
        title: 'STEP 6: Select a Target',
        desc: 'Select any satellite from the catalog to analyze its orbit. PLEASE SCROLL DOWN if you cannot see the table.',
        arrow: 'down',
        position: { top: '40%', left: '50%', transform: 'translateX(-50%)' },
        waitForClick: true,
      },
      {
        id: 'astro-run-sgp4',
        title: 'STEP 7: Run Propagation',
        desc: 'Great choice! Now click the "Run SGP4" button. This calculates exact ECI position, velocity, and altitude 24 hours into the future instantly. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-run-search',
        title: 'STEP 8: Spatial Proximity Search',
        desc: 'Our engine uses k-d Trees to perform spatial proximity searches in O(log n) time. Click "Run Proximity Search" to find nearest objects! PLEASE SCROLL DOWN to see the button.',
        arrow: 'right',
        position: { top: 'calc(50% + 50px)', right: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-sgp4-complete',
        title: 'STEP 9: SGP4 Tour Complete!',
        desc: 'You have successfully run the SGP4 Propagator and Spatial Proximity Search. The mathematical engine has output the results.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      }
    ]
  },
  'astro-foster': {
    theme: 'pink',
    page: 'astro',
    steps: [
      {
        id: 'foster-start',
        title: 'STEP 1: Enter Astro-Computation',
        desc: 'Click the "🧮 Astro-Computation" tab in the top navigation bar to enter the division.',
        arrow: 'up',
        position: { top: 75, left: '60%', transform: 'translateX(-50%)' },
        waitForClick: true,
      },
      {
        id: 'foster-div2',
        title: 'STEP 2: Foster\\'s Pc',
        desc: 'Click on the highlighted "02. Foster\\'s Pc" division button to explore Collision Probability mathematics.',
        arrow: 'up',
        position: { top: 180, left: 'calc(50% - 100px)' },
        waitForClick: true,
      },
      {
        id: 'foster-desc',
        title: 'STEP 3: 2D Gaussian Integration',
        desc: 'This engine uses a 2D Gaussian Numerical Integration over the B-plane to calculate the exact Probability of Collision (Pc) between two objects. PLEASE SCROLL DOWN to view the controls.',
        arrow: 'down',
        position: { top: '35%', left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'foster-primary',
        title: 'STEP 4: Choose Primary Satellite (Asset)',
        desc: 'Select our primary protected satellite from the blinking dropdown. This represents our asset (e.g. ISS or active payload) under risk analysis. Click NEXT when ready.',
        arrow: 'down',
        position: { top: 220, left: 'calc(50% - 250px)' },
      },
      {
        id: 'foster-secondary',
        title: 'STEP 5: Choose Secondary Threat (Debris)',
        desc: 'Select the secondary threat or debris fragment from the blinking dropdown. The engine combines positional uncertainty ellipsoids of both bodies. Click NEXT when ready.',
        arrow: 'down',
        position: { top: 220, left: 'calc(50% + 250px)' },
      },
      {
        id: 'foster-run',
        title: 'STEP 6: Run Mathematical Integration',
        desc: 'Click "Run Mathematical Integration". The engine will project covariances to the B-plane and solve the Riemann Quadrature to evaluate the exact collision risk. PLEASE SCROLL DOWN if you cannot see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'foster-complete',
        title: 'STEP 7: Foster\\'s Pc Results',
        desc: 'The mathematical integration is complete! You can now review the calculated probability of collision (Pc), Miss Distance, and Hard Body Radius.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      }
    ]
  },
  'astro-deltav': {
    theme: 'pink',
    page: 'astro',
    steps: [
      {
        id: 'deltav-start',
        title: 'STEP 1: Enter Astro-Computation',
        desc: 'Click the "🧮 Astro-Computation" tab in the top navigation bar to enter the division.',
        arrow: 'up',
        position: { top: 75, left: '60%', transform: 'translateX(-50%)' },
        waitForClick: true,
      },
      {
        id: 'deltav-div3',
        title: 'STEP 2: Delta-V Optimizer',
        desc: 'Click on the highlighted "03. Delta-V Optimizer" division button to explore Maneuver Planning.',
        arrow: 'up',
        position: { top: 180, left: 'calc(50% + 50px)' },
        waitForClick: true,
      },
      {
        id: 'deltav-desc',
        title: 'STEP 3: Vis-viva & Tsiolkovsky',
        desc: 'Calculates the optimal two-burn Hohmann transfer to achieve radial clearance while minimizing propellant expenditure. PLEASE SCROLL DOWN to view controls.',
        arrow: 'down',
        position: { top: '40%', left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'deltav-select',
        title: 'STEP 4: Select Maneuvering Satellite',
        desc: 'Select the satellite from the blinking dropdown to specify its initial orbital configuration. Click NEXT when ready.',
        arrow: 'down',
        position: { top: 220, left: 'calc(50% - 150px)' },
      },
      {
        id: 'deltav-clearance',
        title: 'STEP 5: Set Radial Clearance Target',
        desc: 'Adjust the target clearance offset (in km) using the blinking input to change burn magnitude parameters. Click NEXT when ready.',
        arrow: 'down',
        position: { top: 220, left: 'calc(50% + 150px)' },
      },
      {
        id: 'deltav-run',
        title: 'STEP 6: Calculate Maneuver',
        desc: 'Click "Calculate Optimal Maneuver". The optimizer will use Tsiolkovsky\\'s rocket equation and Vis-viva mechanics to find the minimum-energy transfer. PLEASE SCROLL DOWN if you cannot see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'deltav-complete',
        title: 'STEP 7: Maneuver Plan Results',
        desc: 'Optimization complete! You can now review the required propellant and burn parameters.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      }
    ]
  },
  'astro-reentry': {
    theme: 'pink',
    page: 'astro',
    steps: [
      {
        id: 'reentry-start',
        title: 'STEP 1: Enter Astro-Computation',
        desc: 'Click the "🧮 Astro-Computation" tab in the top navigation bar to enter the division.',
        arrow: 'up',
        position: { top: 75, left: '60%', transform: 'translateX(-50%)' },
        waitForClick: true,
      },
      {
        id: 'reentry-div4',
        title: 'STEP 2: Reentry Predictor',
        desc: 'Click on the highlighted "04. Reentry Predictor" division button to explore Orbital Decay.',
        arrow: 'up',
        position: { top: 180, left: 'calc(50% + 200px)' },
        waitForClick: true,
      },
      {
        id: 'reentry-desc',
        title: 'STEP 3: Atmospheric Drag Integration',
        desc: 'This engine predicts orbital decay by numerically integrating atmospheric drag forces over time until the object crosses the 100km Kármán line. PLEASE SCROLL DOWN.',
        arrow: 'down',
        position: { top: '40%', left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'reentry-select',
        title: 'STEP 4: Select Decay Object',
        desc: 'Select the satellite from the blinking dropdown. The engine parses its ballistic characteristics to evaluate drag forces. Click NEXT when ready.',
        arrow: 'down',
        position: { top: 220, left: 'calc(50% - 100px)' },
      },
      {
        id: 'reentry-run',
        title: 'STEP 5: Predict Reentry Date',
        desc: 'Click "Predict Reentry Date". The engine will iterate the atmospheric drag models and project the Kármán line boundary intersection. PLEASE SCROLL DOWN.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'reentry-complete',
        title: 'STEP 6: Reentry Prediction Results',
        desc: 'Reentry prediction complete! You can now review the estimated decay time and final altitude.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      }
    ]
  }"""

    # Match from `  astro: {` to the end of `TOUR_REGISTRY`
    pattern = r"\s*astro:\s*\{.*?\n  \}\n\}"
    app = re.sub(pattern, "\n" + new_registry + "\n}", app, flags=re.DOTALL)

    # ── UPDATE TOURPOINTER IN APP.JSX FOR DRAGGING ────────────────────────────
    # Let's write the complete TourPointer component with pointer dragging capability
    tour_pointer_code = """function TourPointer({ step, currentStep, totalSteps, theme, onNext, onEnd }) {
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef(null);

  // Reset drag offset on step change
  useEffect(() => {
    setDragOffset({ x: 0, y: 0 });
    setIsDragging(false);
    dragStart.current = null;
  }, [step]);

  const handlePointerDown = (e) => {
    if (e.target.tagName === 'BUTTON' || e.target.tagName === 'SELECT' || e.target.tagName === 'A') return;
    e.target.setPointerCapture(e.pointerId);
    dragStart.current = {
      x: e.clientX - dragOffset.x,
      y: e.clientY - dragOffset.y
    };
    setIsDragging(true);
  };

  const handlePointerMove = (e) => {
    if (!dragStart.current) return;
    setDragOffset({
      x: e.clientX - dragStart.current.x,
      y: e.clientY - dragStart.current.y
    });
  };

  const handlePointerUp = (e) => {
    dragStart.current = null;
    setIsDragging(false);
  };

  useEffect(() => {
    if (step.arrow === 'up' && step.title && step.title.includes('STEP') && 
        (step.title.includes(' 3:') || step.title.includes('10:') || step.title.includes('16:') || step.title.includes('22:') || step.title.includes(' 2:'))) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [step]);

  const arrowChar = { up: '↑', down: '↓', left: '←', right: '→' }[step.arrow] || '↓'
  const isHorizontal = step.arrow === 'left' || step.arrow === 'right'
  const isGolden = theme === 'golden'
  const accentColor = isGolden ? '#fbbf24' : '#ec4899'
  const bgGradient = isGolden ? 'rgba(245,158,11,0.95)' : 'rgba(236,72,153,0.95)'
  const shadowColor = isGolden ? 'rgba(251,191,36,0.4)' : 'rgba(236,72,153,0.4)'
  const borderColor = isGolden ? '#fef3c7' : '#fbcfe8'

  return (
    <div 
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      style={{
        position: 'fixed', zIndex: 10000,
        ...step.position,
        transform: `${step.position?.transform || ''} translate(${dragOffset.x}px, ${dragOffset.y}px)`,
        animation: isDragging || dragOffset.x !== 0 || dragOffset.y !== 0 ? 'none' : 'bounce-highlight 1.8s infinite',
        display: 'flex',
        flexDirection: isHorizontal ? 'row' : 'column',
        alignItems: step.align || 'center',
        gap: 6,
        pointerEvents: 'auto',
        userSelect: 'none',
        cursor: isDragging ? 'grabbing' : 'grab'
      }}
    >
      {(step.arrow === 'up' || step.arrow === 'left') && (
        <div style={{ color: accentColor, fontSize: 24, textShadow: `0 2px 8px ${shadowColor}`, marginRight: step.align === 'flex-end' ? 20 : 0 }}>{arrowChar}</div>
      )}
      <div style={{
        background: bgGradient, color: '#fff',
        padding: '14px 18px', borderRadius: 10, maxWidth: step.width || 300,
        boxShadow: `0 8px 30px ${shadowColor}, 0 0 0 2px ${borderColor}`,
        fontFamily: "'Inter', 'JetBrains Mono', sans-serif",
      }}>
        {isGolden && (
          <div style={{
            fontSize: 8, fontWeight: 'bold', letterSpacing: '1px', marginBottom: 8,
            background: 'rgba(255,255,255,0.2)', display: 'inline-block',
            padding: '2px 6px', borderRadius: 4, textTransform: 'uppercase'
          }}>
            ✓ MADE DURING 24 HRS FARAWAY 2ND ROUND
          </div>
        )}
        <div style={{ fontSize: 11, fontWeight: 'bold', letterSpacing: '1.5px', marginBottom: 6, opacity: 0.85 }}>
          ⭐ {step.title}  ({currentStep + 1}/{totalSteps})
        </div>
        <div style={{ fontSize: 13, lineHeight: 1.5, marginBottom: 10 }}>{step.desc}</div>
        <div style={{ marginTop: 12, display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <button onClick={onEnd} style={{ background: 'transparent', border: `1px solid ${borderColor}`, color: '#fff', padding: '4px 10px', borderRadius: 4, cursor: 'pointer', fontSize: 11 }}>
            SKIP
          </button>
          {!step.waitForClick && (
            <button onClick={currentStep === totalSteps - 1 ? onEnd : onNext} style={{ background: '#fff', border: 'none', color: accentColor, padding: '4px 12px', borderRadius: 4, cursor: 'pointer', fontWeight: 'bold', fontSize: 11 }}>
              {currentStep === totalSteps - 1 ? 'FINISH' : 'NEXT'}
            </button>
          )}
        </div>
      </div>
      {(step.arrow === 'down' || step.arrow === 'right') && (
        <div style={{ color: accentColor, fontSize: 24, textShadow: `0 2px 8px ${shadowColor}`, marginRight: step.align === 'flex-end' ? 20 : 0 }}>{arrowChar}</div>
      )}
    </div>
  )
}"""

    # Replace from `function TourPointer` to end of `TourPointer` component
    pattern_pointer = r"function TourPointer\(.*?\}\s*\n\s*\n\s*\/\/ ── Assist Judges Dropdown Menu"
    app = re.sub(pattern_pointer, tour_pointer_code + "\n\n// ── Assist Judges Dropdown Menu", app, flags=re.DOTALL)

    with open('App.jsx', 'w', encoding='utf-8') as f:
        f.write(app)
    print("App.jsx updated with choice steps and draggable guider.")

if __name__ == '__main__':
    main()
