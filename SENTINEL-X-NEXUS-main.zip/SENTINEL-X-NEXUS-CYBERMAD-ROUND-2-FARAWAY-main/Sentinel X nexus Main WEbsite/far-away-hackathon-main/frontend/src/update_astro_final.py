import re
import sys

app_path = "components/AstronomicalFeatures.jsx"
with open(app_path, "r", encoding="utf-8") as f:
    content = f.read()

# Replace sgp4 end
content = content.replace(
"""      setSearchRunning(false);
      if (isSgp4Tour && tourStep === 7 && setTourActive) setTourActive(false);
      if (isFullTour && tourStep === 7 && setTourStep) setTourStep(8);
    }, 10);""",
"""      setSearchRunning(false);
      if (isSgp4Tour && tourStep === 7 && setTourStep) setTourStep(8);
      if (isFullTour && tourStep === 7 && setTourStep) setTourStep(8);
    }, 10);"""
)

# Replace foster end
content = content.replace(
"""      setResults(data);

      if (isFosterTour && tourStep === 3 && setTourActive) setTourActive(false);
      if (isFullTour && tourStep === 10 && setTourStep) setTourStep(11);
      setTimeout(() => {""",
"""      setResults(data);

      if (isFosterTour && tourStep === 3 && setTourStep) setTourStep(4);
      if (isFullTour && tourStep === 10 && setTourStep) setTourStep(11);
      setTimeout(() => {"""
)


# Replace deltav end
content = content.replace(
"""      setResults(data);

      if (isDeltavTour && tourStep === 3 && setTourActive) setTourActive(false);
      if (isFullTour && tourStep === 13 && setTourStep) setTourStep(14);
      setTimeout(() => {""",
"""      setResults(data);

      if (isDeltavTour && tourStep === 3 && setTourStep) setTourStep(4);
      if (isFullTour && tourStep === 13 && setTourStep) setTourStep(14);
      setTimeout(() => {"""
)

# Replace reentry end
content = content.replace(
"""      setResults(data);

      if (isReentryTour && tourStep === 3 && setTourActive) setTourActive(false);
      if (isFullTour && tourStep === 16 && setTourStep) setTourStep(17);
      setTimeout(() => {""",
"""      setResults(data);

      if (isReentryTour && tourStep === 3 && setTourStep) setTourStep(4);
      if (isFullTour && tourStep === 16 && setTourStep) setTourStep(17);
      setTimeout(() => {"""
)

with open(app_path, "w", encoding="utf-8") as f:
    f.write(content)
print("Updated AstronomicalFeatures.jsx successfully.")
