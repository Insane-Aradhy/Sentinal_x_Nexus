with open('App.jsx', 'r', encoding='utf-8') as f:
    app = f.read()

# Replace the TourPointer implementation with the safe version
safe_tour_pointer = """function TourPointer({ step, currentStep, totalSteps, theme, onNext, onEnd }) {
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef(null);

  // Reset drag offset on step change
  useEffect(() => {
    setDragOffset({ x: 0, y: 0 });
    setIsDragging(false);
    dragStart.current = null;
  }, [step]);

  const handlePointerDown = (e) => {
    if (!step || e.target.tagName === 'BUTTON' || e.target.tagName === 'SELECT' || e.target.tagName === 'A') return;
    e.target.setPointerCapture(e.pointerId);
    dragStart.current = {
      x: e.clientX - dragOffset.x,
      y: e.clientY - dragOffset.y
    };
    setIsDragging(true);
  };

  const handlePointerMove = (e) => {
    if (!dragStart.current) return;
    setDragOffset({
      x: e.clientX - dragStart.current.x,
      y: e.clientY - dragStart.current.y
    });
  };

  const handlePointerUp = (e) => {
    dragStart.current = null;
    setIsDragging(false);
  };

  useEffect(() => {
    if (step && step.arrow === 'up' && step.title && step.title.includes('STEP') && 
        (step.title.includes(' 3:') || step.title.includes('10:') || step.title.includes('16:') || step.title.includes('22:') || step.title.includes(' 2:'))) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [step]);

  if (!step) return null;

  const arrowChar = { up: '↑', down: '↓', left: '←', right: '→' }[step.arrow] || '↓'
  const isHorizontal = step.arrow === 'left' || step.arrow === 'right'
  const isGolden = theme === 'golden'
  const accentColor = isGolden ? '#fbbf24' : '#ec4899'
  const bgGradient = isGolden ? 'rgba(245,158,11,0.95)' : 'rgba(236,72,153,0.95)'
  const shadowColor = isGolden ? 'rgba(251,191,36,0.4)' : 'rgba(236,72,153,0.4)'
  const borderColor = isGolden ? '#fef3c7' : '#fbcfe8'

  return (
    <div 
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      style={{
        position: 'fixed', zIndex: 10000,
        ...step.position,
        transform: `${step.position?.transform || ''} translate(${dragOffset.x}px, ${dragOffset.y}px)`,
        animation: isDragging || dragOffset.x !== 0 || dragOffset.y !== 0 ? 'none' : 'bounce-highlight 1.8s infinite',
        display: 'flex',
        flexDirection: isHorizontal ? 'row' : 'column',
        alignItems: step.align || 'center',
        gap: 6,
        pointerEvents: 'auto',
        userSelect: 'none',
        cursor: isDragging ? 'grabbing' : 'grab'
      }}
    >
      {(step.arrow === 'up' || step.arrow === 'left') && (
        <div style={{ color: accentColor, fontSize: 24, textShadow: `0 2px 8px ${shadowColor}`, marginRight: step.align === 'flex-end' ? 20 : 0 }}>{arrowChar}</div>
      )}
      <div style={{
        background: bgGradient, color: '#fff',
        padding: '14px 18px', borderRadius: 10, maxWidth: step.width || 300,
        boxShadow: `0 8px 30px ${shadowColor}, 0 0 0 2px ${borderColor}`,
        fontFamily: "'Inter', 'JetBrains Mono', sans-serif",
      }}>
        {isGolden && (
          <div style={{
            fontSize: 8, fontWeight: 'bold', letterSpacing: '1px', marginBottom: 8,
            background: 'rgba(255,255,255,0.2)', display: 'inline-block',
            padding: '2px 6px', borderRadius: 4, textTransform: 'uppercase'
          }}>
            ✓ MADE DURING 24 HRS FARAWAY 2ND ROUND
          </div>
        )}
        <div style={{ fontSize: 11, fontWeight: 'bold', letterSpacing: '1.5px', marginBottom: 6, opacity: 0.85 }}>
          ⭐ {step.title}  ({currentStep + 1}/{totalSteps})
        </div>
        <div style={{ fontSize: 13, lineHeight: 1.5, marginBottom: 10 }}>{step.desc}</div>
        <div style={{ marginTop: 12, display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <button onClick={onEnd} style={{ background: 'transparent', border: `1px solid ${borderColor}`, color: '#fff', padding: '4px 10px', borderRadius: 4, cursor: 'pointer', fontSize: 11 }}>
            SKIP
          </button>
          {!step.waitForClick && (
            <button onClick={currentStep === totalSteps - 1 ? onEnd : onNext} style={{ background: '#fff', border: 'none', color: accentColor, padding: '4px 12px', borderRadius: 4, cursor: 'pointer', fontWeight: 'bold', fontSize: 11 }}>
              {currentStep === totalSteps - 1 ? 'FINISH' : 'NEXT'}
            </button>
          )}
        </div>
      </div>
      {(step.arrow === 'down' || step.arrow === 'right') && (
        <div style={{ color: accentColor, fontSize: 24, textShadow: `0 2px 8px ${shadowColor}`, marginRight: step.align === 'flex-end' ? 20 : 0 }}>{arrowChar}</div>
      )}
    </div>
  )
}"""

import re
pattern_pointer = r"function TourPointer\(.*?\}\s*\n\s*\n\s*\/\/ ── Assist Judges Dropdown Menu"
app = re.sub(pattern_pointer, safe_tour_pointer + "\\n\\n// ── Assist Judges Dropdown Menu", app, flags=re.DOTALL)

with open('App.jsx', 'w', encoding='utf-8') as f:
    f.write(app)
print("Safety checks added to TourPointer.")
