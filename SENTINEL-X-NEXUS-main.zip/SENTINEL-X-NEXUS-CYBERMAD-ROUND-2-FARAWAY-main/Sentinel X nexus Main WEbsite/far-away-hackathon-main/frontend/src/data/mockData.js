// ============================================================
// MOCK DATA — Based on Backend Schema (5_BACKEND_SCHEMA.md)
// Real structure matching the ConjunctionEvent and SentinelAction schemas
// Will be replaced by live WebSocket data in Part 2
// ============================================================

export const conjunctionEvents = [
  {
    eventId: 'EVT-2026-001',
    timestamp: '2026-06-10T04:12:00Z',
    primaryObject: { id: '43013', name: 'ISRO GSAT-30', type: 'PAYLOAD' },
    secondaryObject: { id: '37820', name: 'COSMOS 2546 DEB', type: 'DEBRIS' },
    metrics: {
      timeOfClosestApproach: '2026-06-10T05:47:00Z',
      missDistanceKm: 1.243,
      collisionProbability: 0.000024,
      relativeVelocityKmS: 12.7,
    },
    riskLevel: 'YELLOW',
  },
  {
    eventId: 'EVT-2026-002',
    timestamp: '2026-06-10T03:55:00Z',
    primaryObject: { id: '41340', name: 'STARLINK-1234', type: 'PAYLOAD' },
    secondaryObject: { id: '22899', name: 'SL-8 R/B', type: 'ROCKET BODY' },
    metrics: {
      timeOfClosestApproach: '2026-06-10T07:12:00Z',
      missDistanceKm: 3.881,
      collisionProbability: 0.0000031,
      relativeVelocityKmS: 9.4,
    },
    riskLevel: 'GREEN',
  },
  {
    eventId: 'EVT-2026-003',
    timestamp: '2026-06-10T03:30:00Z',
    primaryObject: { id: '48265', name: 'CARTOSAT-3', type: 'PAYLOAD' },
    secondaryObject: { id: '18820', name: 'FENGYUN 1C DEB', type: 'DEBRIS' },
    metrics: {
      timeOfClosestApproach: '2026-06-10T06:22:00Z',
      missDistanceKm: 0.612,
      collisionProbability: 0.000198,
      relativeVelocityKmS: 13.1,
    },
    riskLevel: 'YELLOW',
  },
  {
    eventId: 'EVT-2026-004',
    timestamp: '2026-06-10T02:10:00Z',
    primaryObject: { id: '51069', name: 'EOS-06', type: 'PAYLOAD' },
    secondaryObject: { id: '44250', name: 'IRIDIUM 33 DEB', type: 'DEBRIS' },
    metrics: {
      timeOfClosestApproach: '2026-06-10T09:05:00Z',
      missDistanceKm: 8.401,
      collisionProbability: 0.00000087,
      relativeVelocityKmS: 7.2,
    },
    riskLevel: 'GREEN',
  },
  {
    eventId: 'EVT-2026-005',
    timestamp: '2026-06-10T01:48:00Z',
    primaryObject: { id: '43508', name: 'RESOURCESAT-2A', type: 'PAYLOAD' },
    secondaryObject: { id: '14820', name: 'CZ-3 DEB', type: 'DEBRIS' },
    metrics: {
      timeOfClosestApproach: '2026-06-10T11:30:00Z',
      missDistanceKm: 2.034,
      collisionProbability: 0.0000112,
      relativeVelocityKmS: 11.8,
    },
    riskLevel: 'GREEN',
  },
]

export const sentinelActions = [
  {
    actionId: 'ACT-2026-003',
    eventId: 'EVT-2026-003',
    timestamp: '2026-06-10T03:31:22Z',
    decision: 'ESCALATE',
    reasoning: 'Miss distance 612m below YELLOW threshold (1km). Collision probability 1.98e-4 elevated. Monitoring frequency increased. Maneuver plan computed and on standby.',
    maneuverDetails: { deltaV: 0.18, burnDurationSec: 22 },
  },
  {
    actionId: 'ACT-2026-001',
    eventId: 'EVT-2026-001',
    timestamp: '2026-06-10T04:12:48Z',
    decision: 'ESCALATE',
    reasoning: 'Conjunction detected: GSAT-30 vs COSMOS debris. Miss distance 1.243km. Collision probability 2.4e-5. Within YELLOW monitoring band. Alerting ground control asynchronously.',
    maneuverDetails: null,
  },
  {
    actionId: 'ACT-2026-002',
    eventId: 'EVT-2026-002',
    timestamp: '2026-06-10T03:55:30Z',
    decision: 'MONITOR',
    reasoning: 'Miss distance 3.88km and probability 3.1e-6 are within GREEN safe limits. Nominal monitoring cycle maintained. No maneuver required.',
    maneuverDetails: null,
  },
]

export const nexusDebate = [
  {
    agentId: 'PLANNING',
    agentName: 'Planning Agent',
    timestamp: '2026-06-10T03:31:45Z',
    message: 'EVT-2026-003 flagged by SENTINEL. Orbital window for avoidance burn: T+0 to T+47min. I compute a ΔV of 0.18 m/s over 22s resolves the conjunction with 98.3% confidence.',
    confidence: 0.98,
    vote: 'APPROVE_MANEUVER',
  },
  {
    agentId: 'ANOMALY',
    agentName: 'Anomaly Agent',
    timestamp: '2026-06-10T03:32:01Z',
    message: 'Concur with Planning. Debris ID 18820 is Fengyun-1C cloud fragment — high uncertainty in trajectory. Collision probability could be underestimated by factor of 3x. Recommend treating as RED.',
    confidence: 0.91,
    vote: 'ESCALATE_RED',
  },
  {
    agentId: 'RESPONSE',
    agentName: 'Response Agent',
    timestamp: '2026-06-10T03:32:18Z',
    message: 'Maneuver plan validated. Fuel cost: 0.34kg propellant. Station-keeping budget impact: minimal. Burn at T+12min is optimal. I am ready to execute on council approval.',
    confidence: 0.96,
    vote: 'APPROVE_MANEUVER',
  },
  {
    agentId: 'COMMS',
    agentName: 'Comms Agent',
    timestamp: '2026-06-10T03:32:35Z',
    message: 'Ground contact window: ISTRAC Bengaluru in 8min. ISRO NOC notification queued. Uplink ready for maneuver command push. Autonomous fallback authorized if no ground ACK in 5min.',
    confidence: 0.99,
    vote: 'APPROVE_MANEUVER',
  },
  {
    agentId: 'PLANNING',
    agentName: 'Planning Agent',
    timestamp: '2026-06-10T03:32:52Z',
    message: 'Council vote: 3x APPROVE_MANEUVER, 1x ESCALATE_RED. Consensus: EXECUTE. Anomaly Agent concerns noted — escalating risk score to 0.82. Burn authorized. Handoff to Response Agent.',
    confidence: 0.97,
    vote: 'CONSENSUS_EXECUTE',
  },
]

export const systemStatus = {
  sentinelUptime: '99.97%',
  objectsTracked: 23847,
  activeConjunctions: 5,
  agentsOnline: 4,
  lastDataSync: '2026-06-10T10:29:00Z',
  dataSource: 'Celestrak + Space-Track',
}
