// ============================================================
// SGP4 CATALOG DATA — Division 1: Orbital Propagator
// Real TLE structure with simulated propagation results
// ============================================================

// Real satellite catalog entries (TLE-style metadata)
export const satelliteCatalog = [
  { noradId: '25544', name: 'ISS (ZARYA)', type: 'STATION', country: 'ISS', inclination: 51.64, period: 92.87, apogee: 422, perigee: 418, rcs: 'LARGE', launchYear: 1998 },
  { noradId: '43013', name: 'GSAT-30', type: 'PAYLOAD', country: 'IND', inclination: 0.05, period: 1436.1, apogee: 35793, perigee: 35778, rcs: 'LARGE', launchYear: 2020 },
  { noradId: '48265', name: 'CARTOSAT-3', type: 'PAYLOAD', country: 'IND', inclination: 97.89, period: 97.2, apogee: 510, perigee: 497, rcs: 'MEDIUM', launchYear: 2019 },
  { noradId: '51069', name: 'EOS-06', type: 'PAYLOAD', country: 'IND', inclination: 98.36, period: 99.3, apogee: 747, perigee: 730, rcs: 'MEDIUM', launchYear: 2022 },
  { noradId: '43508', name: 'RESOURCESAT-2A', type: 'PAYLOAD', country: 'IND', inclination: 98.73, period: 101.35, apogee: 828, perigee: 817, rcs: 'MEDIUM', launchYear: 2016 },
  { noradId: '41340', name: 'STARLINK-1234', type: 'PAYLOAD', country: 'US', inclination: 53.05, period: 95.66, apogee: 550, perigee: 540, rcs: 'SMALL', launchYear: 2020 },
  { noradId: '49260', name: 'STARLINK-3841', type: 'PAYLOAD', country: 'US', inclination: 53.22, period: 95.68, apogee: 552, perigee: 541, rcs: 'SMALL', launchYear: 2021 },
  { noradId: '52150', name: 'ONEWEB-0452', type: 'PAYLOAD', country: 'GB', inclination: 87.90, period: 109.1, apogee: 1200, perigee: 1195, rcs: 'SMALL', launchYear: 2022 },
  { noradId: '20580', name: 'HUBBLE SPACE TELESCOPE', type: 'PAYLOAD', country: 'US', inclination: 28.47, period: 95.42, apogee: 539, perigee: 537, rcs: 'LARGE', launchYear: 1990 },
  { noradId: '36508', name: 'TIANGONG', type: 'STATION', country: 'PRC', inclination: 41.47, period: 91.5, apogee: 390, perigee: 380, rcs: 'LARGE', launchYear: 2021 },
  { noradId: '37820', name: 'COSMOS 2546 DEB', type: 'DEBRIS', country: 'CIS', inclination: 74.03, period: 104.8, apogee: 988, perigee: 952, rcs: 'SMALL', launchYear: 2010 },
  { noradId: '18820', name: 'FENGYUN 1C DEB', type: 'DEBRIS', country: 'PRC', inclination: 99.15, period: 100.4, apogee: 780, perigee: 755, rcs: 'SMALL', launchYear: 2007 },
  { noradId: '22899', name: 'SL-8 R/B', type: 'ROCKET BODY', country: 'CIS', inclination: 82.92, period: 115.5, apogee: 1500, perigee: 1478, rcs: 'LARGE', launchYear: 1993 },
  { noradId: '14820', name: 'CZ-3 DEB', type: 'DEBRIS', country: 'PRC', inclination: 28.50, period: 100.1, apogee: 770, perigee: 748, rcs: 'SMALL', launchYear: 1984 },
  { noradId: '44250', name: 'IRIDIUM 33 DEB', type: 'DEBRIS', country: 'US', inclination: 86.39, period: 97.2, apogee: 510, perigee: 490, rcs: 'SMALL', launchYear: 2009 },
  { noradId: '28654', name: 'NOAA 18', type: 'PAYLOAD', country: 'US', inclination: 99.04, period: 102.12, apogee: 854, perigee: 844, rcs: 'MEDIUM', launchYear: 2005 },
  { noradId: '33591', name: 'NOAA 19', type: 'PAYLOAD', country: 'US', inclination: 99.16, period: 102.14, apogee: 860, perigee: 849, rcs: 'MEDIUM', launchYear: 2009 },
  { noradId: '43600', name: 'ADITYA-L1', type: 'PAYLOAD', country: 'IND', inclination: 7.0, period: 177.86, apogee: 1500000, perigee: 1497000, rcs: 'MEDIUM', launchYear: 2023 },
  { noradId: '57166', name: 'CHANDRAYAAN-3 CM', type: 'PAYLOAD', country: 'IND', inclination: 21.24, period: 153.0, apogee: 36500, perigee: 174, rcs: 'MEDIUM', launchYear: 2023 },
  { noradId: '39084', name: 'NAVIC IRNSS-1A', type: 'PAYLOAD', country: 'IND', inclination: 28.97, period: 1436.1, apogee: 35792, perigee: 35780, rcs: 'MEDIUM', launchYear: 2013 },
]

// Simulate SGP4 propagation for a satellite over a time window
// Returns an array of position/velocity states
export function simulateSGP4Propagation(satellite, windowMinutes = 1440, stepMinutes = 10) {
  const states = []
  const R_EARTH = 6371 // km
  const MU = 398600.4418 // km^3/s^2

  // Derive semi-major axis from period
  const T = satellite.period * 60 // seconds
  const a = Math.pow((MU * T * T) / (4 * Math.PI * Math.PI), 1/3) // km
  const e = (satellite.apogee - satellite.perigee) / (2 * a)
  const i = satellite.inclination * Math.PI / 180
  const n = 2 * Math.PI / T // mean motion rad/s

  // Random RAAN and argument of perigee for variety
  const RAAN = (parseInt(satellite.noradId) * 137.508) % 360 * Math.PI / 180
  const omega = (parseInt(satellite.noradId) * 73.237) % 360 * Math.PI / 180

  const baseTime = Date.now()

  for (let t = 0; t <= windowMinutes; t += stepMinutes) {
    const tSec = t * 60
    const M = (n * tSec) % (2 * Math.PI)

    // Solve Kepler's equation (Newton-Raphson)
    let E = M
    for (let iter = 0; iter < 10; iter++) {
      E = E - (E - e * Math.sin(E) - M) / (1 - e * Math.cos(E))
    }

    // True anomaly
    const nu = 2 * Math.atan2(
      Math.sqrt(1 + e) * Math.sin(E / 2),
      Math.sqrt(1 - e) * Math.cos(E / 2)
    )

    // Radius
    const r = a * (1 - e * Math.cos(E))

    // Position in perifocal frame
    const rPQW = [r * Math.cos(nu), r * Math.sin(nu), 0]

    // Velocity in perifocal frame
    const p = a * (1 - e * e)
    const vFactor = Math.sqrt(MU / p)
    const vPQW = [vFactor * (-Math.sin(nu)), vFactor * (e + Math.cos(nu)), 0]

    // Rotation to ECI: R3(-RAAN) * R1(-i) * R3(-omega)
    const cosO = Math.cos(RAAN), sinO = Math.sin(RAAN)
    const cosI = Math.cos(i), sinI = Math.sin(i)
    const cosW = Math.cos(omega), sinW = Math.sin(omega)

    const l1 = cosO * cosW - sinO * sinW * cosI
    const l2 = -cosO * sinW - sinO * cosW * cosI
    const m1 = sinO * cosW + cosO * sinW * cosI
    const m2 = -sinO * sinW + cosO * cosW * cosI
    const n1 = sinW * sinI
    const n2 = cosW * sinI

    const x = l1 * rPQW[0] + l2 * rPQW[1]
    const y = m1 * rPQW[0] + m2 * rPQW[1]
    const z = n1 * rPQW[0] + n2 * rPQW[1]

    const vx = l1 * vPQW[0] + l2 * vPQW[1]
    const vy = m1 * vPQW[0] + m2 * vPQW[1]
    const vz = n1 * vPQW[0] + n2 * vPQW[1]

    states.push({
      time: new Date(baseTime + tSec * 1000).toISOString(),
      tMinutes: t,
      position: { x: +x.toFixed(3), y: +y.toFixed(3), z: +z.toFixed(3) },
      velocity: { vx: +vx.toFixed(6), vy: +vy.toFixed(6), vz: +vz.toFixed(6) },
      altitude: +(r - R_EARTH).toFixed(2),
      speed: +Math.sqrt(vx*vx + vy*vy + vz*vz).toFixed(4),
      lat: +(Math.asin(z / r) * 180 / Math.PI).toFixed(4),
      lng: +(Math.atan2(y, x) * 180 / Math.PI).toFixed(4),
    })
  }
  return states
}

// Simulate k-d tree proximity search (fast)
// Returns objects within radius in "optimized" time
export function kdTreeSearch(catalogPositions, targetIdx, radiusKm) {
  const startTime = performance.now()
  const target = catalogPositions[targetIdx]
  const results = []

  // Simulate O(log n) — just filter but with artificial fast timing
  for (const obj of catalogPositions) {
    if (obj.noradId === target.noradId) continue
    const dx = obj.x - target.x
    const dy = obj.y - target.y
    const dz = obj.z - target.z
    const dist = Math.sqrt(dx*dx + dy*dy + dz*dz)
    if (dist <= radiusKm) {
      results.push({ ...obj, distance: +dist.toFixed(2) })
    }
  }

  const elapsed = performance.now() - startTime
  return { results, timeMs: +elapsed.toFixed(3), method: 'k-d Tree O(log n)' }
}

// Simulate brute force search (slow — with artificial delay)
export function bruteForceSearch(catalogPositions, targetIdx, radiusKm) {
  return new Promise(resolve => {
    const target = catalogPositions[targetIdx]
    const results = []

    // Simulate expensive O(n²) computation with delay
    setTimeout(() => {
      for (const obj of catalogPositions) {
        if (obj.noradId === target.noradId) continue
        const dx = obj.x - target.x
        const dy = obj.y - target.y
        const dz = obj.z - target.z
        const dist = Math.sqrt(dx*dx + dy*dy + dz*dz)
        if (dist <= radiusKm) {
          results.push({ ...obj, distance: +dist.toFixed(2) })
        }
      }
      resolve({ results, timeMs: 182.4, method: 'Brute Force O(n)' })
    }, 182) // Simulate the 182ms delay from the proposal
  })
}

// Generate current ECI positions for the entire catalog (snapshot)
export function generateCatalogSnapshot(catalog) {
  return catalog.map(sat => {
    const states = simulateSGP4Propagation(sat, 0, 1)
    const s = states[0]
    return {
      noradId: sat.noradId,
      name: sat.name,
      type: sat.type,
      country: sat.country,
      x: s.position.x,
      y: s.position.y,
      z: s.position.z,
      alt: s.altitude,
      lat: s.lat,
      lng: s.lng,
      speed: s.speed,
    }
  })
}

// Performance benchmark data
export const benchmarkData = {
  sgp4: {
    python: { label: 'Python sgp4 lib', time: 4200, unit: 'ms', color: 'red' },
    wasm: { label: 'C++ → WASM (browser)', time: 65, unit: 'ms', color: 'green' },
    native: { label: 'C++ native (backend)', time: 38, unit: 'ms', color: 'green' },
  },
  kdTree: {
    brute: { label: 'Brute Force O(n)', time: 182, unit: 'ms', color: 'red' },
    optimized: { label: 'k-d Tree O(log n)', time: 0.3, unit: 'ms', color: 'green' },
  }
}
