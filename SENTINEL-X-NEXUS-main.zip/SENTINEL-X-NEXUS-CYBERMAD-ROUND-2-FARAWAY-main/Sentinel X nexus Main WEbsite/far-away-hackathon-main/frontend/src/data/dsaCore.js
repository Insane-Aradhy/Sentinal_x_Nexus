// ============================================================
// REAL DSA & MATHEMATICAL CORE ENGINE
// No timeouts, no fake delays. Real algorithms, real math.
// ============================================================

// ─────────────────────────────────────────────────────────────
// 1. K-D TREE (3D Spatial Partitioning)
// ─────────────────────────────────────────────────────────────
class KDNode {
  constructor(point, axis, left, right) {
    this.point = point; // { x, y, z, ...data }
    this.axis = axis; // 0 for x, 1 for y, 2 for z
    this.left = left;
    this.right = right;
  }
}

export class KDTree3D {
  constructor(points) {
    this.root = this.buildTree(points, 0);
  }

  buildTree(points, depth) {
    if (points.length === 0) return null;
    
    const axis = depth % 3;
    const sortedPoints = [...points].sort((a, b) => {
      if (axis === 0) return a.x - b.x;
      if (axis === 1) return a.y - b.y;
      return a.z - b.z;
    });

    const medianIndex = Math.floor(sortedPoints.length / 2);
    
    return new KDNode(
      sortedPoints[medianIndex],
      axis,
      this.buildTree(sortedPoints.slice(0, medianIndex), depth + 1),
      this.buildTree(sortedPoints.slice(medianIndex + 1), depth + 1)
    );
  }

  // Find all points within radius R of target
  rangeSearch(target, radius) {
    const results = [];
    const rSq = radius * radius;
    
    const search = (node) => {
      if (!node) return;

      const dx = node.point.x - target.x;
      const dy = node.point.y - target.y;
      const dz = node.point.z - target.z;
      const distSq = dx*dx + dy*dy + dz*dz;

      if (distSq <= rSq && node.point.id !== target.id) {
        results.push({ ...node.point, distance: Math.sqrt(distSq) });
      }

      const axis = node.axis;
      const targetCoord = axis === 0 ? target.x : (axis === 1 ? target.y : target.z);
      const nodeCoord = axis === 0 ? node.point.x : (axis === 1 ? node.point.y : node.point.z);

      // Check left/right branches
      if (targetCoord - radius <= nodeCoord) {
        search(node.left);
      }
      if (targetCoord + radius >= nodeCoord) {
        search(node.right);
      }
    };

    search(this.root);
    return results;
  }
}

// ─────────────────────────────────────────────────────────────
// 2. LARGE CATALOG GENERATOR (For Real Benchmarks)
// ─────────────────────────────────────────────────────────────
export function generateLargeCatalog(size = 27000) {
  const catalog = [];
  for (let i = 0; i < size; i++) {
    // Random distribution in LEO (Low Earth Orbit)
    const r = 6371 + 300 + Math.random() * 1000; // Earth radius + 300-1300km alt
    const theta = Math.random() * 2 * Math.PI;
    const phi = Math.acos(2 * Math.random() - 1);
    
    catalog.push({
      id: `SAT-${i}`,
      name: `Object ${i}`,
      x: r * Math.sin(phi) * Math.cos(theta),
      y: r * Math.sin(phi) * Math.sin(theta),
      z: r * Math.cos(phi),
    });
  }
  return catalog;
}

// ─────────────────────────────────────────────────────────────
// 3. FOSTER'S 1992 COLLISION PROBABILITY (Real 2D Integration)
// ─────────────────────────────────────────────────────────────
// The probability of collision Pc is the integral of the 2D Gaussian 
// over a circular cross-section defined by the Hard Body Radius (HBR).
// We implement a numerical integration over the circle in the B-plane.
export function calculateFostersPc(covA, covB, missVec, hbrMeters) {
  // 1. Combined Covariance in B-plane (2x2 matrix)
  // Let's assume the inputs covA and covB are already 2x2 projections in the B-plane.
  const C = [
    [covA[0][0] + covB[0][0], covA[0][1] + covB[0][1]],
    [covA[1][0] + covB[1][0], covA[1][1] + covB[1][1]]
  ];

  // 2. Determinant and Inverse of C
  const detC = C[0][0]*C[1][1] - C[0][1]*C[1][0];
  if (detC <= 0) return 0; // Degenerate covariance
  
  const invC = [
    [ C[1][1]/detC, -C[0][1]/detC],
    [-C[1][0]/detC,  C[0][0]/detC]
  ];

  // 3. Bivariate Gaussian PDF function
  const scale = 1.0 / (2 * Math.PI * Math.sqrt(detC));
  const pdf = (x, y) => {
    // Relative position from center of miss vector
    const dx = x - missVec[0];
    const dy = y - missVec[1];
    
    const exponent = -0.5 * (
      dx * (invC[0][0]*dx + invC[0][1]*dy) +
      dy * (invC[1][0]*dx + invC[1][1]*dy)
    );
    return scale * Math.exp(exponent);
  };

  // 4. Numerical Integration over Circular Region (Radius = HBR)
  // Using a grid-based Riemann sum or 2D Simpson's rule. For speed & accuracy, a dense grid:
  const hbrKm = hbrMeters / 1000.0;
  const N = 50; // Grid resolution
  const step = (2 * hbrKm) / N;
  let probability = 0;

  for (let i = 0; i < N; i++) {
    const x = -hbrKm + (i + 0.5) * step;
    for (let j = 0; j < N; j++) {
      const y = -hbrKm + (j + 0.5) * step;
      // Only integrate if inside the circle
      if (x*x + y*y <= hbrKm*hbrKm) {
        probability += pdf(x, y) * (step * step);
      }
    }
  }

  return Math.min(1.0, Math.max(0.0, probability));
}

// ─────────────────────────────────────────────────────────────
// 4. SGP4 MATH (Simplified Propagator for Demo)
// ─────────────────────────────────────────────────────────────
// Real Keplerian propagation from classical orbital elements.
export function propagateKepler(a, e, i, omega, RAAN, M0, meanMotion, timeMinutes) {
  const MU = 398600.4418;
  const M = M0 + (meanMotion * timeMinutes * 60);

  // Solve Kepler's Eq
  let E = M;
  for (let iter = 0; iter < 10; iter++) {
    E = E - (E - e * Math.sin(E) - M) / (1 - e * Math.cos(E));
  }

  // True anomaly
  const nu = 2 * Math.atan2(Math.sqrt(1 + e) * Math.sin(E / 2), Math.sqrt(1 - e) * Math.cos(E / 2));
  
  // Radius
  const r = a * (1 - e * Math.cos(E));
  const rPQW = [r * Math.cos(nu), r * Math.sin(nu), 0];

  const p = a * (1 - e * e);
  const vFactor = Math.sqrt(MU / p);
  const vPQW = [vFactor * (-Math.sin(nu)), vFactor * (e + Math.cos(nu)), 0];

  const cosO = Math.cos(RAAN), sinO = Math.sin(RAAN);
  const cosI = Math.cos(i), sinI = Math.sin(i);
  const cosW = Math.cos(omega), sinW = Math.sin(omega);

  const l1 = cosO * cosW - sinO * sinW * cosI;
  const l2 = -cosO * sinW - sinO * cosW * cosI;
  const m1 = sinO * cosW + cosO * sinW * cosI;
  const m2 = -sinO * sinW + cosO * cosW * cosI;
  const n1 = sinW * sinI;
  const n2 = cosW * sinI;

  return {
    position: [
      l1 * rPQW[0] + l2 * rPQW[1],
      m1 * rPQW[0] + m2 * rPQW[1],
      n1 * rPQW[0] + n2 * rPQW[1]
    ],
    velocity: [
      l1 * vPQW[0] + l2 * vPQW[1],
      m1 * vPQW[0] + m2 * vPQW[1],
      n1 * vPQW[0] + n2 * vPQW[1]
    ]
  };
}
