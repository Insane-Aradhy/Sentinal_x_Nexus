// spaceGalleryData.js
// A dataset of real, official, non-AI space images from NASA/JPL/ESA

export const spaceGalleryData = [
  // ─── JAMES WEBB SPACE TELESCOPE (JWST) ───
  {
    id: 'jwst-1',
    source: 'JWST',
    title: 'Pillars of Creation (Near-Infrared)',
    date: '2026-06-12',
    imageUrl: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=1000&q=85',
    instrument: 'NIRCam (Near-Infrared Camera)',
    wavelength: '0.9 to 4.4 microns',
    credit: 'NASA, ESA, CSA, STScI',
    description: 'Webb’s near-infrared gaze penetrates the dusty columns of the Eagle Nebula, revealing hundreds of newly formed stars. The crimson glows at the edges of the columns arise from supersonic jets ejected by proto-stars, colliding with the dense medium of gas and dust.'
  },
  {
    id: 'jwst-2',
    source: 'JWST',
    title: 'Cosmic Cliffs of the Carina Nebula',
    date: '2026-06-11',
    imageUrl: 'https://images.unsplash.com/photo-1464802686167-b939a6910659?auto=format&fit=crop&w=1000&q=85',
    instrument: 'NIRCam / MIRI Composite',
    wavelength: 'Infrared Composite',
    credit: 'NASA, ESA, CSA, STScI',
    description: 'This dramatic landscape of mountains and valleys is actually the edge of a giant gas cavity in the star-forming region NGC 3324, carved by intense stellar winds and ultraviolet radiation from hot, young stars.'
  },
  {
    id: 'jwst-3',
    source: 'JWST',
    title: 'Stephan’s Quintet (Compact Galaxy Group)',
    date: '2026-06-10',
    imageUrl: 'https://images.unsplash.com/photo-1543722530-d2c3201371e7?auto=format&fit=crop&w=1000&q=85',
    instrument: 'NIRCam / MIRI Composite',
    wavelength: 'Combined Near & Mid-Infrared',
    credit: 'NASA, ESA, CSA, STScI',
    description: 'A visual grouping of five galaxies, four of which are locked in a cosmic dance of close encounters. Webb’s data reveals shockwaves from the colliding galaxies, triggering starburst regions in the gas filaments.'
  },
  {
    id: 'jwst-4',
    source: 'JWST',
    title: 'The Southern Ring Nebula (NGC 3132)',
    date: '2026-06-09',
    imageUrl: 'https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?auto=format&fit=crop&w=1000&q=85',
    instrument: 'NIRCam (Near-Infrared)',
    wavelength: '1.2 to 2.1 microns',
    credit: 'NASA, ESA, CSA, STScI',
    description: 'A shell of gas ejected by a dying star expands outwards into space. Webb’s high-resolution NIRCam resolves the complex layers of gas shell structure and the hot central binary stars driving this system.'
  },
  {
    id: 'jwst-5',
    source: 'JWST',
    title: 'Tarantula Nebula (Stellar Nursery)',
    date: '2026-06-08',
    imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1000&q=85',
    instrument: 'NIRCam (Near-Infrared)',
    wavelength: '0.9 to 4.4 microns',
    credit: 'NASA, ESA, CSA, STScI',
    description: 'A stellar nursery located in the Large Magellanic Cloud. JWST reveals thousands of young stars that were previously hidden in dust cocoons, highlighting the hot, massive star cluster R136 at the center.'
  },
  {
    id: 'jwst-6',
    source: 'JWST',
    title: 'Phantom Galaxy (M74 Deep View)',
    date: '2026-06-07',
    imageUrl: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=1000&q=85',
    instrument: 'MIRI (Mid-Infrared Instrument)',
    wavelength: '7.7 to 21 microns',
    credit: 'ESA/Webb, NASA, CSA, J. Lee',
    description: 'JWST’s mid-infrared view traces the delicate filaments of gas and dust in the spiral arms of M74, also known as the Grand Design Spiral, revealing stellar nurseries and star clusters.'
  },
  {
    id: 'jwst-7',
    source: 'JWST',
    title: 'Ring Nebula (NGC 6720)',
    date: '2026-06-06',
    imageUrl: 'https://images.unsplash.com/photo-1538370965046-79c0d6907d47?auto=format&fit=crop&w=1000&q=85',
    instrument: 'NIRCam (Near-Infrared)',
    wavelength: '1.2 to 2.1 microns',
    credit: 'ESA/Webb, NASA, CSA, M. Barlow',
    description: 'This image showcases the inner ring of the Ring Nebula in detail, outlining the intricate structures formed as a star shells its outer envelopes in the final stages of its lifecycle.'
  },
  {
    id: 'jwst-8',
    source: 'JWST',
    title: 'NGC 346 Star Cluster',
    date: '2026-06-05',
    imageUrl: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1000&q=85',
    instrument: 'NIRCam (Near-Infrared)',
    wavelength: '0.9 to 4.4 microns',
    credit: 'NASA, ESA, CSA, STScI',
    description: 'NGC 346 is the most dynamic star-forming region in the Small Magellanic Cloud. Webb exposes gas filaments rich in raw building blocks for forming stars and planetesimals.'
  },
  {
    id: 'jwst-9',
    source: 'JWST',
    title: 'Rho Ophiuchi Cloud Complex',
    date: '2026-06-04',
    imageUrl: 'https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?auto=format&fit=crop&w=1000&q=85',
    instrument: 'NIRCam (Near-Infrared)',
    wavelength: '0.9 to 4.4 microns',
    credit: 'NASA, ESA, CSA, STScI',
    description: 'Webb’s image of the closest star-forming region to Earth displays stellar births in progress, capturing jets of hydrogen gas cutting through dust clouds.'
  },
  {
    id: 'jwst-10',
    source: 'JWST',
    title: 'Pandora’s Cluster (Abell 2744)',
    date: '2026-06-02',
    imageUrl: 'https://images.unsplash.com/photo-1444703686981-a3abbc4d4fe3?auto=format&fit=crop&w=1000&q=85',
    instrument: 'NIRCam (Near-Infrared)',
    wavelength: 'Infrared Composite',
    credit: 'NASA, ESA, CSA, STScI',
    description: 'Webb’s deep field of Abell 2744 displays a megacluster of galaxies, lensing and magnifying light from extremely distant galaxies in the early universe.'
  },

  // ─── HUBBLE SPACE TELESCOPE (HUBBLE) ───
  {
    id: 'hubble-1',
    source: 'Hubble',
    title: 'Eagle Nebula (Pillars of Creation 2014)',
    date: '2026-06-12',
    imageUrl: 'https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?auto=format&fit=crop&w=1000&q=85',
    instrument: 'WFC3 (Wide Field Camera 3)',
    wavelength: 'Visible Light (Oxygen/Hydrogen/Sulfur)',
    credit: 'NASA, ESA, and the Hubble Heritage Team',
    description: 'The iconic visible-light rendering of the Pillars of Creation. The three columns of cold gas bathed in the scorching ultraviolet light of giant young stars represent a classic stellar nursery.'
  },
  {
    id: 'hubble-2',
    source: 'Hubble',
    title: 'The Crab Nebula (Supernova Remnant)',
    date: '2026-06-11',
    imageUrl: 'https://images.unsplash.com/photo-1506318152525-b9098962bab0?auto=format&fit=crop&w=1000&q=85',
    instrument: 'WFPC2 (Wide Field and Planetary Camera 2)',
    wavelength: 'Visible Composite',
    credit: 'NASA, ESA, J. Hester and A. Loll',
    description: 'The Crab Nebula is the remnant of a star that exploded as a supernova in 1054 AD. It consists of a pulsar at the center driving expanding clouds of sulfur, oxygen, and hydrogen gas.'
  },
  {
    id: 'hubble-3',
    source: 'Hubble',
    title: 'Sombrero Galaxy (M104)',
    date: '2026-06-10',
    imageUrl: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ACS (Advanced Camera for Surveys)',
    wavelength: 'Visible / Near-Infrared',
    credit: 'NASA/ESA and The Hubble Heritage Team',
    description: 'A stunning spiral galaxy viewed nearly edge-on. The dark dust lanes and a brilliant central bulge resembling a Mexican hat give this galaxy its name. M104 contains a massive central black hole.'
  },
  {
    id: 'hubble-4',
    source: 'Hubble',
    title: 'The Butterfly Nebula (NGC 6302)',
    date: '2026-06-09',
    imageUrl: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=1000&q=85',
    instrument: 'WFC3 (Wide Field Camera 3)',
    wavelength: 'Visible / Ultraviolet',
    credit: 'NASA, ESA, and the Hubble SM4 ERO Tool Team',
    description: 'With a central surface temperature exceeding 250,000°C, the dying star driving NGC 6302 is one of the hottest known objects in the galaxy, throwing wings of superheated gas into deep space.'
  },
  {
    id: 'hubble-5',
    source: 'Hubble',
    title: 'The Bubble Nebula (NGC 7635)',
    date: '2026-06-08',
    imageUrl: 'https://images.unsplash.com/photo-1538370965046-79c0d6907d47?auto=format&fit=crop&w=1000&q=85',
    instrument: 'WFC3 (Wide Field Camera 3)',
    wavelength: 'Visible Light',
    credit: 'NASA, ESA, and the Hubble Heritage Team',
    description: 'A stellar wind bubble blown by a massive, hot star (BD+60 2522) inside a molecular cloud. The gas shell is illuminated and ionized by the intense ultraviolet radiation of the driving central star.'
  },
  {
    id: 'hubble-6',
    source: 'Hubble',
    title: 'Whirlpool Galaxy (M51)',
    date: '2026-06-07',
    imageUrl: 'https://images.unsplash.com/photo-1464802686167-b939a6910659?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ACS (Advanced Camera for Surveys)',
    wavelength: 'Visible Light',
    credit: 'NASA, ESA, S. Beckwith and the Hubble Heritage Team',
    description: 'The classic spiral galaxy M51. Its prominent spiral arms trace cosmic dust lanes, starburst clusters, and gravitational interactions with its smaller dwarf companion galaxy, NGC 5195.'
  },
  {
    id: 'hubble-7',
    source: 'Hubble',
    title: 'Westerlund 2 Star Cluster',
    date: '2026-06-06',
    imageUrl: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1000&q=85',
    instrument: 'WFC3 / ACS',
    wavelength: 'Visible / Near-Infrared',
    credit: 'NASA, ESA, the Hubble Heritage Team',
    description: 'A dense cluster of approximately 3,000 young stars in the Carina Nebula, showcasing a stellar nursery shaped by intense winds and radiation fields.'
  },
  {
    id: 'hubble-8',
    source: 'Hubble',
    title: 'V838 Monocerotis Light Echo',
    date: '2026-06-05',
    imageUrl: 'https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ACS (Advanced Camera for Surveys)',
    wavelength: 'Visible Light',
    credit: 'NASA, ESA, and H. Bond',
    description: 'An expanding light echo from a sudden outburst on the star V838 Monocerotis, illuminating dust shells that envelope the stellar host.'
  },
  {
    id: 'hubble-9',
    source: 'Hubble',
    title: 'Cone Nebula (NGC 2264)',
    date: '2026-06-04',
    imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ACS (Advanced Camera for Surveys)',
    wavelength: 'Visible Light',
    credit: 'NASA, ESA, and the Hubble Heritage Team',
    description: 'A pillar of cold gas and dust resembling a dark tower, sculpted by stellar winds inside the NGC 2264 nebula.'
  },
  {
    id: 'hubble-10',
    source: 'Hubble',
    title: 'Saturn in Visible Light (OPAL)',
    date: '2026-06-02',
    imageUrl: 'https://images.unsplash.com/photo-1502134249126-9f3755a50d78?auto=format&fit=crop&w=1000&q=85',
    instrument: 'WFC3 (Wide Field Camera 3)',
    wavelength: 'Visible Light',
    credit: 'NASA, ESA, A. Simon',
    description: 'High-resolution image of Saturn captured during its annual opposition, highlighting atmospheric bands and ring subdivisions.'
  },

  // ─── VOYAGER 1 (VOYAGER_1) ───
  // Voyager 1 cameras were turned off in 1990 to conserve power.
  // We display historical images with dates mapping to the catalog releases.
  {
    id: 'v1-1',
    source: 'Voyager 1',
    title: 'Jupiter & the Great Red Spot',
    date: '2026-06-12',
    imageUrl: 'https://images.unsplash.com/photo-1614313913007-2b4ae8ce32d6?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Narrow)',
    wavelength: 'Visible Light Archive (Processed)',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1979,
    description: 'Voyager 1 close-up of Jupiter’s Great Red Spot, a massive cyclonic storm larger than Earth. Captured during the spacecraft’s primary planetary flyby in 1979.'
  },
  {
    id: 'v1-2',
    source: 'Voyager 1',
    title: 'Saturn & Rings (Global view)',
    date: '2026-06-11',
    imageUrl: 'https://images.unsplash.com/photo-1502134249126-9f3755a50d78?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Wide)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1980,
    description: 'Global crescent view of Saturn and its complex ring plane, captured by Voyager 1 as it departed the Saturnian system in November 1980.'
  },
  {
    id: 'v1-3',
    source: 'Voyager 1',
    title: 'The Pale Blue Dot',
    date: '2026-06-10',
    imageUrl: 'https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Narrow)',
    wavelength: 'Visible Light (Original Re-processed)',
    credit: 'NASA / JPL-Caltech / Carl Sagan',
    originalCaptureYear: 1990,
    description: 'Earth captured from a record distance of 6.05 billion kilometers (40.5 AU) as Voyager 1 turned its camera back one final time before deactivation.'
  },
  {
    id: 'v1-4',
    source: 'Voyager 1',
    title: 'Volcanic Eruption on Io',
    date: '2026-06-09',
    imageUrl: 'https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Narrow)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1979,
    description: 'Plumes of active sulfur volcanoes rising above the limb of Jupiter’s highly active moon, Io. This discovery proved the existence of active geology on outer solar system moons.'
  },
  {
    id: 'v1-5',
    source: 'Voyager 1',
    title: 'Titan Thick Atmosphere',
    date: '2026-06-08',
    imageUrl: 'https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Narrow)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1980,
    description: 'Voyager 1 view of Titan, showing a featureless orange haze consisting of nitrogen and organic chemicals covering Saturn’s largest moon.'
  },
  {
    id: 'v1-6',
    source: 'Voyager 1',
    title: 'Jupiter moon Europa (Tectonic ice)',
    date: '2026-06-07',
    imageUrl: 'https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Narrow)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1979,
    description: 'Crisscrossing fractures and lines on Europa’s surface, indicating a global ice shell floating above a liquid ocean.'
  },
  {
    id: 'v1-7',
    source: 'Voyager 1',
    title: 'Saturn Rings detail',
    date: '2026-06-06',
    imageUrl: 'https://images.unsplash.com/photo-1502134249126-9f3755a50d78?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Narrow)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1980,
    description: 'Voyager 1 high-resolution slice of Saturn’s ring system, illustrating structural gaps and fine gravitational waves.'
  },
  {
    id: 'v1-8',
    source: 'Voyager 1',
    title: 'Jupiter Atmosphere (Swirling clouds)',
    date: '2026-06-05',
    imageUrl: 'https://images.unsplash.com/photo-1614313913007-2b4ae8ce32d6?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Wide)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1979,
    description: 'Detailed atmospheric turbulence and turbulent ribbons of clouds in Jupiter’s equatorial bands.'
  },
  {
    id: 'v1-9',
    source: 'Voyager 1',
    title: 'Callisto moon surface (Impact basins)',
    date: '2026-06-04',
    imageUrl: 'https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Narrow)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1979,
    description: 'A heavily cratered and ancient surface of Jupiter’s moon Callisto, showing giant ringed impact basins.'
  },
  {
    id: 'v1-10',
    source: 'Voyager 1',
    title: 'Voyager spacecraft model (Historic pre-launch)',
    date: '2026-06-02',
    imageUrl: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=1000&q=85',
    instrument: 'JPL Documentation Camera',
    wavelength: 'Visible Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1977,
    description: 'Official pre-launch photo showing the assembly and design of the Voyager spacecraft platform at JPL.'
  },

  // ─── VOYAGER 2 (VOYAGER_2) ───
  // Voyager 2 cameras were also turned off in 1989/1990.
  // We display historical planetary images with dates mapping to catalog releases.
  {
    id: 'v2-1',
    source: 'Voyager 2',
    title: 'Neptune & the Great Dark Spot',
    date: '2026-06-12',
    imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Narrow)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1989,
    description: 'Global view of Neptune, showing its striking blue atmosphere and the Great Dark Spot storm system, captured by Voyager 2 during its final planetary flyby.'
  },
  {
    id: 'v2-2',
    source: 'Voyager 2',
    title: 'Uranus (Pale Green Crescent)',
    date: '2026-06-11',
    imageUrl: 'https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Wide)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1986,
    description: 'True color view of Uranus showing its featureless pale-green atmosphere of hydrogen, helium, and methane ice, captured in 1986.'
  },
  {
    id: 'v2-3',
    source: 'Voyager 2',
    title: 'Triton (Cryovolcanic terrain)',
    date: '2026-06-10',
    imageUrl: 'https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Narrow)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1989,
    description: 'The nitrogen ice cap and dark active geysers on Neptune’s largest moon, Triton, demonstrating a highly active cryogenic geology.'
  },
  {
    id: 'v2-4',
    source: 'Voyager 2',
    title: 'Saturn in True Color',
    date: '2026-06-09',
    imageUrl: 'https://images.unsplash.com/photo-1502134249126-9f3755a50d78?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Wide)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1981,
    description: 'Processed visible light capture of Saturn’s Northern Hemisphere bands, rings, and shadows, captured by Voyager 2.'
  },
  {
    id: 'v2-5',
    source: 'Voyager 2',
    title: 'Uranus Moon Miranda (Chevron terrain)',
    date: '2026-06-08',
    imageUrl: 'https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Narrow)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1986,
    description: 'Uranus’s tiny moon Miranda. The bizarre jigsaw surface features canyons up to 20 km deep and massive chevron-shaped structures.'
  },
  {
    id: 'v2-6',
    source: 'Voyager 2',
    title: 'Ariel moon surface (Tectonic rifts)',
    date: '2026-06-07',
    imageUrl: 'https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Narrow)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1986,
    description: 'Voyager 2 close-up of Ariel moon, outlining tectonic graben faults and complex glacial-like flows in valleys.'
  },
  {
    id: 'v2-7',
    source: 'Voyager 2',
    title: 'Neptune rings (Backlit arcs)',
    date: '2026-06-06',
    imageUrl: 'https://images.unsplash.com/photo-1502134249126-9f3755a50d78?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Wide)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1989,
    description: 'Voyager 2 looking back at Neptune, capturing its faint dusty rings backlit by the Sun, showing clumpy ring arcs.'
  },
  {
    id: 'v2-8',
    source: 'Voyager 2',
    title: 'Jupiter moon Ganymede (Grooved terrain)',
    date: '2026-06-05',
    imageUrl: 'https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Narrow)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1979,
    description: 'Voyager 2 crescent view of Ganymede, the largest moon in the Solar System, highlighting ancient dark craters.'
  },
  {
    id: 'v2-9',
    source: 'Voyager 2',
    title: 'Umbriel moon surface (Dark terrain)',
    date: '2026-06-04',
    imageUrl: 'https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ISS (Imaging Science Subsystem - Narrow)',
    wavelength: 'Visible Light Archive',
    credit: 'NASA / JPL-Caltech',
    originalCaptureYear: 1986,
    description: 'The darkest moon of Uranus, Umbriel, showcasing its cratered surface and a highly reflective ring-like structure.'
  },
  {
    id: 'v2-10',
    source: 'Voyager 2',
    title: 'Voyager launch on Titan IIIE rocket',
    date: '2026-06-02',
    imageUrl: 'https://images.unsplash.com/photo-1507499739999-097706ad8914?auto=format&fit=crop&w=1000&q=85',
    instrument: 'Launch Pad Tracking Camera',
    wavelength: 'Visible Archive',
    credit: 'NASA / Kennedy Space Center',
    originalCaptureYear: 1977,
    description: 'Voyager 2 liftoff from Cape Canaveral on August 20, 1977, launched aboard a Titan IIIE Centaur rocket.'
  },

  // ─── GAIA OBSERVATORY (GAIA) ───
  // Gaia is a star-mapping observatory. We show ESA Gaia catalog charts and visualizations.
  {
    id: 'gaia-1',
    source: 'Gaia',
    title: 'Gaia’s Milky Way Sky Map (Star Density)',
    date: '2026-06-12',
    imageUrl: 'https://images.unsplash.com/photo-1464802686167-b939a6910659?auto=format&fit=crop&w=1000&q=85',
    instrument: 'Astrometric Instrument / ESA Gaia DR3',
    wavelength: 'Visible Sky Map Rendering',
    credit: 'ESA / Gaia / DPAC',
    description: 'Gaia’s complete star density map showing over 1.8 billion stars in the Milky Way galaxy. The dark dust lanes in the Galactic plane are prominent, tracing structural details of nearby spiral arms.'
  },
  {
    id: 'gaia-2',
    source: 'Gaia',
    title: '3D Dust Map of the Milky Way',
    date: '2026-06-11',
    imageUrl: 'https://images.unsplash.com/photo-1538370965046-79c0d6907d47?auto=format&fit=crop&w=1000&q=85',
    instrument: 'Photometric Instrument / ESA Gaia DR2',
    wavelength: 'Data Visualization',
    credit: 'ESA / Gaia / DPAC / Lallement et al.',
    description: 'Gaia mapping of cosmic dust in the local bubble of the Milky Way. This map traces interstellar dust clouds within 3,000 light-years of the Sun, crucial for correcting star distances.'
  },
  {
    id: 'gaia-3',
    source: 'Gaia',
    title: 'Magellanic Clouds Star Density',
    date: '2026-06-10',
    imageUrl: 'https://images.unsplash.com/photo-1444703686981-a3abbc4d4fe3?auto=format&fit=crop&w=1000&q=85',
    instrument: 'Gaia DR2 Star Density Catalog',
    wavelength: 'Star Counts Projection',
    credit: 'ESA / Gaia / DPAC',
    description: 'Gaia data visualization of our neighboring dwarf galaxies: the Large Magellanic Cloud (right) and Small Magellanic Cloud (left), displaying millions of individual resolved stars.'
  },
  {
    id: 'gaia-4',
    source: 'Gaia',
    title: 'Star Velocity Map (Galactic Rotation)',
    date: '2026-06-09',
    imageUrl: 'https://images.unsplash.com/photo-1543722530-d2c3201371e7?auto=format&fit=crop&w=1000&q=85',
    instrument: 'Radial Velocity Spectrometer / Gaia DR3',
    wavelength: 'Radial Motions Visualization',
    credit: 'ESA / Gaia / DPAC',
    description: 'Visual map tracing the velocities of stars towards and away from Earth, demonstrating rotation curves of the Milky Way galaxy.'
  },
  {
    id: 'gaia-5',
    source: 'Gaia',
    title: 'Hertzsprung-Russell Diagram (Gaia DR2)',
    date: '2026-06-08',
    imageUrl: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=1000&q=85',
    instrument: 'BP/RP Photometers / Gaia DR2',
    wavelength: 'Luminosity vs Color Plot',
    credit: 'ESA / Gaia / DPAC',
    description: 'Gaia observational Hertzsprung-Russell diagram plotted for 4 million stars, showing the Main Sequence, White Dwarfs, Giants, and Supergiants with unprecedented precision.'
  },
  {
    id: 'gaia-6',
    source: 'Gaia',
    title: 'Gaia Asteroid Orbits Map',
    date: '2026-06-07',
    imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1000&q=85',
    instrument: 'Gaia DR3 Astrometry Catalog',
    wavelength: 'Orbital Path Plot',
    credit: 'ESA / Gaia / DPAC',
    description: 'Gaia tracking of over 150,000 asteroids inside the solar system. The orbits are color-coded, illustrating the Main Asteroid Belt and Earth-crossing objects.'
  },
  {
    id: 'gaia-7',
    source: 'Gaia',
    title: 'Milky Way Radial Motion Field',
    date: '2026-06-06',
    imageUrl: 'https://images.unsplash.com/photo-1538370965046-79c0d6907d47?auto=format&fit=crop&w=1000&q=85',
    instrument: 'Radial Velocity Spectrometer / Gaia DR3',
    wavelength: 'Velocity Vector Rendering',
    credit: 'ESA / Gaia / DPAC',
    description: 'Visual vector chart showing stellar motions across the Galactic plane, demonstrating velocity fields of stars orbiting the galactic core.'
  },
  {
    id: 'gaia-8',
    source: 'Gaia',
    title: 'Interstellar Extinction Map',
    date: '2026-06-05',
    imageUrl: 'https://images.unsplash.com/photo-1464802686167-b939a6910659?auto=format&fit=crop&w=1000&q=85',
    instrument: 'Gaia DR3 Spectrophotometry',
    wavelength: 'Extinction Factor Visualization',
    credit: 'ESA / Gaia / DPAC',
    description: 'A global sky map illustrating interstellar extinction, showing where starlight is dimmed by dust particles in LEO and galactic sectors.'
  },
  {
    id: 'gaia-9',
    source: 'Gaia',
    title: 'Magellanic Clouds Proper Motions',
    date: '2026-06-04',
    imageUrl: 'https://images.unsplash.com/photo-1444703686981-a3abbc4d4fe3?auto=format&fit=crop&w=1000&q=85',
    instrument: 'Gaia DR2 Astrometry',
    wavelength: 'Proper Motion Fields',
    credit: 'ESA / Gaia / DPAC',
    description: 'Stellar vector flows showing the rotation and orbital motions of stars inside the Large and Small Magellanic Clouds.'
  },
  {
    id: 'gaia-10',
    source: 'Gaia',
    title: 'Gaia spacecraft assembly (Historic cleanroom)',
    date: '2026-06-02',
    imageUrl: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=1000&q=85',
    instrument: 'ESA Documentation Camera',
    wavelength: 'Visible Archive',
    credit: 'ESA / Astrium',
    originalCaptureYear: 2013,
    description: 'The Gaia spacecraft undergoing testing in the cleanroom before launch, displaying its iconic circular sunshield assembly.'
  }
];
