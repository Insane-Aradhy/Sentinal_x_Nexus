import json

with open('App.jsx', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Add autoscroll to TourPointer
pointer_code = '''function TourPointer({ step, currentStep, totalSteps, theme, onNext, onEnd }) {
  React.useEffect(() => {
    // If it's a step that points down to the top tabs, scroll to top!
    if (step.arrow === 'down' && step.title && step.title.includes('STEP')) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [step]);
'''
if 'React.useEffect(() => {' not in content:
    content = content.replace('function TourPointer({ step, currentStep, totalSteps, theme, onNext, onEnd }) {', pointer_code)

# 2. Fix Astro Full Tour
astro_tour_full = """
  'astro': {
    theme: 'pink',
    steps: [
      {
        id: 'astro-intro',
        title: 'STEP 1: Astro-Computation Engine',
        desc: 'Welcome to the Astro-Computation Engine. Here you can run actual physics simulations natively in your browser.',
        arrow: 'down',
        position: { top: 320, left: 'calc(50% - 250px)' }
      },
      {
        id: 'astro-divisions',
        title: 'STEP 2: 4 Mathematical Divisions',
        desc: 'We have broken down orbital mechanics into 4 distinct tools. They cover propagation, collision probability, avoidance, and reentry.',
        arrow: 'up',
        position: { top: 380, left: '50%', transform: 'translateX(-50%)' }
      },
      // ════ DIV 1 ════
      {
        id: 'astro-div1',
        title: 'STEP 3: 01. SGP4 / SDP4 Propagator',
        desc: 'Let\\'s explore Division 1. Click on the highlighted "01. SGP4 / SDP4" division button.',
        arrow: 'down',
        position: { top: 320, left: 'calc(50% - 250px)' },
        waitForClick: true,
      },
      {
        id: 'astro-sgp4-desc',
        title: 'STEP 4: Satellite General Perturbation 4',
        desc: 'SGP4 models the orbital state of Earth-orbiting satellites. It calculates position and velocity vectors by factoring in Earth\\'s oblateness and atmospheric drag. PLEASE SCROLL DOWN.',
        arrow: 'up',
        position: { top: '35%', left: '30%', transform: 'translateX(-50%)' },
      },
      {
        id: 'astro-catalog',
        title: 'STEP 5: Real Object Catalog',
        desc: 'Select a real-world object from the satellite catalog. These are parsed from live TLEs.',
        arrow: 'up',
        position: { top: 580, left: '25%' }
      },
      {
        id: 'astro-select',
        title: 'STEP 6: Integration Time',
        desc: 'Select how far into the future you want to predict (e.g. 24 Hours).',
        arrow: 'up',
        position: { top: 720, left: '15%' }
      },
      {
        id: 'astro-run-sgp4',
        title: 'STEP 7: Run SGP4 Propagation',
        desc: 'Click "Run SGP4" to generate the future ECI coordinates.',
        arrow: 'left',
        position: { top: 720, left: 300 }
      },
      {
        id: 'astro-run-search',
        title: 'STEP 8: DSA Spatial Proximity Search',
        desc: 'Now click "Run Proximity Search". The engine uses a k-d Tree algorithm to rapidly scan the 28,000 object catalog to find the closest threats to our predicted position.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-sgp4-complete',
        title: 'STEP 9: SGP4 Results',
        desc: 'The SGP4 engine has successfully computed the future state and spatial proximity! Click NEXT to continue.',
        arrow: 'up',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }
      },
      // ════ DIV 2 ════
      {
        id: 'astro-div2',
        title: 'STEP 10: 02. Foster\\'s Collision Probability',
        desc: 'Now let\\'s evaluate collision risk! Click on the highlighted "02. Foster\\'s Pc" division button at the top. (Scroll up if needed)',
        arrow: 'down',
        position: { top: 320, left: 'calc(50% - 100px)' },
        waitForClick: true,
      },
      {
        id: 'astro-foster-desc',
        title: 'STEP 11: 2D Gaussian B-Plane Integration',
        desc: 'Foster\\'s Pc projects 3D covariances to the 2D B-plane and performs Riemann Quadrature integration over the combined hard-body radius. PLEASE SCROLL DOWN.',
        arrow: 'down',
        position: { top: '40%', left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'astro-foster-primary',
        title: 'STEP 12: Select Primary Object',
        desc: 'First, select the Primary Object. This represents our asset (e.g. ISS or satellite) whose collision risk we are evaluating.',
        arrow: 'up',
        position: { top: 580, left: '25%' }
      },
      {
        id: 'astro-foster-secondary',
        title: 'STEP 13: Select Secondary Object (Threat)',
        desc: 'Next, select the Secondary Object. This represents the incoming threat or debris that might collide with our asset.',
        arrow: 'up',
        position: { top: 580, left: '75%' }
      },
      {
        id: 'astro-foster-run',
        title: 'STEP 14: Run Mathematical Integration',
        desc: 'Click "Run Mathematical Integration" to compute the collision probability (Pc) in real-time. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-foster-complete',
        title: 'STEP 15: Integration Results',
        desc: 'The 2D Gaussian B-Plane Integration is complete, giving us the exact Probability of Collision (Pc)! Click NEXT to continue.',
        arrow: 'up',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }
      },
      // ════ DIV 3 ════
      {
        id: 'astro-div3',
        title: 'STEP 16: 03. Delta-V Optimizer',
        desc: 'Next, let\\'s plan avoidance maneuvers. Click on the highlighted "03. Delta-V Optimizer" division button at the top.',
        arrow: 'down',
        position: { top: 320, left: 'calc(50% + 50px)' },
        waitForClick: true,
      },
      {
        id: 'astro-deltav-desc',
        title: 'STEP 17: Hohmann Transfer Mathematics',
        desc: 'This module calculates the optimal two-burn Hohmann transfer to change orbits. It computes the Vis-viva equations and maps the required fuel expenditure. PLEASE SCROLL DOWN.',
        arrow: 'down',
        position: { top: '40%', left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'astro-deltav-run',
        title: 'STEP 18: Calculate Optimal Maneuver',
        desc: 'Click "Calculate Optimal Maneuver" to derive the Δv1, Δv2, and estimated propellant mass required. PLEASE SCROLL DOWN.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-deltav-complete',
        title: 'STEP 19: Maneuver Results',
        desc: 'The optimal two-burn Hohmann transfer has been calculated to achieve radial clearance while minimizing propellant expenditure. Click NEXT to continue.',
        arrow: 'up',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }
      },
      // ════ DIV 4 ════
      {
        id: 'astro-div4',
        title: 'STEP 20: 04. Orbital Decay Predictor',
        desc: 'Finally, let\\'s predict atmospheric reentry. Click on the highlighted "04. Reentry Predictor" division button at the top.',
        arrow: 'down',
        position: { top: 320, left: 'calc(50% + 200px)' },
        waitForClick: true,
      },
      {
        id: 'astro-reentry-desc',
        title: 'STEP 21: Atmospheric Drag Integration',
        desc: 'This tool factors in atmospheric density models (NRLMSISE-00 approximation) and ballistic coefficients to calculate the decay rate. PLEASE SCROLL DOWN.',
        arrow: 'down',
        position: { top: '40%', left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'astro-reentry-run',
        title: 'STEP 22: Predict Reentry Date',
        desc: 'Click "Predict Reentry Date". The engine will iterate the atmospheric drag models and project the Kármán line boundary intersection, giving the satellite\\'s structural lifetime. PLEASE SCROLL DOWN.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-reentry-complete',
        title: 'STEP 23: Reentry Results',
        desc: 'The atmospheric drag numerical integration is complete, yielding the structural orbital lifetime and decay curve. Click NEXT to finish the tour.',
        arrow: 'up',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }
      },
      {
        id: 'astro-complete',
        title: 'TOUR COMPLETE',
        desc: 'You have explored all 4 mathematical divisions of the Astro-Computation Engine. Feel free to run your own calculations!',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }
      }
    ]
  },
"""

import re
content = re.sub(r"'astro': \{.*?    \]\n  \},", astro_tour_full, content, flags=re.DOTALL)

# Add foster specific tour missing steps
astro_foster_tour = """
  'astro-foster': {
    theme: 'pink',
    steps: [
      {
        id: 'foster-desc',
        title: 'STEP 1: 2D Gaussian B-Plane Integration',
        desc: 'Foster\\'s Pc projects 3D covariances to the 2D B-plane and performs Riemann Quadrature integration over the combined hard-body radius. PLEASE SCROLL DOWN.',
        arrow: 'down',
        position: { top: '40%', left: '50%', transform: 'translateX(-50%)' },
      },
      {
        id: 'foster-primary',
        title: 'STEP 2: Select Primary Object',
        desc: 'First, select the Primary Object. This represents our asset (e.g. ISS or satellite) whose collision risk we are evaluating.',
        arrow: 'up',
        position: { top: 580, left: '25%' }
      },
      {
        id: 'foster-secondary',
        title: 'STEP 3: Select Secondary Object (Threat)',
        desc: 'Next, select the Secondary Object. This represents the incoming threat or debris that might collide with our asset.',
        arrow: 'up',
        position: { top: 580, left: '75%' }
      },
      {
        id: 'foster-run',
        title: 'STEP 4: Run Mathematical Integration',
        desc: 'Click "Run Mathematical Integration" to compute the collision probability (Pc) in real-time. PLEASE SCROLL DOWN.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'foster-complete',
        title: 'Tour Complete!',
        desc: 'The engine successfully calculated the collision probability. You can observe the results below!',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }
      }
    ]
  },
"""
content = re.sub(r"'astro-foster': \{.*?    \]\n  \},", astro_foster_tour, content, flags=re.DOTALL)


with open('App.jsx', 'w', encoding='utf-8') as f:
    f.write(content)
