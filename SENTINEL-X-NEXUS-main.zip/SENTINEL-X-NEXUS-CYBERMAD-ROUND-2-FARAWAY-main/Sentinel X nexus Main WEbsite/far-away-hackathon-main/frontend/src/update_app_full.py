import re
import sys

app_path = "App.jsx"
with open(app_path, "r", encoding="utf-8") as f:
    content = f.read()

# Add to astro-sgp4
sgp4_end_target = """      {
        id: 'astro-run-search',
        title: 'STEP 8: Spatial Proximity Search',
        desc: 'Our engine uses k-d Trees to perform spatial proximity searches in O(log n) time. Click "Run Proximity Search". The outcome will instantly list the closest objects and query time! PLEASE SCROLL DOWN to see the button.',
        arrow: 'right',
        position: { top: 'calc(50% + 50px)', right: '42%' },
        waitForClick: true,
      },
    ]
  },"""

sgp4_end_replacement = """      {
        id: 'astro-run-search',
        title: 'STEP 8: Spatial Proximity Search',
        desc: 'Our engine uses k-d Trees to perform spatial proximity searches in O(log n) time. Click "Run Proximity Search". The outcome will instantly list the closest objects and query time! PLEASE SCROLL DOWN to see the button.',
        arrow: 'right',
        position: { top: 'calc(50% + 50px)', right: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-sgp4-complete',
        title: 'STEP 9: SGP4 Tour Complete!',
        desc: 'You have successfully run the SGP4 Propagator and Spatial Proximity Search. The mathematical engine has output the results.',
        arrow: 'up',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' },
        width: 420,
      }
    ]
  },"""
content = content.replace(sgp4_end_target, sgp4_end_replacement)

# Add to astro-foster
foster_end_target = """      {
        id: 'astro-foster-run',
        title: 'STEP 4: Run Mathematical Integration',
        desc: 'Click "Run Mathematical Integration" to evaluate the collision probability over the combined hard-body radius. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      }
    ]
  },"""
foster_end_replacement = """      {
        id: 'astro-foster-run',
        title: 'STEP 4: Run Mathematical Integration',
        desc: 'Click "Run Mathematical Integration" to evaluate the collision probability over the combined hard-body radius. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'foster-complete',
        title: 'STEP 5: Foster\\'s Pc Tour Complete!',
        desc: 'You have successfully executed the 2D Gaussian B-Plane Integration to evaluate collision probability.',
        arrow: 'up',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' },
        width: 420,
      }
    ]
  },"""
content = content.replace(foster_end_target, foster_end_replacement)


# Add to astro-deltav
deltav_end_target = """      {
        id: 'astro-deltav-run',
        title: 'STEP 4: Calculate Optimal Maneuver',
        desc: 'Click "Calculate Optimal Maneuver" to simulate the burn vectors and compute required Delta-V and fuel mass. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      }
    ]
  },"""
deltav_end_replacement = """      {
        id: 'astro-deltav-run',
        title: 'STEP 4: Calculate Optimal Maneuver',
        desc: 'Click "Calculate Optimal Maneuver" to simulate the burn vectors and compute required Delta-V and fuel mass. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'deltav-complete',
        title: 'STEP 5: Delta-V Optimizer Complete!',
        desc: 'You have successfully planned the optimal avoidance maneuver using the Vis-Viva and Tsiolkovsky equations.',
        arrow: 'up',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' },
        width: 420,
      }
    ]
  },"""
content = content.replace(deltav_end_target, deltav_end_replacement)


# Add to astro-reentry
reentry_end_target = """      {
        id: 'astro-reentry-run',
        title: 'STEP 4: Predict Reentry Date',
        desc: 'Click "Predict Reentry Date" to evaluate structural orbital lifetime and decay curve. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      }
    ]
  }"""
reentry_end_replacement = """      {
        id: 'astro-reentry-run',
        title: 'STEP 4: Predict Reentry Date',
        desc: 'Click "Predict Reentry Date" to evaluate structural orbital lifetime and decay curve. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'reentry-complete',
        title: 'STEP 5: Reentry Predictor Complete!',
        desc: 'You have successfully calculated the orbital decay timeline using the Atmospheric Drag Numerical Integrator.',
        arrow: 'up',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' },
        width: 420,
      }
    ]
  }"""
content = content.replace(reentry_end_target, reentry_end_replacement)

with open(app_path, "w", encoding="utf-8") as f:
    f.write(content)
print("Updated App.jsx successfully.")
