import re

def main():
    # ── UPDATE ASTRONOMICALFEATURES.JSX ──────────────────────────────────────────
    with open('components/AstronomicalFeatures.jsx', 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Update active tab pill conditions for Delta-V and Reentry
    # Tab 3 (Delta-V)
    content = content.replace(
        "className={`term-pill ${activeDivision === 3 ? 'orange' : 'muted'} ${((isDeltavTour && tourStep === 1) || (isFullTour && tourStep === 15)) ? 'tour-blink-pink' : ''}`}",
        "className={`term-pill ${activeDivision === 3 ? 'orange' : 'muted'} ${((isDeltavTour && tourStep === 1) || (isFullTour && tourStep === 15)) ? 'tour-blink-pink' : ''}`}"
    )
    content = content.replace(
        "if (isFullTour && tourStep === 15) setTourStep(16);",
        "if (isFullTour && tourStep === 15) setTourStep(16);"
    )

    # Tab 4 (Reentry)
    content = content.replace(
        "className={`term-pill ${activeDivision === 4 ? 'red' : 'muted'} ${((isReentryTour && tourStep === 1) || (isFullTour && tourStep === 19)) ? 'tour-blink-pink' : ''}`}",
        "className={`term-pill ${activeDivision === 4 ? 'red' : 'muted'} ${((isReentryTour && tourStep === 1) || (isFullTour && tourStep === 21)) ? 'tour-blink-pink' : ''}`}"
    )
    content = content.replace(
        "if (isFullTour && tourStep === 19) setTourStep(20);",
        "if (isFullTour && tourStep === 21) setTourStep(22);"
    )

    # 2. Update Delta-V Division elements (Satellite select, Clearance input, Run button, handleCompute steps)
    # Target Delta-V Select
    deltav_select_target = """            <div style={{flex: 1}}>
              <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Select Satellite (m₀ = 1500kg)</label>
              <select className="prop-select" style={{width: '100%', borderColor: 'var(--yellow)'}} value={selectedSatIndex} onChange={e => {setSelectedSatIndex(Number(e.target.value)); setResults(null); setProgressStep(0);}}>"""
    
    deltav_select_replacement = """            <div style={{flex: 1}}>
              <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Select Satellite (m₀ = 1500kg)</label>
              <select 
                className={`prop-select ${((isDeltavTour && tourStep === 3) || (isFullTour && tourStep === 17)) ? 'tour-blink-pink' : ''}`} 
                style={{width: '100%', borderColor: 'var(--yellow)'}} 
                value={selectedSatIndex} 
                onChange={e => {setSelectedSatIndex(Number(e.target.value)); setResults(null); setProgressStep(0);}}
              >"""
    content = content.replace(deltav_select_target, deltav_select_replacement)

    # Clearance Target Input
    deltav_input_target = """            <div style={{flex: 1}}>
              <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Radial Clearance Target (km)</label>
              <input 
                type="number" 
                className="prop-select" 
                style={{width: '100%', borderColor: 'var(--yellow)'}}"""

    deltav_input_replacement = """            <div style={{flex: 1}}>
              <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Radial Clearance Target (km)</label>
              <input 
                type="number" 
                className={`prop-select ${((isDeltavTour && tourStep === 4) || (isFullTour && tourStep === 18)) ? 'tour-blink-pink' : ''}`} 
                style={{width: '100%', borderColor: 'var(--yellow)'}}"""
    content = content.replace(deltav_input_target, deltav_input_replacement)

    # Delta-V Run Button
    deltav_btn_target = """          <button 
            className={`prop-btn ${((isDeltavTour && tourStep === 3) || (isFullTour && tourStep === 17)) ? 'tour-blink-pink' : ''}`}"""
    
    deltav_btn_replacement = """          <button 
            className={`prop-btn ${((isDeltavTour && tourStep === 5) || (isFullTour && tourStep === 19)) ? 'tour-blink-pink' : ''}`}"""
    content = content.replace(deltav_btn_target, deltav_btn_replacement)

    # Delta-V handleCompute timeouts
    deltav_timeouts_target = """            if (isDeltavTour && tourStep === 3 && setTourStep) setTourStep(4);
            if (isFullTour && tourStep === 17 && setTourStep) setTourStep(18);"""

    deltav_timeouts_replacement = """            if (isDeltavTour && tourStep === 5 && setTourStep) setTourStep(6);
            if (isFullTour && tourStep === 19 && setTourStep) setTourStep(20);"""
    content = content.replace(deltav_timeouts_target, deltav_timeouts_replacement)


    # 3. Update Reentry Division elements (Satellite select, Run button, handleCompute steps)
    # Reentry Satellite Select
    reentry_select_target = """            <div style={{flex: 1}}>
              <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Select Satellite</label>
              <select className="prop-select" style={{width: '100%', borderColor: 'var(--red)'}} value={selectedSatIndex} onChange={e => {setSelectedSatIndex(Number(e.target.value)); setResults(null); setProgressStep(0);}}>"""

    reentry_select_replacement = """            <div style={{flex: 1}}>
              <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Select Satellite</label>
              <select 
                className={`prop-select ${((isReentryTour && tourStep === 3) || (isFullTour && tourStep === 23)) ? 'tour-blink-pink' : ''}`} 
                style={{width: '100%', borderColor: 'var(--red)'}} 
                value={selectedSatIndex} 
                onChange={e => {setSelectedSatIndex(Number(e.target.value)); setResults(null); setProgressStep(0);}}
              >"""
    content = content.replace(reentry_select_target, reentry_select_replacement)

    # Reentry Run Button
    reentry_btn_target = """          <button 
            className={`prop-btn ${((isReentryTour && tourStep === 3) || (isFullTour && tourStep === 21)) ? 'tour-blink-pink' : ''}`}"""
    
    reentry_btn_replacement = """          <button 
            className={`prop-btn ${((isReentryTour && tourStep === 4) || (isFullTour && tourStep === 24)) ? 'tour-blink-pink' : ''}`}"""
    content = content.replace(reentry_btn_target, reentry_btn_replacement)

    # Reentry handleCompute timeouts
    reentry_timeouts_target = """            if (isReentryTour && tourStep === 3 && setTourStep) setTourStep(4);
            if (isFullTour && tourStep === 21 && setTourStep) setTourStep(22);"""

    reentry_timeouts_replacement = """            if (isReentryTour && tourStep === 4 && setTourStep) setTourStep(5);
            if (isFullTour && tourStep === 24 && setTourStep) setTourStep(25);"""
    content = content.replace(reentry_timeouts_target, reentry_timeouts_replacement)

    # 4. Write back to AstronomicalFeatures.jsx
    with open('components/AstronomicalFeatures.jsx', 'w', encoding='utf-8') as f:
        f.write(content)
    print("AstronomicalFeatures.jsx updated with select choice step hooks.")

if __name__ == '__main__':
    main()
