/**
 * useBackend.js — WebSocket hook for SENTINEL × NEXUS backend
 * 
 * Connects to the backend WebSocket and streams real satellite data.
 * Falls back gracefully to mock data if the backend is not running.
 *
 * The backend URL is read from VITE_WS_URL (set this in your .env or
 * in your Vercel project's Environment Variables when deploying).
 * Defaults to ws://localhost:8000/ws for local development.
 *
 * Returns: { positions, conjunctions, systemStatus, connected }
 */

import { useState, useEffect, useRef, useCallback } from 'react'
import { conjunctionEvents as mockConjunctions, systemStatus as mockStatus } from '../data/mockData'

const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:8000/ws'
const RECONNECT_DELAY_MS = 4000

export function useBackend() {
  const [positions,         setPositions]         = useState([])
  const [conjunctions,      setConjunctions]      = useState(mockConjunctions)
  const [systemStatus,      setSystemStatus]      = useState(mockStatus)
  const [sentinelDecisions, setSentinelDecisions] = useState([])
  const [nexusMessages,     setNexusMessages]     = useState([])
  const [connected,         setConnected]         = useState(false)

  const wsRef       = useRef(null)
  const retryRef    = useRef(null)
  const mountedRef  = useRef(true)

  const connect = useCallback(() => {
    if (!mountedRef.current) return
    if (wsRef.current?.readyState === WebSocket.OPEN) return

    console.log('[WS] Connecting to backend…')

    try {
      const ws = new WebSocket(WS_URL)
      wsRef.current = ws

      ws.onopen = () => {
        if (!mountedRef.current) { ws.close(); return }
        console.log('[WS] ✓ Connected to SENTINEL backend')
        setConnected(true)
      }

      ws.onmessage = (evt) => {
        if (!mountedRef.current) return
        try {
          const msg = JSON.parse(evt.data)
          switch (msg.type) {
            case 'satellite_positions':
              setPositions(msg.data || [])
              break
            case 'conjunction_events':
              if (msg.data?.length > 0) setConjunctions(msg.data)
              break
            case 'sentinel_decisions':
              if (msg.data?.length > 0) setSentinelDecisions(msg.data)
              break
            case 'nexus_message':
              setNexusMessages(prev => [...prev, msg.data])
              break
            case 'system_status':
              setSystemStatus(prev => ({ ...prev, ...msg.data }))
              break
            case 'keepalive':
              ws.send('ping')
              break
            default:
              break
          }
        } catch (e) {
          console.warn('[WS] Failed to parse message:', e)
        }
      }

      ws.onerror = () => {
        // Suppress console noise — backend may not be running yet
      }

      ws.onclose = () => {
        if (!mountedRef.current) return
        setConnected(false)
        console.log(`[WS] Disconnected — retrying in ${RECONNECT_DELAY_MS / 1000}s`)
        retryRef.current = setTimeout(connect, RECONNECT_DELAY_MS)
      }
    } catch (e) {
      retryRef.current = setTimeout(connect, RECONNECT_DELAY_MS)
    }
  }, [])

  useEffect(() => {
    mountedRef.current = true
    connect()
    return () => {
      mountedRef.current = false
      clearTimeout(retryRef.current)
      wsRef.current?.close()
    }
  }, [connect])

  // Function to trigger NEXUS debate
  const triggerNexusDebate = (eventId) => {
    setNexusMessages([]) // Clear previous debate
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'trigger_nexus_debate',
        eventId: eventId
      }))
    }
  }

  return { positions, conjunctions, systemStatus, sentinelDecisions, nexusMessages, connected, triggerNexusDebate }
}
