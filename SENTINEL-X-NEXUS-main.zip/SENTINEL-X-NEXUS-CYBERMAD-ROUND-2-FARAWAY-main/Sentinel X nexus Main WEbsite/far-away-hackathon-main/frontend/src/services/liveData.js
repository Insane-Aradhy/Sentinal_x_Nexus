/**
 * liveData.js — Real-Time Data Services
 * ========================================
 * Fetches live satellite TLEs from Celestrak and Near-Earth Object
 * asteroid data from NASA's NeoWs API.
 *
 * APIs used:
 *  - Celestrak GP JSON API (public, no key needed)
 *    https://celestrak.org/SPACETRACK/query/class/gp/...
 *  - NASA NeoWs (Near Earth Object Web Service) (DEMO_KEY: 30 req/hr)
 *    https://api.nasa.gov/neo/rest/v1/feed
 *  - Backend proxy /api/neo (preferred — avoids CORS, higher reliability)
 */

// ── Celestrak Live TLE Fetch ──────────────────────────────────────────────────
const CELESTRAK_GP_BASE = 'https://celestrak.org/SPACETRACK/query/class/gp'

const CURATED_NORAD_IDS = [
  '25544',  // ISS
  '48274',  // CSS (Tiangong)
  '44233',  // CARTOSAT-3
  '54361',  // EOS-06
  '41877',  // RESOURCESAT-2A
  '44441',  // GSAT-30
  '20580',  // Hubble
  '49140',  // STARLINK-3456
  '49141',  // STARLINK-3457
  '52550',  // ONEWEB satellite
  '37820',  // COSMOS 2546 DEB
  '29228',  // FENGYUN 1C DEB
  '43642',  // CZ-4 DEB
  '33765',  // IRIDIUM 33 DEB
  '22566',  // SL-8 DEB
].join(',')

/**
 * Fetch live TLE data from Celestrak's public GP JSON API.
 * Returns array of { name, noradId, line1, line2 }
 * Falls back to empty array on CORS/network failure.
 */
export async function fetchLiveTLEs() {
  const urls = [
    `${CELESTRAK_GP_BASE}/CATNR/${CURATED_NORAD_IDS}/format/json`,
    `${CELESTRAK_GP_BASE}/GROUP/stations/format/json`,
  ]

  for (const url of urls) {
    try {
      const res = await fetch(url, {
        headers: { 'Accept': 'application/json' },
        signal: AbortSignal.timeout(8000),
      })
      if (!res.ok) continue
      const data = await res.json()
      if (!Array.isArray(data) || data.length === 0) continue

      const mapped = data
        .filter(s => s.TLE_LINE1 && s.TLE_LINE2)
        .map(s => ({
          name:    (s.OBJECT_NAME || '').trim(),
          noradId: s.NORAD_CAT_ID,
          line1:   s.TLE_LINE1,
          line2:   s.TLE_LINE2,
        }))

      console.log(`[LiveData] ✓ Fetched ${mapped.length} live TLEs from Celestrak`)
      return mapped
    } catch (err) {
      console.warn(`[LiveData] Celestrak fetch failed (${url}):`, err.message)
    }
  }

  console.warn('[LiveData] All Celestrak endpoints failed — using backend TLEs')
  return []
}

// ── NASA NeoWs Asteroid Fetch ─────────────────────────────────────────────────
const NASA_NEO_BASE = 'https://api.nasa.gov/neo/rest/v1'
const NASA_API_KEY  = 'Z31bIfistkx3c2bhR3upE672zwDT56hRigeO0uop'  // Replace with your key for higher limits

// Backend proxy URL — read from VITE_BACKEND_URL (set this in your .env or
// in your Vercel project's Environment Variables when deploying).
// Defaults to http://localhost:8000 for local development.
const BACKEND_BASE  = import.meta.env.VITE_BACKEND_URL || 'http://localhost:8000'

/**
 * Fetch Near-Earth Objects for the next N days.
 * Tries the backend proxy first (avoids CORS + rate limits),
 * then falls back to direct NASA API call.
 *
 * Returns array of NEO objects sorted by miss distance (closest first).
 * @param {number} days — how many days ahead to look (max 7 per NASA limit)
 */
export async function fetchNearEarthObjects(days = 7) {
  // ── 1. Try backend proxy ──────────────────────────────────────────────────
  try {
    const res = await fetch(`${BACKEND_BASE}/api/neo?days=${days}`, {
      signal: AbortSignal.timeout(15000),
    })
    if (res.ok) {
      const json = await res.json()
      if (json.data && json.data.length > 0) {
        console.log(`[LiveData] ✓ Fetched ${json.data.length} NEOs via backend proxy`)
        return json.data
      }
    }
  } catch (_) {
    console.warn('[LiveData] Backend NEO proxy unavailable — calling NASA directly')
  }

  // ── 2. Direct NASA NeoWs call ─────────────────────────────────────────────
  const today   = new Date()
  const endDate = new Date(Date.now() + days * 86_400_000)
  const fmt     = (d) => d.toISOString().split('T')[0]
  const url     = `${NASA_NEO_BASE}/feed?start_date=${fmt(today)}&end_date=${fmt(endDate)}&api_key=${NASA_API_KEY}`

  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(12000) })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const json = await res.json()

    const allNEOs = Object.entries(json.near_earth_objects).flatMap(([date, neos]) =>
      neos.map(neo => ({ ...neo, _approachDate: date }))
    )

    allNEOs.sort((a, b) => {
      const aMiss = parseFloat(a.close_approach_data?.[0]?.miss_distance?.kilometers ?? Infinity)
      const bMiss = parseFloat(b.close_approach_data?.[0]?.miss_distance?.kilometers ?? Infinity)
      return aMiss - bMiss
    })

    console.log(`[LiveData] ✓ Fetched ${allNEOs.length} NEOs from NASA NeoWs (direct)`)
    return allNEOs
  } catch (err) {
    console.warn('[LiveData] NASA NeoWs fetch failed:', err.message)
    return []
  }
}

/**
 * Fetch detailed info for a single asteroid by NASA ID.
 * Returns the full NASA asteroid object with orbital data.
 */
export async function fetchAsteroidDetail(asteroidId) {
  try {
    const url = `${NASA_NEO_BASE}/neo/${asteroidId}?api_key=${NASA_API_KEY}`
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    return await res.json()
  } catch (err) {
    console.warn(`[LiveData] Failed to fetch asteroid ${asteroidId}:`, err.message)
    return null
  }
}

// ── Utility helpers ───────────────────────────────────────────────────────────

/** Format a kilometer distance with appropriate units */
export function formatDistance(km) {
  if (km >= 1_000_000) return `${(km / 1_000_000).toFixed(2)}M km`
  if (km >= 1_000)     return `${(km / 1_000).toFixed(2)}k km`
  return `${km.toFixed(0)} km`
}

/** Lunar distance (1 LD ≈ 384,400 km) */
export function toLunarDistances(km) {
  return (km / 384_400).toFixed(2)
}

/** Risk color based on miss distance + hazard flag */
export function asteroidRiskColor(neo) {
  if (neo.is_potentially_hazardous_asteroid) return '#f87171'  // red
  const missKm = parseFloat(neo.close_approach_data?.[0]?.miss_distance?.kilometers ?? Infinity)
  if (missKm < 1_000_000)  return '#fbbf24'  // yellow — within 1M km
  if (missKm < 5_000_000)  return '#60a5fa'  // blue — watchlist
  return '#4ade80'                            // green — safe
}

/** Estimated diameter string */
export function formatDiameter(neo) {
  const d = neo.estimated_diameter?.kilometers
  if (!d) return '—'
  const mn = d.estimated_diameter_min.toFixed(3)
  const mx = d.estimated_diameter_max.toFixed(3)
  return `${mn} – ${mx} km`
}

/** Relative velocity string */
export function formatVelocity(neo) {
  const v = parseFloat(neo.close_approach_data?.[0]?.relative_velocity?.kilometers_per_second)
  if (isNaN(v)) return '—'
  return `${v.toFixed(2)} km/s`
}
