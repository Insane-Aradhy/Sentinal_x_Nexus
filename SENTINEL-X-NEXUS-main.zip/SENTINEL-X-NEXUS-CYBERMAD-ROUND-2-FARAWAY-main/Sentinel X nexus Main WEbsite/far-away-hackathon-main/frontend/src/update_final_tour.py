import re
import sys

def main():
    # 1. FIX CSS ANIMATION
    with open('App.css', 'r', encoding='utf-8') as f:
        css = f.read()
    
    # We remove transform from bounce-highlight so it only animates margin or something, or we can just use top offset
    css = css.replace('transform: translateY(0);', 'margin-top: 0px;')
    css = css.replace('transform: translateY(-8px);', 'margin-top: -8px;')
    
    with open('App.css', 'w', encoding='utf-8') as f:
        f.write(css)

    # 2. UPDATE APP.JSX
    with open('App.jsx', 'r', encoding='utf-8') as f:
        app = f.read()

    # Foster completion for individual tour
    app = app.replace('''      {
        id: 'foster-run',
        title: 'STEP 4: Run Mathematical Integration',
        desc: 'Click "Run Mathematical Integration". The engine will project covariances to the B-plane and solve the Riemann Quadrature to evaluate the exact collision risk. PLEASE SCROLL DOWN if you cannot see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      }
    ]
  },
  'astro-deltav': {''', '''      {
        id: 'foster-run',
        title: 'STEP 4: Run Mathematical Integration',
        desc: 'Click "Run Mathematical Integration". The engine will project covariances to the B-plane and solve the Riemann Quadrature to evaluate the exact collision risk. PLEASE SCROLL DOWN if you cannot see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'foster-complete',
        title: 'STEP 5: Foster\\'s Pc Results',
        desc: 'The mathematical integration is complete! You can now review the probability of collision.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      }
    ]
  },
  'astro-deltav': {''')

    # Delta-V completion for individual tour
    app = app.replace('''      {
        id: 'deltav-run',
        title: 'STEP 4: Calculate Maneuver',
        desc: 'Click "Calculate Delta-V". The optimizer will use Tsiolkovsky\\'s rocket equation and Vis-viva mechanics to find the minimum-energy transfer. PLEASE SCROLL DOWN if you cannot see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      }
    ]
  },
  'astro-reentry': {''', '''      {
        id: 'deltav-run',
        title: 'STEP 4: Calculate Maneuver',
        desc: 'Click "Calculate Delta-V". The optimizer will use Tsiolkovsky\\'s rocket equation and Vis-viva mechanics to find the minimum-energy transfer. PLEASE SCROLL DOWN if you cannot see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'deltav-complete',
        title: 'STEP 5: Maneuver Plan Results',
        desc: 'Optimization complete! You can now review the required propellant and burn parameters.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      }
    ]
  },
  'astro-reentry': {''')

    # Reentry completion for individual tour
    app = app.replace('''      {
        id: 'reentry-run',
        title: 'STEP 4: Predict Reentry',
        desc: 'Click "Predict Decay & Reentry". The engine will integrate the atmospheric drag models to estimate when this object will burn up in the atmosphere. PLEASE SCROLL DOWN if you cannot see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      }
    ]
  }
};''', '''      {
        id: 'reentry-run',
        title: 'STEP 4: Predict Reentry',
        desc: 'Click "Predict Decay & Reentry". The engine will integrate the atmospheric drag models to estimate when this object will burn up in the atmosphere. PLEASE SCROLL DOWN if you cannot see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'reentry-complete',
        title: 'STEP 5: Reentry Prediction Results',
        desc: 'Reentry prediction complete! You can now review the estimated decay time and final altitude.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      }
    ]
  }
};''')


    # Foster completion for Full Tour
    app = app.replace('''      {
        id: 'astro-foster-run',
        title: 'STEP 11: Run Mathematical Integration',
        desc: 'Click "Run Mathematical Integration" to compute the collision probability (Pc) in real-time. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-div3',
        title: 'STEP 12: 03. Delta-V Optimizer',''', '''      {
        id: 'astro-foster-run',
        title: 'STEP 11: Run Mathematical Integration',
        desc: 'Click "Run Mathematical Integration" to compute the collision probability (Pc) in real-time. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-foster-complete',
        title: 'STEP 12: Foster\\'s Pc Results',
        desc: 'The mathematical integration is complete! You can now review the probability of collision. Click NEXT to continue.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      },
      {
        id: 'astro-div3',
        title: 'STEP 13: 03. Delta-V Optimizer',''')

    # Fix numbering for full tour after step 12
    app = app.replace('STEP 13: Vis-Viva & Tsiolkovsky Optimization', 'STEP 14: Vis-Viva & Tsiolkovsky Optimization')
    app = app.replace('STEP 14: Calculate Maneuver', 'STEP 15: Calculate Maneuver')

    # Delta-V completion for Full Tour
    app = app.replace('''      {
        id: 'astro-deltav-run',
        title: 'STEP 15: Calculate Maneuver',
        desc: 'Click "Calculate Delta-V". The optimizer will use Tsiolkovsky\\'s rocket equation to find the minimum-energy transfer. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-div4',
        title: 'STEP 15: 04. Orbital Decay Predictor',''', '''      {
        id: 'astro-deltav-run',
        title: 'STEP 15: Calculate Maneuver',
        desc: 'Click "Calculate Delta-V". The optimizer will use Tsiolkovsky\\'s rocket equation to find the minimum-energy transfer. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-deltav-complete',
        title: 'STEP 16: Maneuver Plan Results',
        desc: 'Optimization complete! You can now review the required propellant and burn parameters. Click NEXT to continue.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      },
      {
        id: 'astro-div4',
        title: 'STEP 17: 04. Orbital Decay Predictor',''')

    # Fix numbering for full tour after step 17
    app = app.replace('STEP 16: Atmospheric Drag Integration', 'STEP 18: Atmospheric Drag Integration')
    app = app.replace('STEP 17: Predict Reentry', 'STEP 19: Predict Reentry')

    # Reentry completion for Full Tour
    app = app.replace('''      {
        id: 'astro-reentry-run',
        title: 'STEP 19: Predict Reentry',
        desc: 'Click "Predict Decay & Reentry". The engine will integrate the atmospheric drag models to estimate when this object will burn up in the atmosphere. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-complete',
        title: 'STEP 18: Astro-Computation Complete!',''', '''      {
        id: 'astro-reentry-run',
        title: 'STEP 19: Predict Reentry',
        desc: 'Click "Predict Decay & Reentry". The engine will integrate the atmospheric drag models to estimate when this object will burn up in the atmosphere. PLEASE SCROLL DOWN to see the button.',
        arrow: 'left',
        position: { top: 'calc(50% + 50px)', left: '42%' },
        waitForClick: true,
      },
      {
        id: 'astro-reentry-complete',
        title: 'STEP 20: Reentry Prediction Results',
        desc: 'Reentry prediction complete! You can now review the estimated decay time and final altitude. Click NEXT to continue.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      },
      {
        id: 'astro-complete',
        title: 'STEP 21: Astro-Computation Complete!',''')

    # Make sure SGP4 complete does not have arrow up so it centers properly
    app = app.replace('''      {
        id: 'astro-sgp4-complete',
        title: 'STEP 9: SGP4 Tour Complete!',
        desc: 'You have successfully run the SGP4 Propagator and Spatial Proximity Search. The mathematical engine has output the results.',
        arrow: 'up',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' },
        width: 420,
      }''', '''      {
        id: 'astro-sgp4-complete',
        title: 'STEP 9: SGP4 Tour Complete!',
        desc: 'You have successfully run the SGP4 Propagator and Spatial Proximity Search. The mathematical engine has output the results.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      }''')

    app = app.replace('''      {
        id: 'astro-sgp4-complete',
        title: 'STEP 9: SGP4 Results',
        desc: 'The SGP4 engine has successfully computed the future state and spatial proximity! Click NEXT to continue.',
        arrow: 'up',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }
      },''', '''      {
        id: 'astro-sgp4-complete',
        title: 'STEP 9: SGP4 Results',
        desc: 'The SGP4 engine has successfully computed the future state and spatial proximity! Click NEXT to continue.',
        arrow: 'none',
        position: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0 },
        width: 420,
      },''')
      
    # Also fix autoscroll conditions to match the new numbering
    # Foster is 13, DeltaV is 17
    # Wait, Foster tab click is Step 10: 'STEP 10: 02. Foster\\'s Collision Probability'
    # Delta-V tab click is Step 13: 'STEP 13: 03. Delta-V Optimizer'
    # Reentry tab click is Step 17: 'STEP 17: 04. Orbital Decay Predictor'
    app = app.replace("if (step.arrow === 'up' && step.title && step.title.includes('STEP') && (step.title.includes(' 3:') || step.title.includes('10:') || step.title.includes('16:') || step.title.includes('20:'))) {",
    "if (step.arrow === 'up' && step.title && step.title.includes('STEP') && (step.title.includes(' 3:') || step.title.includes('10:') || step.title.includes('13:') || step.title.includes('17:'))) {")

    with open('App.jsx', 'w', encoding='utf-8') as f:
        f.write(app)


    # 3. UPDATE AstronomicalFeatures.jsx
    with open('components/AstronomicalFeatures.jsx', 'r', encoding='utf-8') as f:
        astro = f.read()

    # In Foster's Pc handleCompute
    # Full tour goes from 13 (run) -> 14 (complete) instead of 13 -> 14 (div3)
    astro = astro.replace('if (isFullTour && tourStep === 13 && setTourStep) setTourStep(14);', 'if (isFullTour && tourStep === 13 && setTourStep) setTourStep(14); // Now points to foster-complete')
    # Foster individual tour goes from 3 (run) -> 4 (complete) instead of 3 -> end
    astro = astro.replace('if (isFosterTour && tourStep === 3 && setTourStep) setTourStep(4);', 'if (isFosterTour && tourStep === 3 && setTourStep) setTourStep(4); // Now points to foster-complete')

    # In DeltaV handleCalculate
    # Full tour goes from 17 (run) -> 18 (complete)
    # But previously I had 'if (isFullTour && tourStep === 17 && setTourStep) setTourStep(18);' which was pointing to astro-complete!
    astro = astro.replace('if (isFullTour && tourStep === 17 && setTourStep) setTourStep(18);', 'if (isFullTour && tourStep === 15 && setTourStep) setTourStep(16); // Now points to deltav-complete')
    astro = astro.replace('if (isDeltavTour && tourStep === 3 && setTourStep) setTourStep(4);', 'if (isDeltavTour && tourStep === 3 && setTourStep) setTourStep(4); // Now points to deltav-complete')

    # In Reentry handlePredict
    # Full tour goes from 19 (run) -> 20 (complete)
    astro = astro.replace('if (isFullTour && tourStep === 21 && setTourStep) setTourStep(22);', 'if (isFullTour && tourStep === 18 && setTourStep) setTourStep(19);')
    # Actually, in full tour, Reentry run is STEP 19. The array index is 18!
    # So tourStep === 18!
    astro = astro.replace('if (isFullTour && tourStep === 18 && setTourStep) setTourStep(19);', 'if (isFullTour && tourStep === 18 && setTourStep) setTourStep(19); // Now points to reentry-complete')

    with open('components/AstronomicalFeatures.jsx', 'w', encoding='utf-8') as f:
        f.write(astro)

if __name__ == '__main__':
    main()
