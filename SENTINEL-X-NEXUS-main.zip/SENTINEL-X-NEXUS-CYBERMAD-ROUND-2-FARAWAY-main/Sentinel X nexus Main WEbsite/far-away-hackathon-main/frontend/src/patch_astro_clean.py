import re

def patch_astro_jsx():
    with open('components/AstronomicalFeatures.jsx', 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Update Division navigation tabs
    tab_nav = """        {/* Division Navigation */}
        <div className="terms-row fade-in-up delay-1" style={{ marginBottom: '32px' }}>
          <button 
            className={`term-pill ${activeDivision === 1 ? 'green' : 'muted'} ${((isSgp4Tour && tourStep === 2) || (isFullTour && tourStep === 2)) ? 'tour-blink-pink' : ''}`} 
            onClick={() => {
              setActiveDivision(1);
              if (isSgp4Tour && tourStep === 2) setTourStep(3);
              if (isFullTour && tourStep === 2) setTourStep(3);
            }} 
            style={{ cursor: 'pointer', padding: '6px 16px', fontSize: '11px' }}
          >
            01. SGP4 / SDP4
          </button>
          <button 
            className={`term-pill ${activeDivision === 2 ? 'blue' : 'muted'} ${((isFosterTour && tourStep === 1) || (isFullTour && tourStep === 9)) ? 'tour-blink-pink' : ''}`} 
            onClick={() => {
              setActiveDivision(2);
              if (isFosterTour && tourStep === 1) setTourStep(2);
              if (isFullTour && tourStep === 9) setTourStep(10);
            }} 
            style={{ cursor: 'pointer', padding: '6px 16px', fontSize: '11px' }}
          >
            02. Foster's Pc
          </button>
          <button 
            className={`term-pill ${activeDivision === 3 ? 'orange' : 'muted'} ${((isDeltavTour && tourStep === 1) || (isFullTour && tourStep === 15)) ? 'tour-blink-pink' : ''}`} 
            onClick={() => {
              setActiveDivision(3);
              if (isDeltavTour && tourStep === 1) setTourStep(2);
              if (isFullTour && tourStep === 15) setTourStep(16);
            }} 
            style={{ cursor: 'pointer', padding: '6px 16px', fontSize: '11px', borderColor: activeDivision === 3 ? 'var(--yellow)' : '', color: activeDivision === 3 ? 'var(--yellow)' : '' }}
          >
            03. Delta-V Optimizer
          </button>
          <button 
            className={`term-pill ${activeDivision === 4 ? 'red' : 'muted'} ${((isReentryTour && tourStep === 1) || (isFullTour && tourStep === 19)) ? 'tour-blink-pink' : ''}`} 
            onClick={() => {
              setActiveDivision(4);
              if (isReentryTour && tourStep === 1) setTourStep(2);
              if (isFullTour && tourStep === 19) setTourStep(20);
            }} 
            style={{ cursor: 'pointer', padding: '6px 16px', fontSize: '11px', borderColor: activeDivision === 4 ? 'var(--red)' : '', color: activeDivision === 4 ? 'var(--red)' : '' }}
          >
            04. Reentry Predictor
          </button>
        </div>"""

    content = re.sub(r"\{\/\* Division Navigation \*\/\}.*?\{\/\* Divisions \*\/\}", tab_nav + "\n\n        {/* Divisions */}", content, flags=re.DOTALL)

    # 2. Foster's Pc Dropdowns and Button
    # Replace Primary and Secondary dropdown JSX
    foster_dropdowns = """      <div className="dsa-toggle-section" style={{display: 'flex', gap: '16px', marginBottom: '24px'}}>
        <div style={{flex: 1}}>
          <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Select Primary Object</label>
          <select 
            className={`prop-select ${((isFosterTour && tourStep === 3) || (isFullTour && tourStep === 11)) ? 'tour-blink-pink' : ''}`}
            style={{width: '100%', borderColor: 'var(--blue-line)'}} 
            value={primaryIdx} 
            onChange={e => {setPrimaryIdx(Number(e.target.value)); setResults(null); setProgressStep(0);}}
          >
            {satelliteCatalog.map((sat, idx) => (
              <option key={idx} value={idx}>{sat.noradId} — {sat.name} ({sat.type})</option>
            ))}
          </select>
        </div>
        <div style={{flex: 1}}>
          <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Select Secondary Object (Threat)</label>
          <select 
            className={`prop-select ${((isFosterTour && tourStep === 4) || (isFullTour && tourStep === 12)) ? 'tour-blink-pink' : ''}`}
            style={{width: '100%', borderColor: 'var(--red)'}} 
            value={secondaryIdx} 
            onChange={e => {setSecondaryIdx(Number(e.target.value)); setResults(null); setProgressStep(0);}}
          >
            {satelliteCatalog.map((sat, idx) => (
              <option key={idx} value={idx}>{sat.noradId} — {sat.name} ({sat.type})</option>
            ))}
          </select>
        </div>
      </div>"""

    content = re.sub(r'<div className="dsa-toggle-section" style=\{\{display: \'flex\', gap: \'16px\', marginBottom: \'24px\'\}\}>.*?<\/div>\s*<\/div>\s*<\/div>', foster_dropdowns, content, count=1, flags=re.DOTALL)

    # Foster Run button blink and handleCompute tourStep
    foster_btn = """          <button 
            className={`prop-btn ${((isFosterTour && tourStep === 5) || (isFullTour && tourStep === 13)) ? 'tour-blink-pink' : ''}`} 
            onClick={handleCompute}
            disabled={calculating}
            style={{ width: '100%', justifyContent: 'center', borderColor: 'var(--blue-line)', color: 'var(--blue)' }}
          >
            {calculating ? <span className="spinner"></span> : '∫'} 
            {calculating ? 'Executing Pipeline...' : 'Run Mathematical Integration'}
          </button>"""
    
    content = re.sub(r'<button\s+className=\{`prop-btn \$\{.*?\}`\}\s+onClick=\{handleCompute\}\s+disabled=\{calculating\}.*?<\/button>', foster_btn, content, count=1, flags=re.DOTALL)

    # Foster handleCompute timeout
    foster_timeout = """      setTimeout(() => {
        setProgressStep(2);
        setTimeout(() => {
          setProgressStep(3);
          setTimeout(() => {
            setProgressStep(4);
            setCalculating(false);
            if (isFosterTour && tourStep === 5 && setTourStep) setTourStep(6);
            if (isFullTour && tourStep === 13 && setTourStep) setTourStep(14);
          }, 600 + Math.random() * 500);
        }, 1100 + Math.random() * 600);
      }, 700 + Math.random() * 400);"""

    content = re.sub(r"setResults\(data\);\s*setTimeout\(\(\) => \{\s*setProgressStep\(2\);.*?setCalculating\(false\);.*?\}, 700 \+ Math\.random\(\) \* 400\);", "setResults(data);\n      \n" + foster_timeout, content, count=1, flags=re.DOTALL)


    # 3. Delta-V Run button and handleCompute timeout
    deltav_btn = """          <button 
            className={`prop-btn ${((isDeltavTour && tourStep === 3) || (isFullTour && tourStep === 17)) ? 'tour-blink-pink' : ''}`} 
            onClick={handleCompute}
            disabled={computing}
            style={{ width: '100%', justifyContent: 'center', borderColor: 'var(--yellow)', color: 'var(--yellow)', marginBottom: '24px' }}
          >
            {computing ? <span className="spinner"></span> : '🔥'} 
            {computing ? 'Executing Pipeline...' : 'Calculate Optimal Maneuver'}
          </button>"""

    content = re.sub(r'<button\s+className=\{`prop-btn \$\{.*?\}`\}\s+onClick=\{handleCompute\}\s+disabled=\{computing\}.*?style=\{\{\s*width:\s*\'100%\',\s*justifyContent:\s*\'center\',\s*borderColor:\s*\'var\(--yellow\)\'.*?<\/button>', deltav_btn, content, count=1, flags=re.DOTALL)

    deltav_timeout = """      setTimeout(() => {
        setProgressStep(2);
        setTimeout(() => {
          setProgressStep(3);
          setTimeout(() => {
            setProgressStep(4);
            setComputing(false);
            if (isDeltavTour && tourStep === 3 && setTourStep) setTourStep(4);
            if (isFullTour && tourStep === 17 && setTourStep) setTourStep(18);
          }, 500 + Math.random() * 400);
        }, 900 + Math.random() * 500);
      }, 600 + Math.random() * 300);"""

    content = re.sub(r"function DivisionThreeDeltaV.*?setResults\(data\);.*?setComputing\(false\);.*?\},\s*600\s*\+\s*Math\.random\(\)\s*\*\s*300\);(?:\s*setTimeout.*?\},\s*600\s*\+\s*Math\.random\(\)\s*\*\s*300\);)?", lambda m: re.sub(r"setResults\(data\);.*", "setResults(data);\n\n" + deltav_timeout, m.group(0), flags=re.DOTALL), content, count=1, flags=re.DOTALL)


    # 4. Reentry Run button and handleCompute timeout
    reentry_btn = """          <button 
            className={`prop-btn ${((isReentryTour && tourStep === 3) || (isFullTour && tourStep === 21)) ? 'tour-blink-pink' : ''}`} 
            onClick={handleCompute}
            disabled={computing}
            style={{ width: '100%', justifyContent: 'center', borderColor: 'var(--red)', color: 'var(--red)', marginBottom: '24px' }}
          >
            {computing ? <span className="spinner"></span> : '☄️'} 
            {computing ? 'Executing Pipeline...' : 'Predict Reentry Date'}
          </button>"""

    content = re.sub(r'<button\s+className=\{`prop-btn \$\{.*?\}`\}\s+onClick=\{handleCompute\}\s+disabled=\{computing\}.*?style=\{\{\s*width:\s*\'100%\',\s*justifyContent:\s*\'center\',\s*borderColor:\s*\'var\(--red\)\'.*?<\/button>', reentry_btn, content, count=1, flags=re.DOTALL)

    reentry_timeout = """      setTimeout(() => {
        setProgressStep(2);
        setTimeout(() => {
          setProgressStep(3);
          setTimeout(() => {
            setProgressStep(4);
            setComputing(false);
            if (isReentryTour && tourStep === 3 && setTourStep) setTourStep(4);
            if (isFullTour && tourStep === 21 && setTourStep) setTourStep(22);
          }, 700 + Math.random() * 500);
        }, 1200 + Math.random() * 600);
      }, 800 + Math.random() * 400);"""

    content = re.sub(r"function DivisionFourReentry.*?setResults\(data\);.*?setComputing\(false\);.*?\},\s*800\s*\+\s*Math\.random\(\)\s*\*\s*400\);(?:\s*setTimeout.*?\},\s*700\s*\+\s*Math\.random\(\)\s*\*\s*300\);)?", lambda m: re.sub(r"setResults\(data\);.*", "setResults(data);\n\n" + reentry_timeout, m.group(0), flags=re.DOTALL), content, count=1, flags=re.DOTALL)

    with open('components/AstronomicalFeatures.jsx', 'w', encoding='utf-8') as f:
        f.write(content)
    print("AstronomicalFeatures.jsx patched successfully.")

if __name__ == '__main__':
    patch_astro_jsx()
