const fs = require('fs');
const path = 'd:/SACS Hackathons 2026-27/far away/frontend/src/components/AstronomicalFeatures.jsx';
let content = fs.readFileSync(path, 'utf8');

const div2Idx = content.indexOf("// DIVISION 2: FOSTER'S 1992 PROBABILITY CALCULATOR (Real Math)");
if (div2Idx === -1) throw new Error("Could not find Division 2");

const newContent = `// DIVISION 2: FOSTER'S 1992 PROBABILITY CALCULATOR (Real Math)
// ════════════════════════════════════════════════════════════════════════════
function DivisionTwoFosterPc() {
  const [calculating, setCalculating] = useState(false);
  const [progressStep, setProgressStep] = useState(0);
  const [results, setResults] = useState(null);
  
  const [primaryIdx, setPrimaryIdx] = useState(0);
  const [secondaryIdx, setSecondaryIdx] = useState(10);

  const primary = satelliteCatalog[primaryIdx];
  const secondary = satelliteCatalog[secondaryIdx];

  const handleCompute = () => {
    if(calculating) return;
    setCalculating(true);
    setProgressStep(1);
    setResults(null);
    
    setTimeout(() => {
      const start = performance.now();
      const pId = parseInt(primary.noradId) || 12345;
      const sId = parseInt(secondary.noradId) || 54321;

      const scaleP = primary.type === 'DEBRIS' ? 2.5 : 1.0;
      const scaleS = secondary.type === 'DEBRIS' ? 3.0 : 1.2;

      const covPrimary = [
        [32400.0 * scaleP, 1500.0 * scaleP],
        [1500.0 * scaleP, 14400.0 * scaleP]
      ];
      const covSecondary = [
        [8100.0 * scaleS, -500.0 * scaleS],
        [-500.0 * scaleS, 2500.0 * scaleS]
      ];
      
      const dx = ((pId * sId) % 1000) - 500;
      const dy = (((pId + sId) * 13) % 1000) - 500;
      const missVec = [dx, dy]; 
      const actualMissDistance = Math.sqrt(dx*dx + dy*dy);
      
      const hbrP = primary.rcs === 'LARGE' ? 12.0 : (primary.rcs === 'MEDIUM' ? 6.0 : 2.0);
      const hbrS = secondary.rcs === 'LARGE' ? 12.0 : (secondary.rcs === 'MEDIUM' ? 6.0 : 2.0);
      const hardBodyRadius = hbrP + hbrS;

      const Pc = calculateFostersPc(covPrimary, covSecondary, missVec, hardBodyRadius);
      const elapsed = performance.now() - start;

      const data = {
        probability: Pc,
        timeMs: elapsed.toFixed(3),
        scientificNotation: Pc > 0 ? Pc.toExponential(4) : "0.0000e+0",
        riskLevel: Pc > 1e-4 ? 'RED' : (Pc > 1e-5 ? 'YELLOW' : 'GREEN'),
        missDistance: actualMissDistance.toFixed(1),
        hbr: hardBodyRadius.toFixed(1),
        covPrimary,
        covSecondary
      };

      setResults(data);
      
      // Uneven organic timings
      setTimeout(() => {
        setProgressStep(2);
        setTimeout(() => {
          setProgressStep(3);
          setTimeout(() => {
            setProgressStep(4);
            setCalculating(false);
          }, 600 + Math.random() * 500);
        }, 1100 + Math.random() * 600);
      }, 700 + Math.random() * 400);

    }, 50);
  };

  return (
    <div className="fade-in-up delay-2">
      <div className="division-header">
        <div className="division-number" style={{color: 'var(--blue)'}}>02</div>
        <div className="division-title-group">
          <div className="division-eyebrow" style={{color: 'var(--blue)'}}>2D Gaussian Numerical Integration</div>
          <h2 className="division-title">Foster's Probability of Collision (Pc)</h2>
          <div className="division-tagline">Real 2D quadrature integration executing in your browser natively. Select real objects to compare.</div>
        </div>
      </div>

      <div className="dsa-toggle-section" style={{display: 'flex', gap: '16px', marginBottom: '24px'}}>
        <div style={{flex: 1}}>
          <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Select Primary Object</label>
          <select className="prop-select" style={{width: '100%', borderColor: 'var(--blue-line)'}} value={primaryIdx} onChange={e => {setPrimaryIdx(Number(e.target.value)); setResults(null); setProgressStep(0);}}>
            {satelliteCatalog.map((sat, idx) => (
              <option key={idx} value={idx}>{sat.noradId} — {sat.name} ({sat.type})</option>
            ))}
          </select>
        </div>
        <div style={{flex: 1}}>
          <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Select Secondary Object (Threat)</label>
          <select className="prop-select" style={{width: '100%', borderColor: 'var(--red)'}} value={secondaryIdx} onChange={e => {setSecondaryIdx(Number(e.target.value)); setResults(null); setProgressStep(0);}}>
            {satelliteCatalog.map((sat, idx) => (
              <option key={idx} value={idx}>{sat.noradId} — {sat.name} ({sat.type})</option>
            ))}
          </select>
        </div>
      </div>

      <div className="two-col">
        <div className="glass-panel blue-tint">
          <div className="panel-card-title">Mathematical Formulation</div>
          <p className="astro-meta-item" style={{ marginBottom: '16px' }}>
            To calculate the collision probability ($P_c$), the 3D covariances of the primary and secondary objects are projected onto the 2D B-plane, combined, and integrated over the collision cross-section.
          </p>

          <div className="math-display">
            <div className="math-label">B-Plane Covariance Projection</div>
            C = C_primary + C_secondary<br/><br/>
            <span style={{color: 'var(--blue)'}}>
            C = [ {results ? (results.covPrimary[0][0] + results.covSecondary[0][0]).toFixed(1) : 'Σ_x'}   {results ? (results.covPrimary[0][1] + results.covSecondary[0][1]).toFixed(1) : 'Σ_xy'} ]<br/>
            &nbsp;&nbsp;&nbsp;&nbsp;[  {results ? (results.covPrimary[1][0] + results.covSecondary[1][0]).toFixed(1) : 'Σ_yx'}  {results ? (results.covPrimary[1][1] + results.covSecondary[1][1]).toFixed(1) : 'Σ_y'} ]
            </span>
          </div>

          <div className="math-display">
            <div className="math-label">2D PDF Integral over Hard Body Radius</div>
            P_c = (1 / 2π|C|^0.5) ∫∫ exp(-0.5 * r^T * C^-1 * r) dx dy <br/><br/>
            <span style={{color: 'var(--blue)'}}>
            Limits: x² + y² ≤ HBR²
            </span>
          </div>
        </div>

        <div className="glass-panel">
          <div className="panel-card-title" style={{color: 'var(--text-1)'}}>Engine Control & Metrics</div>
          
          <div className="stats-grid" style={{gridTemplateColumns: '1fr 1fr', marginBottom: '24px'}}>
            <div className="stat-cell">
              <div className="stat-cell-label" style={{marginBottom:'8px'}}>Miss Distance</div>
              <div className="stat-cell-val" style={{fontSize:'20px'}}>{results ? results.missDistance : '---'} <span style={{fontSize:'12px', color:'var(--text-3)'}}>m</span></div>
            </div>
            <div className="stat-cell">
              <div className="stat-cell-label" style={{marginBottom:'8px'}}>Hard Body Radius</div>
              <div className="stat-cell-val" style={{fontSize:'20px'}}>{results ? results.hbr : '---'} <span style={{fontSize:'12px', color:'var(--text-3)'}}>m</span></div>
            </div>
          </div>

          <button 
            className="prop-btn" 
            onClick={handleCompute}
            disabled={calculating}
            style={{ width: '100%', justifyContent: 'center', borderColor: 'var(--blue-line)', color: 'var(--blue)' }}
          >
            {calculating ? <span className="spinner"></span> : '∫'} 
            {calculating ? 'Executing Pipeline...' : 'Run Mathematical Integration'}
          </button>

          {/* Sequential Terminal Log - Vanishes when complete */}
          {progressStep > 0 && progressStep < 4 && (
            <div className="terminal-loader" style={{marginTop: '24px', padding: '16px', background: 'rgba(0,0,0,0.4)', borderRadius: '8px', border: '1px solid var(--border)'}}>
              <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                {progressStep === 1 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [1/3] Projecting Covariances to B-Plane...</> : <><span style={{color: 'var(--blue)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[1/3] B-Plane Covariances Generated</span></>}
              </div>
              
              {progressStep > 1 && (
                 <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                   {progressStep === 2 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [2/3] Solving N² Riemann Quadrature...</> : <><span style={{color: 'var(--blue)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[2/3] Mathematical Integration Complete (Pc = {results?.scientificNotation})</span></>}
                 </div>
              )}

              {progressStep > 2 && (
                 <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                   {progressStep === 3 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [3/3] Evaluating Risk Profiles...</> : <><span style={{color: 'var(--blue)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[3/3] Risk Assessment Finalized</span></>}
                 </div>
              )}
            </div>
          )}

          {/* Final Results */}
          {progressStep === 4 && results && (
            <div className="search-results fade-in-up" style={{marginTop: '24px'}}>
              <div className="search-result-bar" style={{borderColor: results.riskLevel === 'RED' ? 'var(--red)' : (results.riskLevel === 'YELLOW' ? 'var(--yellow)' : 'var(--green)')}}>
                <div>
                  <div className="search-result-method">COMPUTED PROBABILITY (Pc)</div>
                  <div className="search-result-count" style={{color: 'var(--text-1)', marginTop:'4px'}}>
                    {results.probability.toFixed(7)}
                  </div>
                </div>
                <div className="search-result-time fast" style={{color: results.riskLevel === 'RED' ? 'var(--red)' : (results.riskLevel === 'YELLOW' ? 'var(--yellow)' : 'var(--green)')}}>
                  {results.scientificNotation}
                </div>
              </div>

              <div className="state-vector-row" style={{marginTop:'12px'}}>
                <span className="sv-label">Computation Time (JS Engine)</span>
                <span className="sv-value">{results.timeMs} ms</span>
              </div>
              <div className="state-vector-row">
                <span className="sv-label">Algorithmic Complexity</span>
                <span className="sv-value">O(N²) grid quadrature</span>
              </div>
              <div className="state-vector-row">
                <span className="sv-label">Risk Level</span>
                <span className={\`sat-type-badge \${results.riskLevel.toLowerCase()}\`} style={{
                  color: results.riskLevel === 'RED' ? 'var(--red)' : (results.riskLevel === 'YELLOW' ? 'var(--yellow)' : 'var(--green)'),
                  borderColor: results.riskLevel === 'RED' ? 'var(--red)' : (results.riskLevel === 'YELLOW' ? 'var(--yellow)' : 'var(--green)'),
                  background: 'transparent'
                }}>
                  {results.riskLevel}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// DIVISION 3: DELTA-V OPTIMIZER
// ════════════════════════════════════════════════════════════════════════════
function DivisionThreeDeltaV() {
  const [computing, setComputing] = useState(false);
  const [progressStep, setProgressStep] = useState(0);
  const [results, setResults] = useState(null);
  const [selectedSatIndex, setSelectedSatIndex] = useState(0);
  const [radialDisplacement, setRadialDisplacement] = useState(2.5);

  const primary = satelliteCatalog[selectedSatIndex];

  const handleCompute = () => {
    if(computing) return;
    setComputing(true);
    setProgressStep(1);
    setResults(null);
    
    setTimeout(() => {
      const start = performance.now();
      
      const MU = 398600.4418;
      const R_EARTH = 6371;
      
      const r1 = R_EARTH + ((primary.apogee + primary.perigee) / 2);
      const r2 = r1 + parseFloat(radialDisplacement);
      
      const v1 = Math.sqrt(MU / r1);
      
      const vTransfer1 = Math.sqrt(MU * (2/r1 - 2/(r1+r2)));
      const vTransfer2 = Math.sqrt(MU * (2/r2 - 2/(r1+r2)));
      const v2 = Math.sqrt(MU / r2);
      
      const dv1 = Math.abs(vTransfer1 - v1);
      const dv2 = Math.abs(v2 - vTransfer2);
      const totalDV = dv1 + dv2;
      
      const Isp = 220;
      const g0 = 9.80665 / 1000;
      const M_initial = 1500;
      const M_final = M_initial * Math.exp(-totalDV / (Isp * g0));
      const fuelMass = M_initial - M_final;
      
      const elapsed = performance.now() - start;

      const data = {
        totalDV: (totalDV * 1000).toFixed(3),
        fuelMass: fuelMass.toFixed(3),
        dv1: (dv1 * 1000).toFixed(3),
        dv2: (dv2 * 1000).toFixed(3),
        timeMs: elapsed.toFixed(3),
        r1: r1.toFixed(1),
        r2: r2.toFixed(1)
      };

      setResults(data);

      setTimeout(() => {
        setProgressStep(2);
        setTimeout(() => {
          setProgressStep(3);
          setTimeout(() => {
            setProgressStep(4);
            setComputing(false);
          }, 500 + Math.random() * 400);
        }, 900 + Math.random() * 500);
      }, 600 + Math.random() * 300);
    }, 50);
  };

  return (
    <div className="fade-in-up delay-2">
      <div className="division-header">
        <div className="division-number" style={{color: 'var(--yellow)'}}>03</div>
        <div className="division-title-group">
          <div className="division-eyebrow" style={{color: 'var(--yellow)'}}>Tsiolkovsky & Vis-Viva Equations</div>
          <h2 className="division-title">Collision Avoidance: Delta-V Optimizer</h2>
          <div className="division-tagline">Calculate the optimal two-burn Hohmann transfer to achieve necessary radial clearance.</div>
        </div>
      </div>

      <div className="two-col">
        <div className="glass-panel orange-tint">
          <div className="panel-card-title">Mathematical Formulation</div>
          <p className="astro-meta-item" style={{ marginBottom: '16px' }}>
            We calculate the kinetic change required for orbital transfer using the Vis-viva equation, followed by the Tsiolkovsky rocket equation to estimate propellant consumption.
          </p>

          <div className="math-display">
            <div className="math-label">Vis-viva Equation (Orbital Energy)</div>
            v² = GM * (2/r - 1/a)<br/><br/>
            <span style={{color: 'var(--yellow)'}}>
            Δv₁ = |√[GM*(2/r₁ - 2/(r₁+r₂))] - v₁|<br/>
            Δv₂ = |v₂ - √[GM*(2/r₂ - 2/(r₁+r₂))]|<br/>
            Total Δv = Δv₁ + Δv₂
            </span>
          </div>

          <div className="math-display">
            <div className="math-label">Tsiolkovsky Rocket Equation</div>
            Δv = I_sp * g₀ * ln(m_initial / m_final)<br/><br/>
            <span style={{color: 'var(--yellow)'}}>
            m_fuel = m_initial - m_initial * exp(-Δv / (I_sp * g₀))
            </span>
          </div>
          
          <div className="dsa-toggle-section" style={{display: 'flex', gap: '16px', marginTop: '16px'}}>
            <div style={{flex: 1}}>
              <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Select Satellite (m₀ = 1500kg)</label>
              <select className="prop-select" style={{width: '100%', borderColor: 'var(--yellow)'}} value={selectedSatIndex} onChange={e => {setSelectedSatIndex(Number(e.target.value)); setResults(null); setProgressStep(0);}}>
                {satelliteCatalog.map((sat, idx) => (
                  <option key={idx} value={idx}>{sat.noradId} — {sat.name}</option>
                ))}
              </select>
            </div>
            <div style={{flex: 1}}>
              <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Radial Clearance Target (km)</label>
              <input 
                type="number" 
                className="prop-select" 
                style={{width: '100%', borderColor: 'var(--yellow)'}} 
                value={radialDisplacement} 
                onChange={e => {setRadialDisplacement(e.target.value); setProgressStep(0); setResults(null);}} 
                step="0.5"
                min="0.5"
                max="50"
              />
            </div>
          </div>
        </div>

        <div className="glass-panel">
          <div className="panel-card-title" style={{color: 'var(--text-1)'}}>Maneuver Plan Output</div>
          
          <button 
            className="prop-btn" 
            onClick={handleCompute}
            disabled={computing}
            style={{ width: '100%', justifyContent: 'center', borderColor: 'var(--yellow)', color: 'var(--yellow)', marginBottom: '24px' }}
          >
            {computing ? <span className="spinner"></span> : '🔥'} 
            {computing ? 'Executing Pipeline...' : 'Calculate Optimal Maneuver'}
          </button>

          {/* Sequential Terminal Log */}
          {progressStep > 0 && progressStep < 4 && (
            <div className="terminal-loader" style={{marginBottom: '24px', padding: '16px', background: 'rgba(0,0,0,0.4)', borderRadius: '8px', border: '1px solid var(--border)'}}>
              <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                {progressStep === 1 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [1/3] Calculating Vis-viva Orbital Energies...</> : <><span style={{color: 'var(--yellow)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[1/3] Orbital Energies Resolved</span></>}
              </div>
              
              {progressStep > 1 && (
                 <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                   {progressStep === 2 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [2/3] Simulating Hohmann Transfer Burn Vectors...</> : <><span style={{color: 'var(--yellow)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[2/3] Trajectory Nodes Established (Total ΔV: {results?.totalDV} m/s)</span></>}
                 </div>
              )}

              {progressStep > 2 && (
                 <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                   {progressStep === 3 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [3/3] Solving Tsiolkovsky Equation...</> : <><span style={{color: 'var(--yellow)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[3/3] Propellant Expenditure Mapped</span></>}
                 </div>
              )}
            </div>
          )}

          {progressStep === 4 && results && (
            <div className="search-results fade-in-up">
              <div className="search-result-bar" style={{borderColor: 'var(--yellow)'}}>
                <div>
                  <div className="search-result-method">TOTAL ΔV REQUIRED</div>
                  <div className="search-result-count" style={{color: 'var(--text-1)', marginTop:'4px', fontSize: '18px', fontWeight: 600}}>
                    {results.totalDV} <span style={{fontSize: '11px', fontWeight: 400, color: 'var(--text-3)'}}>m/s</span>
                  </div>
                </div>
                <div>
                  <div className="search-result-method">EST. PROPELLANT MASS</div>
                  <div className="search-result-count" style={{color: 'var(--yellow)', marginTop:'4px', fontSize: '18px', fontWeight: 600}}>
                    {results.fuelMass} <span style={{fontSize: '11px', fontWeight: 400, color: 'var(--text-3)'}}>kg</span>
                  </div>
                </div>
              </div>

              <div className="state-vector-row" style={{marginTop:'12px'}}>
                <span className="sv-label">Transfer Initiation Burn (Δv₁)</span>
                <span className="sv-value">{results.dv1} m/s</span>
              </div>
              <div className="state-vector-row">
                <span className="sv-label">Circularization Burn (Δv₂)</span>
                <span className="sv-value">{results.dv2} m/s</span>
              </div>
              <div className="state-vector-row">
                <span className="sv-label">Initial Orbit Radius (r₁)</span>
                <span className="sv-value">{results.r1} km</span>
              </div>
              <div className="state-vector-row">
                <span className="sv-label">Target Orbit Radius (r₂)</span>
                <span className="sv-value">{results.r2} km</span>
              </div>
              <div className="state-vector-row">
                <span className="sv-label">Computation Time (JS Engine)</span>
                <span className="sv-value" style={{color: 'var(--green)'}}>{results.timeMs} ms</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// DIVISION 4: REENTRY PREDICTOR (Orbital Decay)
// ════════════════════════════════════════════════════════════════════════════
function DivisionFourReentry() {
  const [computing, setComputing] = useState(false);
  const [progressStep, setProgressStep] = useState(0);
  const [results, setResults] = useState(null);
  const [selectedSatIndex, setSelectedSatIndex] = useState(0);
  const [visibleBars, setVisibleBars] = useState(0);

  const primary = satelliteCatalog[selectedSatIndex];
  
  // Animation loop for plotting graph
  useEffect(() => {
    if (progressStep === 4 && results?.decayCurve) {
       setVisibleBars(0);
       let curr = 0;
       const interval = setInterval(() => {
           curr++;
           setVisibleBars(curr);
           if(curr >= results.decayCurve.length) clearInterval(interval);
       }, 50); // plot one bar every 50ms
       return () => clearInterval(interval);
    }
  }, [progressStep, results]);

  const handleCompute = () => {
    if(computing) return;
    setComputing(true);
    setProgressStep(1);
    setResults(null);
    setVisibleBars(0);
    
    setTimeout(() => {
      const start = performance.now();
      
      const MU = 398600.4418;
      const R_EARTH = 6371;
      
      let a = R_EARTH + ((primary.apogee + primary.perigee) / 2);
      
      const mass = 1200;
      const area = primary.rcs === 'LARGE' ? 10.0 : (primary.rcs === 'MEDIUM' ? 4.0 : 1.0);
      const Cd = 2.2;
      const BC = mass / (Cd * area);
      
      const rho0 = 3.614e-13;
      const h0 = 400;
      const H = 50;
      
      let days = 0;
      let altitude = a - R_EARTH;
      
      const decayCurve = [];
      decayCurve.push({ day: 0, altitude: altitude });
      
      const MAX_DAYS = 36500;
      
      while (altitude > 100 && days < MAX_DAYS) {
        const rho = rho0 * Math.exp(-(altitude - h0) / H); 
        
        const a_m = a * 1000;
        const delta_a_m = -2 * Math.PI * (1/BC) * rho * (a_m * a_m);
        const delta_a_km = delta_a_m / 1000;
        
        const period_s = 2 * Math.PI * Math.sqrt((a*a*a) / MU);
        const orbits_per_day = 86400 / period_s;
        
        a += (delta_a_km * orbits_per_day);
        altitude = a - R_EARTH;
        days += 1;
        
        if (days % Math.max(1, Math.floor(MAX_DAYS/100)) === 0 || altitude <= 100) {
          if (decayCurve.length < 50 || altitude <= 100) {
             decayCurve.push({ day: days, altitude: Math.max(100, altitude) });
          }
        }
      }
      
      const elapsed = performance.now() - start;

      let riskLevel = 'GREEN';
      if (days < 365) riskLevel = 'RED';
      else if (days < 1825) riskLevel = 'YELLOW';
      
      const data = {
        lifetimeDays: days,
        lifetimeYears: (days / 365.25).toFixed(2),
        ballisticCoeff: BC.toFixed(1),
        timeMs: elapsed.toFixed(3),
        riskLevel,
        decayCurve,
        maxYears: days === MAX_DAYS
      };

      setResults(data);

      setTimeout(() => {
        setProgressStep(2);
        setTimeout(() => {
          setProgressStep(3);
          setTimeout(() => {
            setProgressStep(4);
            setComputing(false);
          }, 800 + Math.random() * 600);
        }, 1300 + Math.random() * 500);
      }, 700 + Math.random() * 300);

    }, 50);
  };

  return (
    <div className="fade-in-up delay-2">
      <div className="division-header">
        <div className="division-number" style={{color: 'var(--red)'}}>04</div>
        <div className="division-title-group">
          <div className="division-eyebrow" style={{color: 'var(--red)'}}>Atmospheric Drag Numerical Integrator</div>
          <h2 className="division-title">Orbital Decay & Reentry Predictor</h2>
          <div className="division-tagline">Calculate structural lifetime until atmospheric reentry (100km Kármán line boundary).</div>
        </div>
      </div>

      <div className="two-col">
        <div className="glass-panel" style={{ borderColor: 'rgba(248,113,113,0.2)', background: 'rgba(248,113,113,0.04)' }}>
          <div className="panel-card-title">Mathematical Formulation</div>
          <p className="astro-meta-item" style={{ marginBottom: '16px' }}>
            Calculates orbital decay by numerically integrating atmospheric drag forces over time. Uses an exponential atmospheric density model.
          </p>

          <div className="math-display" style={{borderColor: 'var(--red)', borderLeftColor: 'var(--red)'}}>
            <div className="math-label" style={{color: 'var(--red)'}}>Atmospheric Density (Exponential Model)</div>
            ρ = ρ₀ * exp(-(h - h₀) / H)<br/><br/>
            <span style={{color: 'var(--red)'}}>
            ρ₀ = 3.614e-13 kg/m³ (at 400km)<br/>
            H = 50 km (Scale Height)
            </span>
          </div>

          <div className="math-display" style={{borderColor: 'var(--red)', borderLeftColor: 'var(--red)'}}>
            <div className="math-label" style={{color: 'var(--red)'}}>Orbital Decay Rate (Δa per rev)</div>
            Δa = -2π * (C_d * A / m) * ρ * a²<br/><br/>
            <span style={{color: 'var(--red)'}}>
            Integrated over time until h = 100 km
            </span>
          </div>
          
          <div className="dsa-toggle-section" style={{display: 'flex', gap: '16px', marginTop: '16px'}}>
            <div style={{flex: 1}}>
              <label className="astro-meta-item" style={{display: 'block', marginBottom: '8px'}}>Select Satellite</label>
              <select className="prop-select" style={{width: '100%', borderColor: 'var(--red)'}} value={selectedSatIndex} onChange={e => {setSelectedSatIndex(Number(e.target.value)); setResults(null); setProgressStep(0);}}>
                {satelliteCatalog.map((sat, idx) => (
                  <option key={idx} value={idx}>{sat.noradId} — {sat.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="glass-panel">
          <div className="panel-card-title" style={{color: 'var(--text-1)'}}>Reentry Projection</div>
          
          <button 
            className="prop-btn" 
            onClick={handleCompute}
            disabled={computing}
            style={{ width: '100%', justifyContent: 'center', borderColor: 'var(--red)', color: 'var(--red)', marginBottom: '24px' }}
          >
            {computing ? <span className="spinner"></span> : '☄️'} 
            {computing ? 'Executing Pipeline...' : 'Predict Reentry Date'}
          </button>

          {/* Sequential Terminal Log */}
          {progressStep > 0 && progressStep < 4 && (
            <div className="terminal-loader" style={{marginBottom: '24px', padding: '16px', background: 'rgba(0,0,0,0.4)', borderRadius: '8px', border: '1px solid var(--border)'}}>
              <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                {progressStep === 1 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [1/3] Analyzing Ballistic Characteristics...</> : <><span style={{color: 'var(--red)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[1/3] Ballistic Coefficient Parsed (BC = {results?.ballisticCoeff} kg/m²)</span></>}
              </div>
              
              {progressStep > 1 && (
                 <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                   {progressStep === 2 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [2/3] Iterating Atmospheric Drag Models...</> : <><span style={{color: 'var(--red)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[2/3] Drag Integrals Evaluated over {results?.decayCurve.length} intervals</span></>}
                 </div>
              )}

              {progressStep > 2 && (
                 <div className="terminal-line" style={{color: 'var(--text-2)', fontSize: '13px', fontFamily: 'monospace', marginBottom: '8px', display: 'flex', alignItems: 'center'}}>
                   {progressStep === 3 ? <><span className="spinner" style={{width:'12px',height:'12px',borderWidth:'2px',marginRight:'8px'}}></span> [3/3] Projecting Kármán Line Boundary Intersection...</> : <><span style={{color: 'var(--red)', marginRight:'8px'}}>✔</span> <span style={{color: 'var(--text-1)'}}>[3/3] Reentry Vector Confirmed</span></>}
                 </div>
              )}
            </div>
          )}

          {progressStep === 4 && results && (
            <div className="search-results fade-in-up">
              <div className="search-result-bar" style={{borderColor: results.riskLevel === 'RED' ? 'var(--red)' : (results.riskLevel === 'YELLOW' ? 'var(--yellow)' : 'var(--green)')}}>
                <div>
                  <div className="search-result-method">PREDICTED ORBITAL LIFETIME</div>
                  <div className="search-result-count" style={{color: 'var(--text-1)', marginTop:'4px', fontSize: '18px', fontWeight: 600}}>
                    {results.maxYears ? '> 100' : results.lifetimeYears} <span style={{fontSize: '11px', fontWeight: 400, color: 'var(--text-3)'}}>Years</span>
                  </div>
                </div>
                <div className="search-result-time fast" style={{color: results.riskLevel === 'RED' ? 'var(--red)' : (results.riskLevel === 'YELLOW' ? 'var(--yellow)' : 'var(--green)')}}>
                  {results.maxYears ? '> 36,500' : results.lifetimeDays} <span style={{ fontSize: '12px', color: 'var(--text-3)' }}>Days</span>
                </div>
              </div>

              <div className="state-vector-row" style={{marginTop:'12px'}}>
                <span className="sv-label">Ballistic Coefficient (kg/m²)</span>
                <span className="sv-value">{results.ballisticCoeff}</span>
              </div>
              <div className="state-vector-row">
                <span className="sv-label">Computation Time (JS Engine)</span>
                <span className="sv-value" style={{color: 'var(--green)'}}>{results.timeMs} ms</span>
              </div>
              
              {/* Sequential visual decay representation */}
              <div style={{marginTop: '16px', height: '100px', borderBottom: '1px solid var(--border)', borderLeft: '1px solid var(--border)', position: 'relative', display: 'flex', alignItems: 'flex-end', paddingTop: '10px'}}>
                 {results.decayCurve.map((pt, i) => {
                    const startAlt = results.decayCurve[0].altitude;
                    const hPercent = ((pt.altitude - 100) / (startAlt - 100)) * 100;
                    return (
                      <div key={i} style={{
                         flex: 1, 
                         height: i < visibleBars ? \`\${Math.max(2, hPercent)}%\` : '0%', 
                         background: 'rgba(248,113,113,0.3)', 
                         borderTop: i < visibleBars ? '2px solid var(--red)' : 'none',
                         transition: 'height 0.2s cubic-bezier(0.2, 0.8, 0.2, 1)'
                      }}></div>
                    )
                 })}
                 <div style={{position: 'absolute', bottom: '-20px', right: 0, fontSize: '10px', color: 'var(--text-3)'}}>Reentry (100km)</div>
                 <div style={{position: 'absolute', top: 0, left: '-40px', fontSize: '10px', color: 'var(--text-3)'}}>{Math.round(results.decayCurve[0].altitude)}km</div>
              </div>

            </div>
          )}
        </div>
      </div>
    </div>
  );
}
`;

fs.writeFileSync(path, content.substring(0, div2Idx) + newContent);
console.log("Updated Division 2, 3, 4 with uneven timings, vanishing loaders, and animated graphs.");
