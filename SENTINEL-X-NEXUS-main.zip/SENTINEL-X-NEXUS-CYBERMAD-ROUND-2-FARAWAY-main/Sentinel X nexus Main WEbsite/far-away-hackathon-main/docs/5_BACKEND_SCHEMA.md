# Backend Schema
## Project: FAR AWAY Hackathon - Autonomous Space Defense
### Subdivision 1: Mission Control Foundation

*Note: For Part 1, this schema defines the Mock Data structures we will use on the frontend. In Part 2, the Python backend will serve this exact schema via REST/WebSockets.*

**1. Telemetry Event Object (`ConjunctionEvent`)**
```json
{
  "eventId": "string (UUID)",
  "timestamp": "string (ISO 8601)",
  "primaryObject": {
    "id": "string (NORAD ID)",
    "name": "string",
    "type": "string (e.g., 'PAYLOAD')"
  },
  "secondaryObject": {
    "id": "string (NORAD ID)",
    "name": "string",
    "type": "string (e.g., 'DEBRIS')"
  },
  "metrics": {
    "timeOfClosestApproach": "string (ISO 8601)",
    "missDistanceKm": "float",
    "collisionProbability": "float (e.g., 0.00015)",
    "relativeVelocityKmS": "float"
  },
  "riskLevel": "string ('GREEN', 'YELLOW', 'RED')"
}
```

**2. SENTINEL Agent Action Object (`SentinelAction`)**
```json
{
  "actionId": "string",
  "eventId": "string (UUID link to ConjunctionEvent)",
  "timestamp": "string",
  "decision": "string (e.g., 'MONITOR', 'ESCALATE', 'EXECUTE_MANEUVER')",
  "reasoning": "string (Short chain-of-thought)",
  "maneuverDetails": {
    "deltaV": "float",
    "burnDurationSec": "float"
  }
}
```

**3. Frontend State Requirements**
- `events`: Array of `ConjunctionEvent` objects.
- `sentinelActions`: Array of `SentinelAction` objects.
- `systemStatus`: Object holding overall system health.
