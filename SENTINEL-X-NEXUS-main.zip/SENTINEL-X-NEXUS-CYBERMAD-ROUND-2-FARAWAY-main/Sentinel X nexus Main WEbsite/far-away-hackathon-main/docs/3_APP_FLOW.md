# App Flow (The User Journey)
## Project: FAR AWAY Hackathon - Autonomous Space Defense
### Subdivision 1: Mission Control Foundation

**1. Entry Point**
- The judge/user navigates to `localhost:5173`.
- A brief (1-2 second) futuristic loading sequence (e.g., "INITIALIZING ORBITAL SENSORS...").

**2. Main Dashboard View**
- The screen opens to a panoramic dual-panel interface.
- **Left/Main Panel (SENTINEL)**: The user sees a live-updating stream of telemetry data. A clear badge indicates "PRODUCTION CORE - ACTIVE". The UI is stable, confident, and highlighted with green accents.
- **Right/Secondary Panel (NEXUS)**: The user sees the multi-agent council interface. A clear badge indicates "BETA / NEXT-GEN". It sits idle but listening, with subtle blue and dashed accents.

**3. Interaction in Part 1**
- For Subdivision 1, the user scrolls through static/mock conjunction events in the telemetry feed.
- The user can click a "Simulate Event" button (placeholder for now) to see how the UI reacts to an escalated threat (Green -> Red state change).
- The journey sets the stage for the narrative: "SENTINEL guards today. NEXUS plans tomorrow."
