# 🛰️ SENTINEL × NEXUS | Autonomous Space Defense & Mission Control

An autonomous dual-layer orbital defense system designed to monitor active satellite traffic, calculate collision conjunction risks in real time using real-world data, and autonomously execute avoidance protocols with a multi-agent debate council.

---

## 🚀 The Dual-Architecture

Our system is structured into two complementary layers, dividing today's production needs from tomorrow's experimental capabilities:

```
                  +-----------------------------------+
                  |      CELESTRAK & SPACE-TRACK      |
                  |     (Real-Time TLE Data Feed)     |
                  +-----------------------------------+
                                    |
                                    v
                  +-----------------------------------+
                  |     ORBITAL MECHANICS ENGINE      |
                  |   (SGP4 Conjunction Screening)    |
                  +-----------------------------------+
                                    |
                                    v
+-----------------------------------------------------------------------+
|  🛡️ LAYER 1: SENTINEL (Production Core)                                |
|  - Autonomous watchdog monitoring satellite trajectories 24/7.         |
|  - Autonomously computes avoidance maneuvers and evaluates fuel delta-v.|
|  - Fires corrective burns autonomously (no human in the loop).         |
+-----------------------------------------------------------------------+
                                    |
                       (Escalates Ambiguous Crises)
                                    v
+-----------------------------------------------------------------------+
|  ⬡ LAYER 2: NEXUS (Next-Gen Beta Council)                            |
|  - 4 specialized AI agents (Planning, Anomaly, Response, Comms).      |
|  - 3-Round Deliberation: initial positions, rebuttals, consensus.    |
|  - Resolves complex trade-offs (e.g. active payload priority).       |
+-----------------------------------------------------------------------+
```

---

## 🛠️ Tech Stack & Key APIs
- **Frontend**: React (Vite) + CSS Variables + Google Fonts (Outfit, Inter, JetBrains Mono) + 3D Orbital Globe.
- **Backend**: Python FastAPI + Uvicorn + WebSockets.
- **Orbital Mechanics**: SGP4 Propagation + Celestrak live TLE API.

---

## 📥 Setup & Running Instructions

### Prerequisites
- [Node.js](https://nodejs.org/) (v18+)
- [Python](https://www.python.org/) (v3.10+)

### 1. Backend Setup
1. Open a terminal in the `backend` folder:
   ```bash
   cd backend
   ```
2. Create a virtual environment and activate it:
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the server:
   ```bash
   python main.py
   ```
   *The backend will run on `http://localhost:8000` and start fetching live TLEs.*

### 2. Frontend Setup
1. Open a new terminal in the `frontend` folder:
   ```bash
   cd frontend
   ```
2. Install packages:
   ```bash
   npm install
   ```
3. Start the dev server:
   ```bash
   npm run dev
   ```
4. Open your browser and navigate to **`http://localhost:5173`**.

---

## 🎬 The Demo Scenario & Pitch Guide

Use this scripted guide to deliver a flawless, high-impact demo to the hackathon judges.

### ⏱️ Part 1: Introduce the Crisis (0:00 - 1:00)
- **What to say**: 
  > *"Every single day, there are over 27,000 trackable pieces of debris orbiting Low Earth Orbit at 28,000 km/h. A collision with a ₹500+ crore satellite happens in milliseconds. Today, humans monitor this manually—but they sleep, shifts end, and the data is too massive. We built SENTINEL to take humans out of the bottleneck."*
- **What to show**: 
  - Point to the live tracking globe showing active satellite positions updating in real time.
  - Show the topbar stats indicating **Objects Tracked** (~60 live payloads fetched from Celestrak) and the **47 Autonomous Saves** already recorded.

### ⏱️ Part 2: Trigger Sentinel's Autonomy (1:00 - 1:45)
- **Action**: Click the **"Broadcast Demo Crisis"** button in the header.
- **What to show**:
  - The globe flashes, indicating a **RED alert**. The alert bar snaps open at the top.
  - The **SENTINEL** panel (left side) opens autonomously.
- **What to say**:
  - > *"Watch the screen. We've just simulated a RED-level threat. EOS-06 is on a collision course with a piece of Fengyun-1C debris. The miss distance is only 114 meters. Notice that we didn't press any 'resolve' button—SENTINEL autonomously detected this, computed an avoidance burn, and generated a retrograde thrust profile. For routine debris, SENTINEL operates autonomously without asking."*

### ⏱️ Part 3: The NEXUS Council Debate (1:45 - 2:45)
- **Action**: Look at the **NEXUS** panel (right side) opening 1.5 seconds after SENTINEL.
- **What to show**:
  - The roster badges pulse/glow when an agent types.
  - Custom **Round Separators** mark the debate flow (Round 1, Round 2, Round 3).
  - Typing indicators show exactly which agent is drafting: e.g. `"Risk & Policy Agent reasoning..."`.
- **What to say**:
  - > *"But what about a complex crisis? For example, when two active satellites are on a collision course. Maneuvering either satellite expends fuel and disrupts communications. Who yields? That's too critical for one agent. So SENTINEL escalates to NEXUS—our experimental multi-agent council."*
  - > *"Notice the agents debating. They don't just agree linearly. The Astrodynamics Agent proposes maneuvering the primary satellite, but the Risk & Policy Agent objects because the primary is a critical earth observation platform. In Round 2, they debate fuel depletion and debris fragmentation probability. Comms checks ground station visibility (e.g. Bangalore vs Svalbard). By Round 3, they converge on a binding two-phase conditional resolution."*

### ⏱️ Part 4: Show the Consensus (2:45 - 3:00)
- **What to show**:
  - Scroll down to the final **Verdict** card showing the **Consolidated Vote Tally**.
  - Show the 4 glowing status circles highlighting unanimous alignment.
- **What to say**:
  - > *"At the end of the debate, the Executive Agent issues the final ruling, logging a unanimous 4/4 vote tally to our audit ledger. This multi-agent debate replicates a room of expert engineers in seconds, eliminating coordination lag."*
  - > *"SENTINEL is the shield protecting space assets today; NEXUS is the brain organizing space traffic tomorrow."*
