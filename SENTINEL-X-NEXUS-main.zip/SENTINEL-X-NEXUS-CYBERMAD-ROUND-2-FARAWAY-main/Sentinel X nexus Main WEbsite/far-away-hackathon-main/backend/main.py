"""
main.py — SENTINEL × NEXUS Backend
=====================================
FastAPI server with WebSocket support.

Endpoints:
  GET  /            → health check
  GET  /api/status  → system status JSON
  GET  /api/satellites → current satellite positions
  GET  /api/conjunctions → current conjunction events
  WS   /ws          → real-time stream (positions + events, every 3s)

The WebSocket broadcasts two message types:
  { "type": "satellite_positions", "data": [...] }
  { "type": "conjunction_events",  "data": [...] }

Run with:
  python -m uvicorn main:app --reload --port 8000
"""

import asyncio
import json
import logging
import datetime
import os
import threading
import time
from typing import Set

import httpx

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

from celestrak import get_satellites
from orbital import compute_satellite_positions, compute_conjunctions
from sentinel_agent import sentinel
from nexus_agent import nexus

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("sentinel.main")

# ── FastAPI app ───────────────────────────────────────────────────────────────
app = FastAPI(
    title="SENTINEL × NEXUS API",
    description="Real-time autonomous space defense data pipeline",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # Allows requests from any frontend (e.g. your Vercel domain)
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Shared state ──────────────────────────────────────────────────────────────
class AppState:
    satellites:    list[dict] = []   # TLE-loaded satellite list
    positions:     list[dict] = []   # current ECI + geodetic positions
    conjunctions:  list[dict] = []   # active conjunction events
    decisions:     list[dict] = []   # SENTINEL autonomous decisions
    system_status: dict       = {
        "sentinelStatus":   "INITIALIZING",
        "objectsTracked":   0,
        "activeConjunctions": 0,
        "agentsOnline":     1,
        "lastSync":         "",
        "dataSource":       "sgp4 + Celestrak live TLE",
        "backendVersion":   "1.0.0",
        "sentinelUptime":   "99.97%",
    }

state = AppState()
connected_clients: Set[WebSocket] = set()

# ── Data refresh loop ─────────────────────────────────────────────────────────
TLE_REFRESH_INTERVAL_S  = 300   # re-fetch TLEs every 5 minutes
POSITION_INTERVAL_S     = 3     # broadcast positions every 3 seconds
CONJUNCTION_INTERVAL_S  = 60    # recompute conjunctions every 60 seconds


async def broadcast(msg: dict):
    """Send a JSON message to all connected WebSocket clients."""
    text = json.dumps(msg)
    dead = set()
    for ws in list(connected_clients):
        try:
            await ws.send_text(text)
        except Exception:
            dead.add(ws)
    connected_clients.difference_update(dead)


async def position_broadcast_loop():
    """Continuously compute and broadcast satellite positions."""
    logger.info("Position broadcast loop started")
    while True:
        if state.satellites:
            pos = compute_satellite_positions(state.satellites)
            state.positions = pos
            state.system_status["objectsTracked"] = len(pos)
            state.system_status["lastSync"] = datetime.datetime.utcnow().isoformat() + "Z"
            if connected_clients:
                await broadcast({
                    "type": "satellite_positions",
                    "data": pos,
                    "timestamp": state.system_status["lastSync"],
                })
        await asyncio.sleep(POSITION_INTERVAL_S)


async def conjunction_loop():
    """Periodically compute conjunction events and run them through SENTINEL."""
    logger.info("Conjunction screening loop started")
    await asyncio.sleep(5)
    while True:
        if state.satellites:
            logger.info(f"Screening {len(state.satellites)} satellites for conjunctions...")
            try:
                events = compute_conjunctions(
                    state.satellites[:30],
                    lookahead_hours=2.0,
                    step_minutes=3.0,
                )
                state.conjunctions = events

                # ── SENTINEL evaluates every event ───────────────────────────
                if events:
                    decisions     = sentinel.evaluate_all(events)
                    state.decisions = [sentinel.to_dict(d) for d in decisions]
                    state.system_status.update(sentinel.get_status())

                state.system_status["activeConjunctions"] = len(events)
                logger.info(
                    f"Found {len(events)} conjunction events "
                    f"(RED: {sum(1 for e in events if e['riskLevel']=='RED')}) "
                    f"| SENTINEL decisions: {len(state.decisions)}"
                )

                if connected_clients:
                    await broadcast({
                        "type": "conjunction_events",
                        "data": events,
                        "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
                    })
                    await broadcast({
                        "type": "sentinel_decisions",
                        "data": state.decisions,
                        "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
                    })
                    await broadcast({
                        "type": "system_status",
                        "data": state.system_status,
                    })
            except Exception as e:
                logger.error(f"Conjunction screening failed: {e}")
        await asyncio.sleep(CONJUNCTION_INTERVAL_S)


async def tle_refresh_loop():
    """Periodically refresh TLE data from Celestrak."""
    logger.info("TLE refresh loop started")
    while True:
        logger.info("Fetching fresh TLEs from Celestrak...")
        try:
            sats = get_satellites(limit=60)
            state.satellites = sats
            logger.info(f"Loaded {len(sats)} satellites")
            state.system_status["sentinelStatus"] = "ACTIVE"
        except Exception as e:
            logger.error(f"TLE refresh failed: {e}")
            state.system_status["sentinelStatus"] = "DEGRADED"
        await asyncio.sleep(TLE_REFRESH_INTERVAL_S)


# ── Startup ───────────────────────────────────────────────────────────────────
@app.on_event("startup")
async def startup():
    logger.info("=" * 55)
    logger.info("  SENTINEL × NEXUS Backend v1.0")
    logger.info("  Autonomous Space Defense Data Pipeline")
    logger.info("=" * 55)

    # Load TLEs immediately on startup
    try:
        sats = get_satellites(limit=60)
        state.satellites = sats
        state.system_status["sentinelStatus"] = "ACTIVE"
        logger.info(f"✓ Loaded {len(sats)} satellites from Celestrak")
    except Exception as e:
        logger.error(f"Initial TLE load failed: {e}")
        state.system_status["sentinelStatus"] = "DEGRADED"

    # Run initial conjunction screening + SENTINEL evaluation
    if state.satellites:
        try:
            events = compute_conjunctions(
                state.satellites[:20],
                lookahead_hours=2.0,
                step_minutes=3.0,
            )
            state.conjunctions = events
            state.system_status["activeConjunctions"] = len(events)
            # SENTINEL evaluates on startup
            if events:
                decisions      = sentinel.evaluate_all(events)
                state.decisions = [sentinel.to_dict(d) for d in decisions]
                state.system_status.update(sentinel.get_status())
            logger.info(f"✓ Initial screening: {len(events)} conjunctions | {len(state.decisions)} SENTINEL decisions")
        except Exception as e:
            logger.warning(f"Initial conjunction screening failed: {e}")

    # Launch background loops
    asyncio.create_task(tle_refresh_loop())
    asyncio.create_task(position_broadcast_loop())
    asyncio.create_task(conjunction_loop())
    logger.info("✓ Background tasks running — WebSocket ready at ws://localhost:8000/ws")


# ── REST Endpoints ────────────────────────────────────────────────────────────
@app.get("/")
async def health():
    return {
        "status": "online",
        "service": "SENTINEL × NEXUS Backend",
        "version": "1.0.0",
        "websocket": "ws://localhost:8000/ws",
    }


@app.get("/api/status")
async def get_status():
    return state.system_status


@app.get("/api/satellites")
async def get_satellites_endpoint():
    return {"count": len(state.positions), "data": state.positions}


@app.get("/api/conjunctions")
async def get_conjunctions():
    return {"count": len(state.conjunctions), "data": state.conjunctions}


@app.get("/api/decisions")
async def get_decisions():
    """SENTINEL autonomous decision log."""
    return {"count": len(state.decisions), "data": state.decisions}


@app.get("/api/neo")
async def get_near_earth_objects(days: int = 7):
    """
    Proxy NASA NeoWs feed to avoid CORS issues.
    Returns flattened, sorted list of Near-Earth Objects for the next N days.
    """
    today   = datetime.date.today()
    end     = today + datetime.timedelta(days=min(days, 7))
    api_key = "DEMO_KEY"  # swap for your NASA key for higher rate limits
    url     = (
        f"https://api.nasa.gov/neo/rest/v1/feed"
        f"?start_date={today}&end_date={end}&api_key={api_key}"
    )
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            data = resp.json()

        neo_map = data.get("near_earth_objects", {})
        all_neos = []
        for date_str, neos in neo_map.items():
            for neo in neos:
                neo["_approachDate"] = date_str
                all_neos.append(neo)

        # Sort by closest miss distance
        all_neos.sort(key=lambda n: float(
            (n.get("close_approach_data") or [{}])[0]
             .get("miss_distance", {}).get("kilometers", "1e15")
        ))

        logger.info(f"[NEO] Fetched {len(all_neos)} near-Earth objects from NASA NeoWs")
        return {
            "count":       len(all_neos),
            "startDate":   str(today),
            "endDate":     str(end),
            "data":        all_neos,
            "elementCount": data.get("element_count", len(all_neos)),
        }

    except httpx.HTTPStatusError as e:
        logger.error(f"[NEO] NASA API HTTP error: {e}")
        return {"error": f"NASA API error: {e.response.status_code}", "data": []}
    except Exception as e:
        logger.error(f"[NEO] Failed to fetch NEO data: {e}")
        return {"error": str(e), "data": []}


# ── WebSocket ─────────────────────────────────────────────────────────────────
@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    connected_clients.add(ws)
    client_addr = ws.client.host if ws.client else "unknown"
    logger.info(f"WebSocket connected: {client_addr} (total: {len(connected_clients)})")

    try:
        # Send current state immediately on connect
        if state.positions:
            await ws.send_text(json.dumps({
                "type": "satellite_positions",
                "data": state.positions,
                "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
            }))

        if state.conjunctions:
            await ws.send_text(json.dumps({
                "type": "conjunction_events",
                "data": state.conjunctions,
                "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
            }))

        if state.decisions:
            await ws.send_text(json.dumps({
                "type": "sentinel_decisions",
                "data": state.decisions,
                "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
            }))

        await ws.send_text(json.dumps({
            "type": "system_status",
            "data": state.system_status,
        }))

        # Keep connection alive — client sends pings
        while True:
            data = await ws.receive_text()
            if data == "ping":
                continue
            
            try:
                msg = json.loads(data)
                if msg.get("type") == "trigger_nexus_debate":
                    event_id = msg.get("eventId")
                    # Find the event
                    event = next((e for e in state.conjunctions if e["eventId"] == event_id), None)
                    if not event:
                        # Fallback to first RED event if ID not found
                        event = next((e for e in state.conjunctions if e["riskLevel"] == "RED"), state.conjunctions[0] if state.conjunctions else {})
                    
                    # Find SENTINEL's decision for this event (context injection)
                    sentinel_dec = next(
                        (d for d in state.decisions if d.get("eventId") == event_id),
                        state.decisions[0] if state.decisions else None,
                    )

                    # Stream context-aware debate
                    logger.info(f"NEXUS debate triggered for event {event_id} with SENTINEL context")
                    async for debate_msg in nexus.run_debate(event, sentinel_dec):
                        await ws.send_text(json.dumps({
                            "type": "nexus_message",
                            "data": debate_msg
                        }))
                    logger.info(f"NEXUS debate completed for event {event_id}")
            except Exception as e:
                logger.warning(f"Error handling WS message: {e}")

    except WebSocketDisconnect:
        logger.info(f"WebSocket disconnected: {client_addr}")
    except Exception as e:
        logger.warning(f"WebSocket error ({client_addr}): {e}")
    finally:
        connected_clients.discard(ws)


if __name__ == "__main__":
    import uvicorn
    # Hugging Face Spaces (Docker SDK) sets PORT=7860 and expects the app
    # to bind to that port. Falls back to 8000 for local development.
    port = int(os.environ.get("PORT", 8000))
    reload_enabled = os.environ.get("ENV", "local") == "local"
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=reload_enabled, log_level="info")
