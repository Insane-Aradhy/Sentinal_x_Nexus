"""
build_demo_tles.py — Generate demo TLEs that guarantee conjunction events
=========================================================================
This script computes which debris TLEs produce close approaches with
the payload TLEs using the actual sgp4 propagator, then prints the
winning satellite set.

Run once to validate, then hardcode the results in celestrak.py
"""
import datetime
import math
from sgp4.api import Satrec, jday

# Current epoch in TLE format: YYDDD.FFFFFFFF
now = datetime.datetime.utcnow()
doy = now.timetuple().tm_yday
frac = (now.hour * 3600 + now.minute * 60 + now.second) / 86400.0
epoch_str = f"{str(now.year)[2:]}{doy:03d}.{int(frac * 1e8):08d}"
print(f"Current epoch string: {epoch_str}")

# Payloads we care about — real orbital elements, LEO SSO ~97.4 deg
PAYLOADS = [
    # (name, inclination, RAAN_deg, eccentricity, argperigee, mean_anomaly, mean_motion, norad)
    ("CARTOSAT-3",   97.4584, 50.2349, 0.0001433, 88.643, 271.489, 15.1946, 44233),
    ("EOS-06",       98.0027, 77.2541, 0.0001200, 115.23, 244.900, 14.8543, 54361),
    ("RESOURCESAT-2A", 98.7082, 225.4135, 0.0001354, 97.512, 262.618, 14.1948, 41877),
]

# Check all pair distances at t=0 and t+30min intervals over 3 hours
def check_distance(sr_a, sr_b, start_dt, steps=90, step_min=2):
    min_d = float('inf')
    min_t = start_dt
    for i in range(steps):
        dt = start_dt + datetime.timedelta(minutes=i*step_min)
        jd, fr = jday(dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second)
        ea, ra, _ = sr_a.sgp4(jd, fr)
        eb, rb, _ = sr_b.sgp4(jd, fr)
        if ea != 0 or eb != 0:
            continue
        d = math.sqrt(sum((a-b)**2 for a,b in zip(ra,rb)))
        if d < min_d:
            min_d = d
            min_t = dt
    return min_d, min_t

# Use known working pair from test
line1_a = "1 54361U 22057A   26160.48002315  .00000531  00000-0  55632-4 0  9998"
line2_a = "2 54361  98.0027  77.2541 0001200 115.2300 244.9000 14.85434210185237"
line1_b = "1 29228U 99025AFX 26160.48000000  .00002512  00000-0  31312-3 0  9993"
line2_b = "2 29228  98.0025  77.2545 0001210 115.2280 244.9020 14.85432000185238"

sr_a = Satrec.twoline2rv(line1_a, line2_a)
sr_b = Satrec.twoline2rv(line1_b, line2_b)

now = datetime.datetime.utcnow()
d, t = check_distance(sr_a, sr_b, now, steps=90, step_min=2)
print(f"\nEOS-06 x FENGYUN: min dist = {d:.3f} km = {d*1000:.0f} m at {t.strftime('%H:%M')} UTC")

# Try variations of mean_anomaly to get even closer
print("\nSearching for tighter debris elements...")
best = d
best_ma_offset = 0
for delta_ma in range(-30, 31, 1):
    # Offset mean anomaly by delta degrees
    orig_ma = 244.9020
    new_ma = (orig_ma + delta_ma) % 360
    new_l2 = f"2 29228  98.0025  77.2545 0001210 115.2280 {new_ma:08.4f} 14.85432000185238"
    try:
        sr_test = Satrec.twoline2rv(line1_b, new_l2)
        dist, _ = check_distance(sr_a, sr_test, now, steps=90, step_min=2)
        if dist < best:
            best = dist
            best_ma_offset = delta_ma
            best_l2 = new_l2
    except:
        pass

print(f"Best MA offset: {best_ma_offset:+d} deg → min dist = {best:.3f} km = {best*1000:.0f} m")
if best_ma_offset != 0:
    print(f"Optimal line2: {best_l2}")
