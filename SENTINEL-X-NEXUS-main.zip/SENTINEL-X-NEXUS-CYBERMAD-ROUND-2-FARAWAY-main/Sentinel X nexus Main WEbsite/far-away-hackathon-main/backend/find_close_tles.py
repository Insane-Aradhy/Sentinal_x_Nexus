"""
find_close_tles.py
Find debris MA offsets that produce RED/YELLOW/GREEN conjunctions
"""
import datetime, math
from sgp4.api import Satrec, jday

def min_dist(l1a, l2a, l1b, l2b, hours=3, step_min=1):
    sa = Satrec.twoline2rv(l1a, l2a)
    sb = Satrec.twoline2rv(l1b, l2b)
    now = datetime.datetime(2026, 6, 10, 14, 0, 0)
    best = float('inf')
    for i in range(int(hours*60/step_min)):
        dt = now + datetime.timedelta(minutes=i*step_min)
        jd, fr = jday(dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second)
        ea, ra, _ = sa.sgp4(jd, fr)
        eb, rb, _ = sb.sgp4(jd, fr)
        if ea or eb: continue
        d = math.sqrt(sum((a-b)**2 for a,b in zip(ra,rb)))
        if d < best: best = d
    return best

# EOS-06
l1_eos = "1 54361U 22057A   26161.58000000  .00000531  00000-0  55632-4 0  9998"
l2_eos = "2 54361  98.0027  77.2541 0001200 115.2300 244.9000 14.85434210185237"

# FENGYUN base (15 km miss)
l1_fy  = "1 29228U 99025AFX 26161.58000000  .00002512  00000-0  31312-3 0  9993"
l2_fy_base = "2 29228  98.0025  77.2545 0001210 115.2280 {ma:08.4f} 14.85432000185238"

print("Searching mean anomaly offsets...")
results = []
for delta in range(-180, 181, 2):
    ma = (244.9020 + delta) % 360
    l2 = l2_fy_base.format(ma=ma)
    d = min_dist(l1_eos, l2_eos, l1_fy, l2)
    results.append((d, delta, ma, l2))

results.sort()
print("Top 10 closest approaches:")
for d, delta, ma, l2 in results[:10]:
    tag = "RED" if d < 1 else "YELLOW" if d < 5 else "GREEN"
    print(f"  [{tag}] delta={delta:+4d}deg MA={ma:.3f} -> dist={d*1000:.0f}m")
    print(f"         {l2}")

# Also do CARTOSAT-3 x COSMOS
print("\nSearching CARTOSAT-3 x COSMOS pairs...")
l1_cart = "1 44233U 19060A   26161.58000000  .00001526  00000-0  20012-3 0  9990"
l2_cart = "2 44233  97.4584  50.2349 0001433  88.6430 271.4885 15.19457670345672"
l1_cos  = "1 37820U 11017WH  26161.58000000  .00001812  00000-0  24234-3 0  9990"
l2_cos_base = "2 37820  97.4580  50.2360 0001450  88.6380 {ma:08.4f} 15.19452000345673"

results2 = []
for delta in range(-180, 181, 2):
    ma = (271.4910 + delta) % 360
    l2 = l2_cos_base.format(ma=ma)
    d = min_dist(l1_cart, l2_cart, l1_cos, l2)
    results2.append((d, delta, ma, l2))

results2.sort()
print("Top 5 closest approaches:")
for d, delta, ma, l2 in results2[:5]:
    tag = "RED" if d < 1 else "YELLOW" if d < 5 else "GREEN"
    print(f"  [{tag}] delta={delta:+4d}deg MA={ma:.3f} -> dist={d*1000:.0f}m")
    print(f"         {l2}")
