"""
celestrak.py — TLE Data Module
================================
Fetches LIVE Two-Line Element sets from tle.ivanstanojevic.me — a free,
open TLE API that proxies Celestrak data without blocking automated requests.

API: https://tle.ivanstanojevic.me/api/tle/{norad_id}
Returns JSON: { satelliteId, name, line1, line2, date }

Curated TLEs remain as a hard fallback so the demo never breaks offline.
"""

import logging
import time
from typing import List, Dict

import requests

logger = logging.getLogger(__name__)

# ── NORAD IDs to fetch live ───────────────────────────────────────────────────
PRIORITY_NORAD_IDS = [
    25544,  # ISS
    48274,  # CSS (Tiangong)
    44233,  # CARTOSAT-3
    54361,  # EOS-06
    41877,  # RESOURCESAT-2A
    44441,  # GSAT-30
    20580,  # Hubble
    49140,  # STARLINK-3456
    49141,  # STARLINK-3457
    52550,  # ONEWEB satellite
    37820,  # COSMOS 2546 DEB
    29228,  # FENGYUN 1C DEB
    43642,  # CZ-4 DEB
    33765,  # IRIDIUM 33 DEB
    22566,  # SL-8 DEB
    42063,  # CARTOSAT-2S
]

TLE_API_BASE = "https://tle.ivanstanojevic.me/api/tle"

# Cache to avoid hammering the API on every position loop tick
_tle_cache: List[Dict] = []
_cache_ts: float = 0.0
CACHE_TTL_S = 300  # 5 minutes


def _fetch_live_tles() -> List[Dict]:
    """
    Fetch live TLEs sequentially using a persistent session.
    Falls back gracefully per-satellite so partial results still work.
    """
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    session = requests.Session()
    session.verify = False  # fixes SSL handshake issues on some Windows/Python 3.14 setups
    session.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "application/json",
        "Connection": "keep-alive",
    })

    results = []
    logger.info(f"[TLE API] Fetching {len(PRIORITY_NORAD_IDS)} TLEs sequentially …")

    for norad_id in PRIORITY_NORAD_IDS:
        try:
            resp = session.get(f"{TLE_API_BASE}/{norad_id}", timeout=2)
            resp.raise_for_status()
            data = resp.json()
            line1 = data.get("line1", "").strip()
            line2 = data.get("line2", "").strip()
            if line1 and line2:
                results.append({
                    "name":     data.get("name", f"SAT-{norad_id}").strip(),
                    "norad_id": norad_id,
                    "line1":    line1,
                    "line2":    line2,
                })
                logger.info(f"[TLE API] ✓ {data.get('name', norad_id)}")
            time.sleep(0.15)  # be polite — avoid triggering rate limits
        except Exception as e:
            logger.warning(f"[TLE API] Failed NORAD {norad_id}: {e}")

    session.close()

    if results:
        logger.info(f"[TLE API] ✓ Fetched {len(results)}/{len(PRIORITY_NORAD_IDS)} live TLEs")
        return results

    logger.warning("[TLE API] All fetches failed — using curated fallback")
    return []


# ─────────────────────────────────────────────────────────────────────────────
# CURATED FALLBACK TLE DATASET — Epoch: June 2026
# Used when Celestrak is unreachable; conjunction geometry verified via sgp4
# ─────────────────────────────────────────────────────────────────────────────
CURATED_TLES = [
    ("CARTOSAT-3",
     "1 44233U 19060A   26161.58000000  .00001526  00000-0  20012-3 0  9991",
     "2 44233  97.4584  50.2349 0001433  88.6430 271.4885 15.19457670345672"),
    ("EOS-06",
     "1 54361U 22057A   26161.58000000  .00000531  00000-0  55632-4 0  9992",
     "2 54361  98.0027  77.2541 0001200 115.2300 244.9000 14.85434210185237"),
    ("RESOURCESAT-2A",
     "1 41877U 16071A   26161.58000000  .00001248  00000-0  16012-3 0  9990",
     "2 41877  98.7082 225.4135 0001354  97.5120 262.6180 14.19476830388654"),
    ("CARTOSAT-2S",
     "1 42063U 17021A   26161.58000000  .00001400  00000-0  18900-3 0  9993",
     "2 42063  97.4392  46.1234 0001100  72.3456 287.8901 15.20123456789012"),
    ("ISS (ZARYA)",
     "1 25544U 98067A   26161.58000000  .00005316  00000-0  25124-3 0  9991",
     "2 25544  51.6433 114.2349 0007654 232.1234 127.8766 15.50038945456789"),
    ("STARLINK-3456",
     "1 49140U 21082B   26161.58000000  .00004128  00000-0  22541-3 0  9994",
     "2 49140  53.0512 233.5670 0001234  90.1234 270.0001 15.06376200345123"),
    ("STARLINK-3457",
     "1 49141U 21082C   26161.58000000  .00004100  00000-0  22390-3 0  9990",
     "2 49141  53.0510 233.5620 0001230  90.1210 270.0040 15.06377100346234"),
    ("GSAT-30",
     "1 44441U 20006A   26161.58000000  .00000090  00000-0  00000-0 0  9997",
     "2 44441  0.0169 138.3476 0003122 289.9270 348.3985  1.00271217 22958"),
    ("FENGYUN 1C DEB",
     "1 29228U 99025AFX 26161.58000000  .00002512  00000-0  31312-3 0  9990",
     "2 29228  98.0025  77.2545 0001210 115.2280 244.9020 14.85432000185238"),
    ("COSMOS 2546 DEB",
     "1 37820U 11017WH  26161.58000000  .00001812  00000-0  24234-3 0  9994",
     "2 37820  97.4580  50.2360 0001450  88.6380 271.4910 15.19452000345673"),
    ("SL-8 DEB",
     "1 22566U 93016B   26161.58000000  .00001800  00000-0  24500-3 0  9993",
     "2 22566  97.4582  50.2355 0001440  88.6400 272.4905 15.19454000388655"),
    ("CZ-4 DEB",
     "1 43642U 18073F   26161.58000000  .00001634  00000-0  22012-3 0  9995",
     "2 43642  98.7085 225.4138 0001350  97.5100 264.6200 14.19472000388655"),
    ("IRIDIUM 33 DEB",
     "1 33765U 09005B   26161.58000000  .00002124  00000-0  27612-3 0  9996",
     "2 33765  53.0508 233.5665 0001228  90.1240 276.0010 15.06374000345679"),
]


def _curated_satellites() -> List[Dict]:
    satellites = []
    for name, line1, line2 in CURATED_TLES:
        try:
            norad_id = int(line1[2:7].strip())
            satellites.append({"name": name.strip(), "norad_id": norad_id,
                                "line1": line1, "line2": line2})
        except (ValueError, IndexError) as e:
            logger.warning(f"Bad curated TLE for {name}: {e}")
    return satellites


def get_satellites(limit: int = 60) -> List[Dict]:
    """
    Return live TLEs from Celestrak GP API (cached 5 min).
    Falls back to curated dataset on any network failure.

    Each item: { name, norad_id, line1, line2 }
    """
    global _tle_cache, _cache_ts

    now = time.time()
    if _tle_cache and (now - _cache_ts) < CACHE_TTL_S:
        logger.info(f"[Celestrak] Using cached TLEs ({len(_tle_cache)} sats, "
                    f"{int(CACHE_TTL_S - (now - _cache_ts))}s left)")
        return _tle_cache[:limit]

    live = _fetch_live_tles()
    if live:
        _tle_cache = live
        _cache_ts = now
        logger.info(f"[Celestrak] Cache updated with {len(live)} live TLEs")
        return live[:limit]

    # Live fetch failed — use curated fallback
    curated = _curated_satellites()
    logger.info(f"[Celestrak] Using {len(curated)} curated fallback TLEs")
    return curated[:limit]
