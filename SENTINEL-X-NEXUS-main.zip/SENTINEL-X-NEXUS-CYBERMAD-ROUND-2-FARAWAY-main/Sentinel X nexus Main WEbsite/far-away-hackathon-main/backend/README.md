---
title: Sentinel Nexus Backend
emoji: 🛰️
colorFrom: blue
colorTo: indigo
sdk: docker
app_port: 7860
pinned: false
---

# SENTINEL × NEXUS Backend (Hugging Face Space)

This is the FastAPI backend for the SENTINEL × NEXUS autonomous space defense
system, deployed via the Hugging Face Spaces Docker SDK.

## Endpoints

- `GET  /`                — health check
- `GET  /api/status`      — system status JSON
- `GET  /api/satellites`  — current satellite positions
- `GET  /api/conjunctions`— current conjunction events
- `GET  /api/decisions`   — SENTINEL decision log
- `GET  /api/neo?days=7`  — NASA NeoWs near-Earth object proxy
- `WS   /ws`              — real-time stream (positions + events)

## Connecting the frontend

Once this Space is live at `https://<your-username>-<space-name>.hf.space`,
set these environment variables in your Vercel project:

```
VITE_BACKEND_URL=https://<your-username>-<space-name>.hf.space
VITE_WS_URL=wss://<your-username>-<space-name>.hf.space/ws
```

## Local development

```bash
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```
