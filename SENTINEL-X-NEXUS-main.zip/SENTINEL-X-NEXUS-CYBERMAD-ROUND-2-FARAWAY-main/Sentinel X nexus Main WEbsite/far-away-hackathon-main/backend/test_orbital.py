from celestrak import get_satellites
from orbital import compute_satellite_positions, compute_conjunctions

print("Loading satellites...")
sats = get_satellites()
print(f"Loaded: {len(sats)} satellites")
for s in sats:
    print(f"  {s['name']:<30} NORAD={s['norad_id']}")

print()
print("Computing positions...")
pos = compute_satellite_positions(sats)
print(f"Valid positions: {len(pos)}")
for p in pos[:5]:
    print(f"  {p['name']:<30} lat={p['lat']:7.2f} lon={p['lon']:8.2f} alt={p['alt']:8.1f} km")

print()
print("Screening conjunctions (2h, 2min steps)...")
events = compute_conjunctions(sats, lookahead_hours=2.0, step_minutes=2.0)
print(f"Conjunctions found: {len(events)}")
for e in events:
    miss_m = e['metrics']['missDistanceKm'] * 1000
    prob   = e['metrics']['collisionProbability']
    print(f"  [{e['riskLevel']:6}] {e['primaryObject']['name'][:22]:<22} x {e['secondaryObject']['name'][:22]:<22} | miss={miss_m:.0f}m Pc={prob:.2e}")

if not events:
    print("  (no conjunctions found — checking thresholds)")
    print(f"  MAX_CONJUNCTION_KM = 20 km")
    print(f"  Try increasing threshold or extending lookahead")
