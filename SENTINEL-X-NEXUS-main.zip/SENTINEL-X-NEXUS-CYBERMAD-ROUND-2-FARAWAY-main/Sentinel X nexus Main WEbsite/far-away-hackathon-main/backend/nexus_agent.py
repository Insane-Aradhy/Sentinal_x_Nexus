"""
nexus_agent.py — NEXUS Multi-Agent Council (Division 8)
=======================================================
Multi-Round Debate with Disagreement, Rebuttals, and Consensus Resolution.

SECRET WEAPON (from project brief):
  "Show agents disagreeing and resolving — e.g., Anomaly Agent flags risk,
   Response Agent proposes maneuver, Planning Agent runs feasibility.
   Judges have never seen autonomous agents debating a satellite crisis
   in real time."

The debate now runs in 3 rounds:
  ROUND 1 — Initial Positions (agents DISAGREE)
    COMMS:     Situational brief
    ANOMALY:   Proposes maneuver for primary satellite (physics-first)
    PLANNING:  OBJECTS — argues secondary should maneuver (policy-first)

  ROUND 2 — Rebuttals (agents challenge each other)
    ANOMALY:   Responds to Planning's objection with revised data
    PLANNING:  Counters with regulatory and mission-priority analysis
    COMMS:     Provides feasibility check and coordination timeline

  ROUND 3 — Resolution
    RESPONSE:  Synthesises all positions, tallies votes, issues final ruling

Each agent references REAL orbital data. No two debates are the same.
"""

import os
import json
import asyncio
import uuid
import math
import random
import datetime
import traceback
from typing import AsyncGenerator, Optional
from dotenv import load_dotenv

try:
    import google.generativeai as genai
    HAS_GENAI = True
except ImportError:
    HAS_GENAI = False

load_dotenv()


from sentinel_agent import (
    circular_orbit_velocity,
    period_seconds,
    delta_v_for_miss_distance,
    fuel_estimate_kg,
    burn_duration_s,
)


# ─── Agent Definitions ───────────────────────────────────────────────────────
AGENTS = {
    "COMMS": {
        "name": "System Link",
        "role": "Communications & Coordination",
    },
    "ANOMALY": {
        "name": "Astrodynamics Agent",
        "role": "Orbital Physics Expert",
    },
    "PLANNING": {
        "name": "Risk & Policy Agent",
        "role": "Mission Priority & Regulations",
    },
    "RESPONSE": {
        "name": "Executive Agent",
        "role": "Final Decision Authority",
    },
}


# ─── Gemini Pool & LLM Generator ─────────────────────────────────────────────
class GeminiPool:
    def __init__(self):
        self.keys = [
            os.getenv('GEMINI_API_KEY_1'),
            os.getenv('GEMINI_API_KEY_2'),
            os.getenv('GEMINI_API_KEY_3'),
        ]
        self.keys = [k for k in self.keys if k and k.strip() != "your_gemini_api_key_1_here" and "your_gemini_api_key" not in k]
        self.current_idx = 0

    def get_next_key(self):
        if not self.keys:
            return None
        key = self.keys[self.current_idx]
        self.current_idx = (self.current_idx + 1) % len(self.keys)
        return key

pool = GeminiPool()

async def generate_debate_via_llm(ctx: dict) -> list[dict]:
    if not HAS_GENAI or not pool.keys:
        raise Exception("Gemini API not configured or google-generativeai missing.")

    prompt = f"""You are the backend logic for NEXUS, an autonomous multi-agent space defense council.
Your job is to generate a JSON array of messages simulating a debate between 4 AI agents resolving an orbital crisis.
The crisis telemetry is:
- Primary Object: {ctx['primary_name']} (ID: {ctx['primary_id']}, Type: {ctx['primary_type']})
- Secondary Object: {ctx['secondary_name']} (ID: {ctx['secondary_id']}, Type: {ctx['secondary_type']})
- Miss Distance: {ctx['miss_km']} km
- Relative Velocity: {ctx['rel_vel_kms']} km/s
- Probability of Collision: {ctx['prob']}
- Time to TCA (Closest Approach): {ctx['lead_minutes']} minutes
- Delta-V needed for Option A: {ctx['ms']['delta_v']} m/s (Cost: {ctx['ms']['fuel_g']} g propellant)

Agents:
1. COMMS (System Link): Reports the initial situation and checks ground station feasibility.
2. ANOMALY (Astrodynamics): Proposes maneuvers based on pure physics and orbital mechanics.
3. PLANNING (Risk & Policy): Argues about mission priority, fuel budgets, and space law, often disagreeing with ANOMALY.
4. RESPONSE (Executive): Tallies the votes and issues the final binding execution order.

The debate MUST proceed in 3 Rounds:
ROUND 1: Initial Positions (COMMS, ANOMALY, PLANNING). They MUST disagree on the approach.
ROUND 2: Rebuttals (ANOMALY, PLANNING, COMMS). They must argue and eventually reach a compromise (like a conditional two-phase protocol).
ROUND 3: Resolution (RESPONSE). Synthesizes and gives the final order.

Output exactly a JSON array of objects with the following schema:
[{{
    "agentId": "COMMS" | "ANOMALY" | "PLANNING" | "RESPONSE",
    "agentName": "System Link" | "Astrodynamics Agent" | "Risk & Policy Agent" | "Executive Agent",
    "delay": <float between 1.5 and 4.0 simulating thinking time>,
    "message": "<the actual dialogue of the agent>",
    "vote": "APPROVE_MANEUVER" | "ESCALATE_RED" | "MANEUVER_PRIMARY" | "MANEUVER_SECONDARY" | "CONDITIONAL_SECONDARY" | "CONSENSUS_EXECUTE",
    "confidence": <float between 0.80 and 0.99>,
    "round": 1 | 2 | 3
}}]
Make the dialogue sound highly technical, urgent, and professional. Return ONLY valid JSON, no markdown blocks.
"""

    for attempt in range(len(pool.keys)):
        key = pool.get_next_key()
        try:
            genai.configure(api_key=key)
            model = genai.GenerativeModel('gemini-flash-latest')
            # Run in a thread to avoid blocking asyncio loop
            response = await asyncio.to_thread(
                model.generate_content,
                prompt,
                generation_config={"response_mime_type": "application/json"}
            )
            return json.loads(response.text)
        except Exception as e:
            print(f"[GeminiPool] Key failed: {str(e)}")
            continue
            
    raise Exception("All Gemini API keys failed or rate-limited.")


# ─── Context Builder ─────────────────────────────────────────────────────────
def build_debate_context(event_data: dict, sentinel_decision: Optional[dict] = None) -> dict:
    primary = event_data.get("primaryObject", {})
    secondary = event_data.get("secondaryObject", {})
    metrics = event_data.get("metrics", {})

    miss_km = metrics.get("missDistanceKm", 0.5)
    miss_m = miss_km * 1000
    rel_vel = metrics.get("relativeVelocityKmS", 10.0)
    prob = metrics.get("collisionProbability", 1e-3)
    tca_str = metrics.get("timeOfClosestApproach", datetime.datetime.utcnow().isoformat() + "Z")
    risk = event_data.get("riskLevel", "RED")

    try:
        tca_dt = datetime.datetime.fromisoformat(tca_str.rstrip("Z"))
        now = datetime.datetime.utcnow()
        lead_h = max(0, (tca_dt - now).total_seconds() / 3600)
    except Exception:
        lead_h = 1.5

    alt_km = 550.0
    v_circ = circular_orbit_velocity(alt_km)
    period_s = period_seconds(alt_km)
    period_min = period_s / 60

    target_miss_10 = 10.0
    target_miss_25 = 25.0

    dv_10, strategy_10 = delta_v_for_miss_distance(alt_km, miss_km, target_miss_10, rel_vel, max(lead_h, 0.5))
    dv_25, strategy_25 = delta_v_for_miss_distance(alt_km, miss_km, target_miss_25, rel_vel, max(lead_h, 0.5))

    fuel_10 = fuel_estimate_kg(dv_10)
    fuel_25 = fuel_estimate_kg(dv_25)
    burn_10 = burn_duration_s(dv_10)
    burn_25 = burn_duration_s(dv_25)

    sec_type = secondary.get("type", "PAYLOAD")
    is_debris = sec_type == "DEBRIS" or any(
        kw in secondary.get("name", "").upper()
        for kw in ["DEB", "DEBRIS", "R/B", "ROCKET"]
    )
    both_payloads = primary.get("type") == "PAYLOAD" and not is_debris

    impact_energy_mj = 0.5 * 1500 * (rel_vel * 1000) ** 2 / 1e6

    # Mission descriptions (used across rounds)
    missions_pool = [
        ("critical communications relay", "scientific research platform"),
        ("Earth observation satellite", "navigation augmentation payload"),
        ("weather monitoring platform", "technology demonstration mission"),
        ("broadband constellation node", "spectrum monitoring asset"),
    ]
    missions_pool = [
        ("critical communications relay", "scientific research platform"),
        ("Earth observation satellite", "navigation augmentation payload"),
        ("weather monitoring platform", "technology demonstration mission"),
        ("broadband constellation node", "spectrum monitoring asset"),
        ("military early warning system", "commercial imaging satellite"),
        ("deep space relay node", "decommissioned weather satellite"),
        ("experimental propulsion testbed", "commercial internet constellation node"),
        ("classified payload", "debris mitigation target"),
    ]
    m1_desc, m2_desc = random.choice(missions_pool)

    # Service disruption and fuel budget numbers
    service_downtime_min = random.randint(30, 90)
    fuel_budget_pct = round(random.uniform(0.5, 2.5), 1)
    debris_fragments = random.randint(200, 2000)
    threatened_sats = random.randint(15, 60)

    return {
        "primary_name": primary.get("name", "UNKNOWN"),
        "primary_id": primary.get("id", "?"),
        "primary_type": primary.get("type", "PAYLOAD"),
        "secondary_name": secondary.get("name", "UNKNOWN"),
        "secondary_id": secondary.get("id", "?"),
        "secondary_type": sec_type,
        "is_debris": is_debris,
        "both_payloads": both_payloads,
        "miss_km": miss_km,
        "miss_m": miss_m,
        "miss_au_str": f"{miss_km * 6.684587122e-9:.4e}",
        "rel_vel_kms": rel_vel,
        "rel_vel_au_str": f"{rel_vel * 6.684587122e-9:.4e}",
        "prob": prob,
        "prob_str": f"{prob:.2e}",
        "risk": risk,
        "tca_str": tca_str,
        "lead_hours": round(lead_h, 2),
        "lead_minutes": round(lead_h * 60, 1),
        "alt_km": alt_km,
        "alt_au_str": f"{alt_km * 6.684587122e-9:.4e}",
        "v_circ_kms": round(v_circ, 2),
        "v_circ_au_str": f"{v_circ * 6.684587122e-9:.4e}",
        "period_min": round(period_min, 1),
        "ms": {
            "target_km": target_miss_10,
            "target_au_str": f"{target_miss_10 * 6.684587122e-9:.4e}",
            "delta_v": dv_10,
            "strategy": strategy_10,
            "fuel_kg": fuel_10,
            "fuel_g": round(fuel_10 * 1000, 1),
            "burn_s": burn_10,
        },
        "mc": {
            "target_km": target_miss_25,
            "target_au_str": f"{target_miss_25 * 6.684587122e-9:.4e}",
            "delta_v": dv_25,
            "strategy": strategy_25,
            "fuel_kg": fuel_25,
            "fuel_g": round(fuel_25 * 1000, 1),
            "burn_s": burn_25,
        },
        "impact_energy_mj": round(impact_energy_mj, 1),
        "sentinel_decision": sentinel_decision,
        "m1_desc": m1_desc,
        "m2_desc": m2_desc,
        "service_downtime": service_downtime_min,
        "fuel_budget_pct": fuel_budget_pct,
        "debris_fragments": debris_fragments,
        "threatened_sats": threatened_sats,
    }



# ─── Gemini Pool & LLM Generator ─────────────────────────────────────────────
class GeminiPool:
    def __init__(self):
        self.keys = [
            os.getenv('GEMINI_API_KEY_1'),
            os.getenv('GEMINI_API_KEY_2'),
            os.getenv('GEMINI_API_KEY_3'),
        ]
        self.keys = [k for k in self.keys if k and k.strip() != "your_gemini_api_key_1_here" and "your_gemini_api_key" not in k]
        self.current_idx = 0

    def get_next_key(self):
        if not self.keys:
            return None
        key = self.keys[self.current_idx]
        self.current_idx = (self.current_idx + 1) % len(self.keys)
        return key

pool = GeminiPool()

async def generate_debate_via_llm(ctx: dict) -> list[dict]:
    if not HAS_GENAI or not pool.keys:
        raise Exception("Gemini API not configured or google-generativeai missing.")

    prompt = f"""You are the backend logic for NEXUS, an autonomous multi-agent space defense council.
Your job is to generate a JSON array of messages simulating a debate between 4 AI agents resolving an orbital crisis.
The crisis telemetry is:
- Primary Object: {ctx['primary_name']} (ID: {ctx['primary_id']}, Type: {ctx['primary_type']})
- Secondary Object: {ctx['secondary_name']} (ID: {ctx['secondary_id']}, Type: {ctx['secondary_type']})
- Miss Distance: {ctx['miss_km']} km
- Relative Velocity: {ctx['rel_vel_kms']} km/s
- Probability of Collision: {ctx['prob']}
- Time to TCA (Closest Approach): {ctx['lead_minutes']} minutes
- Delta-V needed for Option A: {ctx['ms']['delta_v']} m/s (Cost: {ctx['ms']['fuel_g']} g propellant)

Agents:
1. COMMS (System Link): Reports the initial situation and checks ground station feasibility.
2. ANOMALY (Astrodynamics): Proposes maneuvers based on pure physics and orbital mechanics.
3. PLANNING (Risk & Policy): Argues about mission priority, fuel budgets, and space law, often disagreeing with ANOMALY.
4. RESPONSE (Executive): Tallies the votes and issues the final binding execution order.

The debate MUST proceed in 3 Rounds:
ROUND 1: Initial Positions (COMMS, ANOMALY, PLANNING). They MUST disagree on the approach.
ROUND 2: Rebuttals (ANOMALY, PLANNING, COMMS). They must argue and eventually reach a compromise (like a conditional two-phase protocol).
ROUND 3: Resolution (RESPONSE). Synthesizes and gives the final order.

Output exactly a JSON array of objects with the following schema:
[{{
    "agentId": "COMMS" | "ANOMALY" | "PLANNING" | "RESPONSE",
    "agentName": "System Link" | "Astrodynamics Agent" | "Risk & Policy Agent" | "Executive Agent",
    "delay": <float between 1.5 and 4.0 simulating thinking time>,
    "message": "<the actual dialogue of the agent>",
    "vote": "APPROVE_MANEUVER" | "ESCALATE_RED" | "MANEUVER_PRIMARY" | "MANEUVER_SECONDARY" | "CONDITIONAL_SECONDARY" | "CONSENSUS_EXECUTE",
    "confidence": <float between 0.80 and 0.99>,
    "round": 1 | 2 | 3
}}]
Make the dialogue sound highly technical, urgent, and professional. Return ONLY valid JSON, no markdown blocks.
"""

    for attempt in range(len(pool.keys)):
        key = pool.get_next_key()
        try:
            genai.configure(api_key=key)
            model = genai.GenerativeModel('gemini-1.5-flash')
            # Run in a thread to avoid blocking asyncio loop
            response = await asyncio.to_thread(
                model.generate_content,
                prompt,
                generation_config={"response_mime_type": "application/json"}
            )
            return json.loads(response.text)
        except Exception as e:
            print(f"[GeminiPool] Key failed: {str(e)}")
            continue
            
    raise Exception("All Gemini API keys failed or rate-limited.")

# ─── Multi-Round Debate Generator ────────────────────────────────────────────
def generate_debate_script(ctx: dict) -> list[dict]:
    p = ctx["primary_name"]
    s = ctx["secondary_name"]
    ms = ctx["ms"]
    mc = ctx["mc"]

    dv_rev = round(ms["delta_v"] * 0.85, 4)
    fuel_rev_g = round(fuel_estimate_kg(dv_rev) * 1000, 1)
    burn_rev_s = round(burn_duration_s(dv_rev), 1)
    rev_strategy = "RETROGRADE" if ms["strategy"] == "PROGRADE" else "PROGRADE"

    script = []

    # ═══════════════════════════════════════════════════════════════════════
    # ROUND 1 — INITIAL POSITIONS
    # ═══════════════════════════════════════════════════════════════════════

    # ── COMMS: Situational brief ──
    script.append({
        "agentId": "COMMS",
        "agentName": AGENTS["COMMS"]["name"],
        "delay": 1.5,
        "message": (
            f"NEXUS COUNCIL ACTIVATED — ROUND 1.\n"
            f"Escalation received from SENTINEL autonomous layer.\n\n"
            f"SITUATION: {p} (NORAD {ctx['primary_id']}) is on a collision course with "
            f"{s} (NORAD {ctx['secondary_id']}).\n"
            f"• Miss distance: {ctx['miss_au_str']} AU\n"
            f"• Relative velocity: {ctx['rel_vel_au_str']} AU/s\n"
            f"• Collision probability: {ctx['prob_str']}\n"
            f"• Time to TCA: {ctx['lead_minutes']} minutes\n"
            f"• Impact energy: {ctx['impact_energy_mj']} MJ\n\n"
            + (
                f"⚠ CRITICAL: Both active payloads. "
                f"SENTINEL cannot autonomously resolve — council must decide which spacecraft maneuvers.\n\n"
                f"Agents, present your initial positions."
                if ctx["both_payloads"] else
                f"Secondary classified as {'DEBRIS' if ctx['is_debris'] else ctx['secondary_type']}. "
                f"Standard protocol applies, but SENTINEL has escalated for council verification.\n\n"
                f"Agents, present your initial positions."
            )
        ),
        "vote": None,
        "confidence": 1.0,
        "round": 1,
        "dataCard": {
            "type": "situation_brief",
            "missM": round(ctx["miss_m"]),
            "relVel": ctx["rel_vel_kms"],
            "prob": ctx["prob_str"],
            "tcaMin": ctx["lead_minutes"],
            "impactMJ": ctx["impact_energy_mj"],
        },
    })

    # ── ANOMALY: Proposes primary maneuvers (physics-first approach) ──
    script.append({
        "agentId": "ANOMALY",
        "agentName": AGENTS["ANOMALY"]["name"],
        "delay": 2.5,
        "message": (
            f"Astrodynamics analysis complete.\n\n"
            f"Both objects at ~{ctx['alt_au_str']} AU altitude, orbital velocity {ctx['v_circ_au_str']} AU/s, "
            f"period {ctx['period_min']} min.\n\n"
            f"MY POSITION: {p} should execute an immediate {ms['strategy']} burn.\n"
            f"• Option A: {ms['delta_v']:.4f} m/s ({ms['burn_s']:.1f}s) → {ctx['ms']['target_au_str']} AU clearance, cost {ms['fuel_g']}g\n"
            f"• Option B: {mc['delta_v']:.4f} m/s ({mc['burn_s']:.1f}s) → {ctx['mc']['target_au_str']} AU clearance, cost {mc['fuel_g']}g\n\n"
            f"I recommend Option A. {p} has a confirmed thruster capability and we have "
            f"{ctx['lead_minutes']} minutes to TCA — sufficient margin. "
            f"Waiting for {s} to maneuver introduces coordination delay risk."
        ),
        "vote": "MANEUVER_PRIMARY",
        "confidence": 0.91,
        "round": 1,
        "dataCard": {
            "type": "maneuver_options",
            "optionA": {
                "strategy": ms["strategy"],
                "deltaV": ms["delta_v"],
                "burnS": ms["burn_s"],
                "fuelG": ms["fuel_g"],
                "clearanceKm": ms["target_km"],
            },
            "optionB": {
                "strategy": mc["strategy"],
                "deltaV": mc["delta_v"],
                "burnS": mc["burn_s"],
                "fuelG": mc["fuel_g"],
                "clearanceKm": mc["target_km"],
            },
        },
    })

    # ── PLANNING: OBJECTS — argues secondary should maneuver ──
    if ctx["both_payloads"]:
        planning_r1 = (
            f"⚠ OBJECTION to Astrodynamics.\n\n"
            f"I strongly disagree with maneuvering {p}.\n\n"
            f"MISSION PRIORITY ANALYSIS:\n"
            f"• {p}: Classified as {ctx['m1_desc']}. "
            f"Maneuver interrupts service for {ctx['service_downtime']} minutes "
            f"and expends {ctx['fuel_budget_pct']}% of remaining station-keeping budget.\n"
            f"• {s}: Classified as {ctx['m2_desc']}. "
            f"Higher maneuverability margin, lower mission criticality.\n\n"
            f"Under IADC Space Debris Mitigation Guidelines and UN COPUOS protocols, "
            f"the less critical asset should yield. {s} should execute the avoidance burn. "
            f"Maneuvering {p} is operationally reckless and violates priority hierarchy."
        )
    else:
        planning_r1 = (
            f"⚠ PARTIAL OBJECTION to Astrodynamics.\n\n"
            f"I agree {p} must maneuver (debris is uncontrollable), but I dispute Option A.\n\n"
            f"RISK ANALYSIS: At {ctx['rel_vel_au_str']} AU/s relative velocity, "
            f"failure to achieve sufficient clearance generates {ctx['debris_fragments']} trackable fragments "
            f"threatening {ctx['threatened_sats']} operational spacecraft.\n\n"
            f"Option A's {ctx['ms']['target_au_str']} AU clearance is insufficient for the tracking uncertainty. "
            f"I recommend Option B ({ctx['mc']['target_au_str']} AU clearance) — the additional {mc['fuel_g'] - ms['fuel_g']:.1f}g "
            f"propellant cost is negligible compared to a Kessler cascade risk.\n\n"
            f"VOTE: Option B, not Option A."
        )

    script.append({
        "agentId": "PLANNING",
        "agentName": AGENTS["PLANNING"]["name"],
        "delay": 2.8,
        "message": planning_r1,
        "vote": "MANEUVER_SECONDARY" if ctx["both_payloads"] else "MANEUVER_CONSERVATIVE",
        "confidence": 0.88,
        "round": 1,
        "dataCard": None,
    })

    # ═══════════════════════════════════════════════════════════════════════
    # ROUND 2 — REBUTTALS (agents challenge each other)
    # ═══════════════════════════════════════════════════════════════════════

    # ── ANOMALY: Responds to Planning's objection ──
    if ctx["both_payloads"]:
        anomaly_r2 = (
            f"Rebuttal to Risk & Policy.\n\n"
            f"I acknowledge {p}'s higher mission priority. However, I challenge the assumption "
            f"that {s} can maneuver in time.\n\n"
            f"COORDINATION RISK: Contacting {s}'s operator, obtaining authorization, and "
            f"uplinking burn commands takes 20–40 minutes. With {ctx['lead_minutes']} minutes to TCA, "
            f"{'this leaves dangerously thin margins' if ctx['lead_minutes'] < 90 else 'this is feasible but tight'}.\n\n"
            f"REVISED POSITION: If we can confirm {s}'s ground station contact within "
            f"10 minutes, I support maneuvering {s} with a {rev_strategy} burn of "
            f"{dv_rev} m/s ({burn_rev_s}s, {fuel_rev_g}g). "
            f"Otherwise, {p} must maneuver as fallback — we cannot risk coordination failure."
        )
    else:
        anomaly_r2 = (
            f"Rebuttal to Risk & Policy.\n\n"
            f"Option B is over-engineered. The tracking uncertainty at {ctx['miss_au_str']} AU "
            f"miss distance is approximately ±50m (3σ from latest conjunction data message).\n\n"
            f"Option A's {ctx['ms']['target_au_str']} AU clearance exceeds this by 200x.\n\n"
            f"Furthermore, Option B's {mc['fuel_g']}g burn depletes an additional "
            f"{mc['fuel_g'] - ms['fuel_g']:.1f}g of propellant — this compounds across "
            f"the remaining {random.randint(2, 5)} years of {p}'s mission life.\n\n"
            f"REVISED POSITION: I maintain Option A. However, I concede we should "
            f"schedule a post-maneuver tracking verification at TCA + 15 minutes."
        )

    script.append({
        "agentId": "ANOMALY",
        "agentName": AGENTS["ANOMALY"]["name"],
        "delay": 2.2,
        "message": anomaly_r2,
        "vote": "CONDITIONAL_SECONDARY" if ctx["both_payloads"] else "MANEUVER_PRIMARY",
        "confidence": 0.85,
        "round": 2,
        "dataCard": None,
    })

    # ── PLANNING: Counter-rebuttal ──
    if ctx["both_payloads"]:
        planning_r2 = (
            f"Counter to Astrodynamics.\n\n"
            f"The coordination timeline concern is valid. I accept the conditional framework.\n\n"
            f"REVISED POSITION:\n"
            f"• Phase 1 (T-{ctx['lead_minutes']:.0f} to T-{max(ctx['lead_minutes']-10, 0):.0f} min): "
            f"Comms Agent attempts contact with {s} operator.\n"
            f"• Phase 2a (contact confirmed): {s} executes {rev_strategy} burn. {p} holds.\n"
            f"• Phase 2b (contact FAILS by T-{max(ctx['lead_minutes']-15, 30):.0f} min): "
            f"Fallback — {p} executes {ms['strategy']} burn autonomously.\n\n"
            f"This two-phase protocol preserves {p}'s mission while guaranteeing crisis resolution. "
            f"I now align with Astrodynamics on the conditional approach."
        )
    else:
        planning_r2 = (
            f"Counter to Astrodynamics.\n\n"
            f"The 200x clearance margin argument is compelling. I revise my position.\n\n"
            f"I withdraw my objection to Option A. However, I maintain one condition: "
            f"the post-maneuver tracking verification that Astrodynamics proposed is essential. "
            f"If post-burn miss distance is below {ms['target_km'] * 0.5 * 6.684587122e-9:.4e} AU, "
            f"we must execute a secondary correction burn.\n\n"
            f"REVISED VOTE: Option A with mandatory post-burn verification. "
            f"I am now in agreement with Astrodynamics."
        )

    script.append({
        "agentId": "PLANNING",
        "agentName": AGENTS["PLANNING"]["name"],
        "delay": 2.0,
        "message": planning_r2,
        "vote": "CONDITIONAL_SECONDARY" if ctx["both_payloads"] else "APPROVE_MANEUVER",
        "confidence": 0.90,
        "round": 2,
        "dataCard": None,
    })

    # ── COMMS: Feasibility and coordination ──
    if ctx["both_payloads"]:
        comms_r2 = (
            f"Coordination feasibility report.\n\n"
            f"I have cross-referenced {s}'s ground station schedule. "
            f"Next available uplink window: {random.randint(3, 12)} minutes from now "
            f"via {'Bangalore' if random.random() > 0.5 else 'Svalbard'} ground station.\n\n"
            f"Contact probability: {random.randint(85, 98)}%. "
            f"Burn command uplink time: {random.randint(2, 5)} minutes.\n\n"
            f"ASSESSMENT: Phase 2a (secondary maneuver) is feasible within timeline. "
            f"I recommend proceeding with the two-phase protocol. "
            f"I will initiate operator contact immediately upon council authorization."
        )
    else:
        comms_r2 = (
            f"Coordination note.\n\n"
            f"{p}'s ground station is currently in contact via "
            f"{'ISTRAC Bangalore' if random.random() > 0.5 else 'ISRO Lucknow'}. "
            f"Burn command can be uplinked within {random.randint(1, 3)} minutes of authorization.\n\n"
            f"Post-burn tracking verification: I will coordinate with the 18th Space Defense Squadron "
            f"for radar confirmation at TCA + 15 minutes as both agents requested.\n\n"
            f"VOTE: Concur with both agents — Option A with post-burn verification."
        )

    script.append({
        "agentId": "COMMS",
        "agentName": AGENTS["COMMS"]["name"],
        "delay": 1.8,
        "message": comms_r2,
        "vote": "APPROVE_MANEUVER",
        "confidence": 0.94,
        "round": 2,
        "dataCard": None,
    })

    # ═══════════════════════════════════════════════════════════════════════
    # ROUND 3 — RESOLUTION (Executive synthesises + final ruling)
    # ═══════════════════════════════════════════════════════════════════════

    if ctx["both_payloads"]:
        exec_target = s
        exec_dv = dv_rev
        exec_fuel_g = fuel_rev_g
        exec_strategy = rev_strategy
        fallback_target = p
        fallback_dv = ms["delta_v"]

        resolution_msg = (
            f"EXECUTIVE RULING — ROUND 3 — CONSENSUS REACHED AFTER DELIBERATION.\n\n"
            f"VOTE TALLY:\n"
            f"• Astrodynamics: Conditional — {s} maneuvers if contact confirmed, {p} as fallback ✓\n"
            f"• Risk & Policy: Conditional — two-phase protocol aligned with Astrodynamics ✓\n"
            f"• System Link: Feasibility confirmed — contact window available ✓\n"
            f"• Executive: Affirming consensus ✓\n\n"
            f"RESULT: UNANIMOUS (4/4) — Two-Phase Conditional Protocol\n\n"
            f"BINDING ORDERS:\n"
            f"1. COMMS: Initiate contact with {s} operator IMMEDIATELY.\n"
            f"2. IF contact confirmed within 10 min → {s} executes {exec_strategy} burn "
            f"of {exec_dv} m/s ({burn_rev_s}s). {p} HOLDS POSITION.\n"
            f"3. IF contact FAILS → {p} autonomously executes {ms['strategy']} burn "
            f"of {fallback_dv:.4f} m/s. No further council needed.\n"
            f"4. Post-maneuver verification at TCA + 15 min.\n\n"
            f"Decision logged to immutable audit ledger with full debate transcript. "
            f"Council session CLOSED."
        )
    else:
        exec_target = p
        exec_dv = ms["delta_v"]
        exec_fuel_g = ms["fuel_g"]
        exec_strategy = ms["strategy"]
        fallback_target = None

        resolution_msg = (
            f"EXECUTIVE RULING — ROUND 3 — CONSENSUS REACHED AFTER DELIBERATION.\n\n"
            f"VOTE TALLY:\n"
            f"• Astrodynamics: Option A with post-burn verification ✓\n"
            f"• Risk & Policy: Initially objected to Option A, revised to agree ✓\n"
            f"• System Link: Concurs, ground station ready ✓\n"
            f"• Executive: Affirming consensus ✓\n\n"
            f"NOTE: Risk & Policy's initial objection triggered a productive debate "
            f"that added a critical safety measure (post-burn verification). "
            f"This is exactly why multi-agent deliberation outperforms single-agent decision-making.\n\n"
            f"RESULT: UNANIMOUS (4/4) after 1 round of disagreement\n\n"
            f"BINDING ORDERS:\n"
            f"1. {p}: Execute {exec_strategy} burn of {exec_dv:.4f} m/s "
            f"({ms['burn_s']:.1f}s duration) at T-{min(ctx['lead_minutes'] * 0.6, 60):.0f} min before TCA.\n"
            f"2. Post-burn clearance target: >{ctx['ms']['target_au_str']} AU.\n"
            f"3. Mandatory tracking verification at TCA + 15 min.\n"
            f"4. If post-burn miss < {ms['target_km'] * 0.5 * 6.684587122e-9:.4e} AU → secondary correction authorized.\n\n"
            f"Decision logged to immutable audit ledger with full debate transcript. "
            f"SENTINEL returning to autonomous mode. Council session CLOSED."
        )

    script.append({
        "agentId": "RESPONSE",
        "agentName": AGENTS["RESPONSE"]["name"],
        "delay": 3.0,
        "message": resolution_msg,
        "vote": "CONSENSUS_EXECUTE",
        "confidence": 0.99,
        "round": 3,
        "dataCard": {
            "type": "verdict",
            "decision": "TWO_PHASE_PROTOCOL" if ctx["both_payloads"] else "EXECUTE_MANEUVER",
            "target": exec_target,
            "deltaV": exec_dv,
            "clearanceKm": ms["target_km"],
            "voteTally": {
                "total": 4,
                "agree": 4,
                "rounds": 3,
                "initialDisagreements": 1,
                "resolvedVia": "two-phase conditional" if ctx["both_payloads"] else "rebuttal + post-burn verification",
            },
        },
    })

    return script


# ─── NEXUS Council Engine ────────────────────────────────────────────────────
class NexusCouncil:
    def __init__(self):
        self.active_debates = {}
        self.debate_history = []


    async def run_debate(
        self,
        event_data: dict,
        sentinel_decision: Optional[dict] = None,
    ) -> AsyncGenerator[dict, None]:
        debate_id = f"NEX-{str(uuid.uuid4())[:8].upper()}"
        self.active_debates[debate_id] = []

        ctx = build_debate_context(event_data, sentinel_decision)
        
        # Try LLM first
        script = None
        try:
            print(f"[NEXUS] Attempting to generate debate via Gemini LLM for {debate_id}...")
            script = await generate_debate_via_llm(ctx)
            print("[NEXUS] Successfully generated LLM debate.")
        except Exception as e:
            print(f"[NEXUS] LLM generation failed ({e}). Falling back to procedural engine.")
            script = generate_debate_script(ctx)

        current_round = 0

        for step in script:
            # Emit round separator when round changes
            if step.get("round", 0) != current_round:
                current_round = step["round"]
                round_msg = {
                    "id": str(uuid.uuid4()),
                    "debateId": debate_id,
                    "agentId": "__SYSTEM__",
                    "agentName": "Council Protocol",
                    "message": f"── ROUND {current_round} {'— INITIAL POSITIONS' if current_round == 1 else '— REBUTTALS' if current_round == 2 else '— RESOLUTION'} ──",
                    "vote": None,
                    "confidence": None,
                    "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
                    "isRoundMarker": True,
                    "round": current_round,
                }
                self.active_debates[debate_id].append(round_msg)
                yield round_msg
                await asyncio.sleep(0.8)

            await asyncio.sleep(step["delay"])

            msg = {
                "id": str(uuid.uuid4()),
                "debateId": debate_id,
                "agentId": step["agentId"],
                "agentName": step["agentName"],
                "message": step["message"],
                "vote": step["vote"],
                "confidence": step["confidence"],
                "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
                "round": step.get("round"),
            }

            if step.get("dataCard"):
                msg["dataCard"] = step["dataCard"]

            self.active_debates[debate_id].append(msg)
            yield msg

        # Archive
        self.debate_history.append({
            "debateId": debate_id,
            "eventId": event_data.get("eventId", "?"),
            "messages": self.active_debates[debate_id],
            "rounds": 3,
            "completedAt": datetime.datetime.utcnow().isoformat() + "Z",
        })

    def get_status(self) -> dict:
        return {
            "nexusStatus": "STANDBY",
            "activeDebates": len(self.active_debates),
            "completedDebates": len(self.debate_history),
            "nexusMode": "multi_round_debate",
            "agentCount": 4,
            "debateRounds": 3,
        }


nexus = NexusCouncil()
