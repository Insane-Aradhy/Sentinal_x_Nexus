# Product Requirements Document (PRD)

## 1. Objective
To enhance the SENTINEL and NEXUS platforms by introducing an "Astronomical Features" page. This new page will provide advanced, computationally rigorous orbital mechanics and collision assessment tools that currently require expensive, manual software (like STK or MATLAB). These tools will be broken down into 4 distinct divisions on the page.

## 2. Scope & Features
The new page will feature four computationally advanced capabilities, each operating in its own division:

### Division 1: SGP4 / SDP4 Orbital Propagator
*   **Description:** An in-browser or native-speed propagator for tracking satellite positions in real-time.
*   **Problem Solved:** Current Python wrappers are too slow (4.2 seconds for 1000 satellites).
*   **Requirement:** A C++ based SGP4 engine (e.g., Vallado's implementation) that can compute positions for 1,000 satellites over 24 hours in under 65ms.
*   **Key Value:** Enables instant constellation health checks and visualization.

### Division 2: Foster's Collision Probability (Pc) Calculator
*   **Description:** A collision assessment engine that calculates actual probabilities instead of categorical risks ("High", "Medium").
*   **Problem Solved:** Most platforms just provide categorical labels. Real assessment requires integrating bivariate Gaussian distributions over a hard-body cross-section in the B-plane.
*   **Requirement:** Implement Foster's 1992 method using Gaussian Quadrature. Target time: ~1.8 seconds for 200 Conjunction Data Messages (CDMs).

### Division 3: Minimum Delta-V Avoidance Optimizer
*   **Description:** A maneuver optimization engine to compute the most fuel-efficient burn vector to avoid a predicted collision.
*   **Problem Solved:** Currently takes 20-30 minutes of manual simulation.
*   **Requirement:** Use Lambert's Problem (Izzo's algorithm) and Sequential Quadratic Programming (SQP) to find the globally optimal burn epoch and direction in ~1.8 seconds. It must also check for secondary conjunctions.

### Division 4: RK45 Reentry Predictor with Monte Carlo Uncertainty
*   **Description:** High-fidelity propagation for decaying orbits to predict atmospheric reentry windows and impact zones.
*   **Problem Solved:** SGP4 degrades for decaying orbits. Real prediction needs full equations of motion (J2-J6, NRLMSISE-00 atmospheric drag, Solar Radiation Pressure).
*   **Requirement:** Implement RK45 adaptive step integrator and parallelized 500-run Monte Carlo simulations to generate a reentry probability heat map.

## 3. Key Differentiator
*   **DSA Layer Integration:** The entire system will utilize optimized Data Structures and Algorithms (3D k-d trees, Binary Max-Heaps, Interval Trees) to ensure the 27,000+ object orbital catalog can be queried in milliseconds.

## 4. User Interaction
*   Users will navigate to the "Astronomical Features" dashboard.
*   They can interact with each of the 4 divisions separately.
*   There will be visible benchmarks (e.g., "Optimized vs Naive" toggle) to showcase the performance leap to users and judges.
