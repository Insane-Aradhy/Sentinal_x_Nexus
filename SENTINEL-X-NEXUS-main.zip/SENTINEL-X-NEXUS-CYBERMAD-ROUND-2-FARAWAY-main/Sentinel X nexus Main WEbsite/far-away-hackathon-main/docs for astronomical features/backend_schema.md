# Backend Schema

## 1. Core Module Integration
The backend will utilize FastAPI to expose endpoints. Rather than writing the math in Python, the backend will import a compiled C++ extension.

```python
import fastapi
import sentinel_core # C++ module built via pybind11

app = fastapi.FastAPI()
```

## 2. API Endpoints

### 2.1. Propagate Orbit (Division 1)
*   **Route:** `POST /api/astro/propagate`
*   **Payload Schema:**
    ```json
    {
      "tle_line1": "string",
      "tle_line2": "string",
      "time_window_minutes": "integer",
      "step_size_minutes": "integer"
    }
    ```
*   **Response Schema:**
    ```json
    {
      "states": [
         { "time": "float", "position": [x, y, z], "velocity": [vx, vy, vz] }
      ]
    }
    ```

### 2.2. Calculate Foster's Pc (Division 2)
*   **Route:** `POST /api/astro/foster-pc`
*   **Payload Schema:**
    ```json
    {
      "miss_distance_km": "float",
      "relative_velocity_km_s": "float",
      "hard_body_radius_m": "float",
      "covariance_matrix_1": [[float]],
      "covariance_matrix_2": [[float]]
    }
    ```
*   **Response Schema:**
    ```json
    {
      "probability_pc": "float",
      "is_above_threshold": "boolean"
    }
    ```

### 2.3. Optimize Maneuver (Division 3)
*   **Route:** `POST /api/astro/optimize-maneuver`
*   **Payload Schema:**
    ```json
    {
      "satellite_state": {"position": [], "velocity": []},
      "tca_epoch": "string",
      "threshold_miss_km": "float"
    }
    ```
*   **Response Schema:**
    ```json
    {
      "burn_epoch_minutes_from_now": "float",
      "delta_v_rtn_m_s": [float, float, float],
      "delta_v_magnitude": "float",
      "fuel_cost_kg": "float",
      "new_miss_distance_km": "float",
      "new_pc": "float",
      "creates_secondary_conjunction": "boolean"
    }
    ```

### 2.4. Predict Reentry (Division 4)
*   **Route:** `POST /api/astro/predict-reentry`
*   **Payload Schema:**
    ```json
    {
      "tle_line1": "string",
      "tle_line2": "string",
      "monte_carlo_runs": "integer"
    }
    ```
*   **Response Schema:**
    ```json
    {
      "reentry_window_10th_percentile": "string (timestamp)",
      "reentry_window_90th_percentile": "string (timestamp)",
      "heatmap_points": [
         { "lat": float, "lng": float, "weight": float }
      ]
    }
    ```

## 3. Data Structures Models
Internally, the `sentinel_core` handles caching and memory management for the catalog.
*   **Catalog Sync:** A daily job fetches TLEs from Space-Track and updates the C++ `std::unordered_map` and the 3D k-d tree in memory.
