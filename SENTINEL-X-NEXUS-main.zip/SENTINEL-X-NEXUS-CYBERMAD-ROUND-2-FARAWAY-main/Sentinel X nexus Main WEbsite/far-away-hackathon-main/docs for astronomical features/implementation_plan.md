# Implementation Plan

## Overview
The goal is to implement the "Astronomical Features" page in 4 distinct divisions, driven by a highly optimized C++ mathematical core integrated into our existing Python backend, and displayed via our React frontend.

## Phase 1: C++ Core Development (Backend)
1.  **Setup Environment:** Set up `pybind11` and CMake for the FastAPI backend repository.
2.  **DSA Foundation:** Implement the 3D k-d tree, Max-Heap, and Bloom filter structures to handle catalog scale.
3.  **Feature 1 (SGP4):** Integrate Vallado's C++ SGP4 propagator. Expose python bindings.
4.  **Feature 2 (Foster's Pc):** Write the 2x2 covariance projection and Gaussian quadrature integration.
5.  **Feature 3 (Maneuver):** Implement Izzo's algorithm for Lambert's problem and integrate NLopt for SQP optimization.
6.  **Feature 4 (Reentry):** Implement RK45 with adaptive step size. Integrate the NRLMSISE-00 atmospheric model. Wrap the loop in an OpenMP `#pragma` for Monte Carlo parallelization.

## Phase 2: FastAPI Integration (Backend)
1.  **Import Core:** Bind `sentinel_core.so` into the FastAPI app.
2.  **Create Endpoints:** Write the 4 REST/WebSocket endpoints (`/propagate`, `/foster-pc`, `/optimize-maneuver`, `/predict-reentry`).
3.  **PDF Generator:** Integrate `ReportLab` to build the "Maneuver Report" PDF based on the optimizer's output.

## Phase 3: Frontend Development (React)
1.  **Routing:** Add `/astronomical-features` to the `react-router`.
2.  **Layout:** Create a master layout with side-navigation/tabs for Division 1, 2, 3, and 4.
3.  **Division 1 (SGP4):** Build a data table or map component. Add the "Optimized vs Naive" benchmark toggle.
4.  **Division 2 (Foster's Pc):** Build the comparison view (categorical risk vs exact $P_c$).
5.  **Division 3 (Delta-V):** Create forms for threshold inputs. Build the output card showing RTN Delta-V and fuel cost. Add the PDF download button.
6.  **Division 4 (Reentry):** Integrate `Leaflet.js` and `heatmap.js`. Build the map canvas that consumes the Monte Carlo distribution points to render the uncertainty ellipse.

## Phase 4: Integration and Styling
1.  **Styling:** Ensure all components match the "Space Grotesk" neon-glassmorphism aesthetic dictated by the UI/UX design brief.
2.  **API Hookup:** Connect all React hooks to the FastAPI endpoints.
3.  **Error Handling:** Ensure the C++ exceptions are gracefully caught by pybind11 and converted to HTTP 400/500 errors in FastAPI.

## Phase 5: Verification & Testing
1.  Test SGP4 output against reference TLEs.
2.  Verify Foster's Pc calculations using known Conjunction Data Messages.
3.  Validate Leaflet heatmap rendering performance with 500+ data points.
4.  Perform final UI polishing and micro-interaction checks.
