# Application Flow

## 1. Entry Point
*   User logs into the SENTINEL/NEXUS dashboard.
*   User clicks on the "Astronomical Features" module from the main navigation sidebar.
*   The system loads a hub page presenting 4 tabbed divisions.

## 2. Division 1: SGP4 Orbital Propagation
1.  **Input:** User selects a constellation or inputs a TLE set.
2.  **Action:** The React frontend sends a WebSocket request to the backend.
3.  **Processing:** FastAPI routes the request to the `sentinel_core.so` C++ module. SGP4 propagation calculates orbital states for 24-hours into the future.
4.  **Output:** The frontend receives the position/velocity vectors and immediately updates the 3D globe and data tables.
5.  **DSA Demo:** User toggles "k-d tree search". The frontend fires a proximity search to the backend. Backend uses the C++ k-d tree to return near-instant results.

## 3. Division 2: Foster's Collision Probability
1.  **Input:** User selects a RED alert conjunction event from the timeline.
2.  **Action:** Frontend requests a deep probability analysis.
3.  **Processing:** C++ core projects the combined covariances of the two objects onto the B-plane and evaluates the bivariate Gaussian integral using Gaussian quadrature.
4.  **Output:** Frontend renders the exact numerical probability $P_c$ alongside the maneuver threshold limit.

## 4. Division 3: Delta-V Avoidance Optimizer
1.  **Input:** From a RED alert event (in Division 2), the user clicks "Calculate Avoidance Maneuver".
2.  **Action:** User defines a safety threshold (e.g., 5 km miss distance).
3.  **Processing:** C++ core runs SQP nonlinear optimization wrapped around Izzo's Lambert solver. It searches for the minimum $\Delta V$ required and simultaneously checks for secondary conjunctions.
4.  **Output:** Frontend displays the optimal burn time, RTN vector, and total fuel cost.
5.  **Export:** User clicks "Download Report". Backend uses `ReportLab` to generate a PDF and triggers a file download in the browser.

## 5. Division 4: Reentry Predictor
1.  **Input:** User inputs a decaying satellite's TLE and selects "Predict Reentry".
2.  **Action:** User sets Monte Carlo parameters (e.g., 500 runs).
3.  **Processing:** C++ core launches OpenMP parallel threads. Each thread runs an RK45 integrator with NRLMSISE-00 drag models, slightly varying solar flux and area-to-mass ratios.
4.  **Output:** The backend returns an array of simulated reentry coordinates and time percentiles (10th-90th).
5.  **Rendering:** Frontend passes coordinates to Leaflet.js which draws the uncertainty ellipse heat map on a global map layout.
