# Technical Requirements Document (TRD)

## 1. System Architecture
The 4 astronomical features will not require new microservices. Instead, they will be built as a single, highly optimized C++ core module (`sentinel_core.so`).

*   **Backend:** Python FastAPI backend will load the C++ module using `pybind11`. (Alternatively, it can be compiled to WASM via Emscripten for pure client-side execution, but PyBind11 is recommended for speed of integration).
*   **Frontend:** React-based dashboard communicating with the backend via REST APIs and WebSockets.
*   **Data Structures Layer:** The performance relies heavily on C++ data structures (k-d trees, max-heaps, etc.) handling the 27,000+ object space catalog.

## 2. Detailed Technical Stack
### Core Technologies
*   **C++17:** For all heavy computations (SGP4, Integration, Optimization).
*   **pybind11:** To create Python bindings for the C++ logic.
*   **Eigen 3:** C++ header-only library for linear algebra, 2x2 covariance matrix operations, and rotation matrices.
*   **OpenMP:** For parallelizing the 500-run Monte Carlo simulations across CPU cores.

### Division-Specific Libraries
*   **Division 1 (SGP4):** Vallado SGP4 reference implementation in C++.
*   **Division 2 (Foster's Pc):** Boost.Math for Gaussian quadrature weights and nodes.
*   **Division 3 (Maneuver Optimizer):** NLopt (or NLOPT-C++) for SQP/SLSQP nonlinear optimization. ReportLab (Python) for generating PDF maneuver reports.
*   **Division 4 (Reentry Predictor):** nrlmsise-00 C port for atmospheric density models. Leaflet.js and heatmap.js for the frontend React map.

## 3. Data Structures & Algorithms (DSA) Layer Requirements
To ensure real-time performance on a catalog of 27,000 satellites, the C++ core MUST implement:
1.  **3D k-d Tree:** For O(log n) proximity searches (e.g., finding all debris within 50km).
2.  **Binary Max-Heap:** For O(log n) sorting of conjunction events by $P_c$ to instantly triage the most dangerous events.
3.  **Interval Tree:** For O(log n + k) timeline queries of conjunctions over specific time windows.
4.  **Dijkstra's Algorithm on Orbital Graph:** For multi-burn minimum-cost transfer routing.
5.  **Bloom Filter:** For O(1) TLE checksum validation.

## 4. Performance Targets
*   **SGP4 Propagation:** 1000 satellites × 24-hours in < 65 ms.
*   **Foster's Pc:** Evaluate 200 CDMs in < 2.0 seconds.
*   **Delta-V Optimization:** Find optimal maneuver and check secondary conjunctions in < 2.0 seconds.
*   **Reentry Prediction:** 500 Monte Carlo runs over decaying orbits in < 15 seconds (using OpenMP).

## 5. Security & Deployment
*   No additional Docker containers required. The C++ code compiles into the existing FastAPI environment during the build step.
*   Dependencies like Eigen and NLopt will be statically linked or managed via package managers to ensure portability.
