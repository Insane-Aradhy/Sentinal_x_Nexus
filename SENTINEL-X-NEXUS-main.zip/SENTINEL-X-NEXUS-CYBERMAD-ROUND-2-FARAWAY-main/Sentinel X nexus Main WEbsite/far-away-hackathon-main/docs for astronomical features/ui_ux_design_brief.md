# UI/UX Design Brief

## 1. Visual Theme and Aesthetic
The new "Astronomical Features" page must strictly adhere to the overarching visual identity of the platform:
*   **Colors:** Deep space dark theme. Backgrounds (`#0A0A0E`, `#10101A`). High-contrast, neon-tinged accents (Green `#00E676`, Blue `#00B0FF`, Orange `#FF9100`, Red `#FF1744`).
*   **Typography:** 'Space Grotesk' for headers/numbers, 'JetBrains Mono' for data, metrics, code blocks, and 'Inter' for body text.
*   **Glassmorphism:** Use semi-transparent panels with blur effects (`backdrop-filter: blur(8px)`) and subtle tinted borders to separate the divisions.

## 2. Layout Structure
The page will be organized into **4 primary divisions** corresponding to the 4 features.
*   A side navigation or top-level pill-navigation menu will allow the user to quickly jump between the 4 divisions.
*   Each division will function as a self-contained dashboard panel.

## 3. Division Layouts

### Division 1: SGP4 Propagator
*   **Visuals:** A live table or 3D orbital visualization of the catalog.
*   **Interactive Elements:** The "Benchmark Toggle". A switch labeled "OPTIMIZED (k-d tree) / NAIVE (brute force)". When toggled to naive, the UI simulates a hang (182ms). When optimized, it processes instantly (0.3ms). This makes the backend C++ improvements tangible to the user.

### Division 2: Foster's Pc Calculator
*   **Visuals:** Side-by-side comparison. Left side shows legacy "HIGH/LOW" risk alerts. Right side shows the calculated $P_c$ (e.g., $1.4 \times 10^{-4}$) in precise JetBrains Mono font.
*   **Interactive Elements:** A list of incoming Conjunction Data Messages (CDMs) that the user can click on to see the bivariate Gaussian distribution metrics.

### Division 3: Maneuver Optimizer
*   **Visuals:** A clean input panel for constraints (miss distance threshold).
*   **Output:** Highlighted optimal Burn Epoch and $\Delta V$ vector (Radial, Transverse, Normal). 
*   **Interactive Elements:** A prominent "Generate One-Click Maneuver Report (PDF)" button.

### Division 4: Reentry Predictor
*   **Visuals:** The most striking visual element of the page. An interactive world map integrated with `Leaflet.js` and `heatmap.js`.
*   **Output:** A bright thermal heatmap overlaid on the map showing the probability distribution of the debris ground track.
*   **Interactive Elements:** Controls to adjust Monte Carlo run counts or input atmospheric uncertainty bounds ($F_{10.7}$ solar flux).

## 4. Micro-interactions
*   Hovering over mathematical terms or acronyms (e.g., `RTN`, `TCA`, `SQP`) should display a small tooltip explaining the concept.
*   Progress bars for the Monte Carlo simulations should update smoothly using WebSockets.
