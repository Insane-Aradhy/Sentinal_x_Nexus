# Sentinel & Nexus - System Architecture & Hackathon Context

This document serves as the definitive source of truth for the Sentinel & Nexus space situational awareness platform, developed for the Far Away Hackathon (by Zuup).

## 1. Executive Summary & Value Proposition

### Problem Statement
Low Earth Orbit (LEO) is becoming increasingly congested with active satellites, defunct payloads, and space debris. The risk of catastrophic collisions (Kessler Syndrome) threatens the sustainability of space operations. Existing tools for conjunction assessment and orbital mitigation are often siloed, slow, or lack intuitive real-time visualizations.

### Core Solution & Key Differentiators
Sentinel & Nexus provides a unified, dual-agent operator console:
*   **Sentinel (Surveillance):** Autonomously scans live TLE (Two-Line Element) streams, propagating orbits using SGP4/SDP4 models to predict close approaches and conjunctions.
*   **Nexus (Mitigation):** Acts as a rapid-response autonomous agent, calculating orbital mechanics solutions (like Hohmann Transfer Delta-V) to suggest collision avoidance maneuvers.

**Key Differentiators for Judges:**
*   **Real-time WebGL 3D Visualization:** An interactive globe rendering live satellite trajectories.
*   **Math-Heavy Astronomical Core:** Implements real orbital mechanics formulas (Foster's Pc, Delta-V optimization, Reentry prediction) rather than just UI mockups.
*   **Dual-Agent AI Architecture Concept:** The system logically separates threat detection (Sentinel) from threat mitigation (Nexus), mirroring real-world defense frameworks.

### Target User Persona & Primary Workflows
*   **Target Users:** Satellite Fleet Operators, Space Situational Awareness (SSA) Analysts, Astronomical Researchers.
*   **Primary Workflows:**
    1.  Monitor the 3D globe and side panels for incoming conjunction alerts.
    2.  Review automated mitigation strategies provided by the Nexus agent.
    3.  Use the Astronomical Core modules to manually verify collision probabilities or plan future orbital transfers.
    4.  Track Near-Earth Objects (NEOs) for broader planetary defense context.

---

## 2. Tech Stack & Infrastructure

*   **Frontend Ecosystem:**
    *   **Framework:** React (built via Vite for rapid HMR and optimized builds).
    *   **3D Rendering:** Three.js / React Three Fiber (`react-three/fiber`, `react-three/drei`).
    *   **Styling:** Standard CSS with a sci-fi/operator console design language (neon accents, glassmorphism).
    *   **Mapping:** `react-globe.gl` / custom Three.js implementations for orbital tracks.
*   **Backend Ecosystem:**
    *   **Framework:** Python 3 + FastAPI.
    *   **Server:** Uvicorn (ASGI) for handling asynchronous operations and WebSockets.
    *   **Math/Data Science:** `numpy`, `sgp4` (for orbital propagation).
*   **External APIs & Data Sources:**
    *   **Orbital Data:** Celestrak / Space-Track APIs (TLE data fetching).
    *   **Asteroids:** NASA NeoWs (Near Earth Object Web Service) API.
    *   **Imagery:** NASA APOD & NASA Image Library APIs.
*   **Deployment Architecture:**
    *   **Frontend:** Vercel (static site hosting with seamless CI/CD).
    *   **Backend:** Hugging Face Spaces (Dockerized environment). Crucially, the backend dynamically binds to the `$PORT` environment variable to comply with Hugging Face's container orchestration.

---

## 3. Core Component Architecture

### 3.1 Backend Architecture (`/backend`)
*   `main.py`: The FastAPI application entry point. Handles CORS middleware, registers REST API endpoints (like the `/api/neo` NASA proxy), and manages the primary WebSocket `/ws` endpoint for streaming real-time telemetry to the frontend.
*   `sentinel_agent.py`: The threat detection engine. Continuously runs a background loop to propagate orbits using the SGP4 algorithm, calculating relative distances between objects to flag Nominal, Caution, or Critical conjunctions.
*   `nexus_agent.py`: The mitigation engine. When Sentinel flags a threat, Nexus calculates the physics required to avoid it, including fuel requirements (Delta-V) for Hohmann transfers.
*   `celestrak.py`: Data ingestion layer responsible for pulling fresh TLE catalogs.
*   `orbital.py`: A utility module containing pure math functions for orbital mechanics conversions.

### 3.2 Frontend Architecture (`/frontend/src`)
*   `App.jsx`: The central orchestrator. Manages the global layout, establishes the WebSocket connection via custom hooks, holds the central application state (alerts, telemetry), and manages the z-index/display logic for the global alert bar.
*   `components/OrbitalGlobe.jsx`: Renders the 3D interactive Earth and plots satellites based on the live data stream.
*   `components/SentinelPanel.jsx` & `NexusPanel.jsx`: The left and right floating operator interfaces. They consume data passed down from `App.jsx` to display target stats and mitigation solutions.
*   `components/AstronomicalFeatures.jsx`: A heavily customized dashboard containing four distinct computational modules (SGP4 Propagator, Probability of Collision, Delta-V Optimizer, Reentry Predictor).
*   `components/AsteroidTracker.jsx`: A dedicated view for monitoring Near Earth Objects, interfacing directly with the backend proxy to NASA APIs.
*   `components/SpaceImageGallery.jsx`: Renders the interactive space imagery feed.
*   `services/` & `hooks/`: Contains logic for establishing the WebSocket (`useBackend.js`) and fetching REST data (`liveData.js`), dynamically resolving the backend URL via `import.meta.env`.

---

## 4. Key Features & Workflows

1.  **Continuous Conjunction Assessment:** The backend continuously simulates orbital paths. When two tracked objects breach a predefined proximity threshold (e.g., 50km), the system broadcasts a "Critical" alert payload over the WebSocket.
2.  **Automated Mitigation Generation:** In response to a Critical alert, the Nexus agent immediately computes a safe avoidance trajectory (Hohmann Transfer) and broadcasts the required Delta-V (fuel expenditure) back to the operator.
3.  **UI/UX Alert Mechanics:** When a Critical alert is received, a high-visibility alert bar drops down from the top of the screen. To prevent it from obstructing the operator panels (`z-index: 10`), a `setTimeout` function in `App.jsx` automatically drops the alert bar's `z-index` to `9` after 3 seconds, slipping it cleanly behind the side panels.
4.  **Astronomical Computation Core:** A suite of specialized tools allowing manual override and deep-dive analysis. Operators can input specific TLEs and timestamps to run localized, high-precision physics calculations in the browser.

---

## 5. API & Data Flow Matrix

### 5.1 WebSocket Feed
*   **Endpoint:** `ws://[BACKEND_URL]/ws`
*   **Direction:** Backend -> Frontend (Streaming)
*   **Payload (JSON):** Contains arrays of satellite positions (latitude, longitude, altitude), current system status, and active alerts (Nominal, Caution, Critical) complete with target names and IDs.

### 5.2 REST Endpoints
*   **`GET /`**: Health check and basic API status.
*   **`GET /api/neo`**: Acts as a proxy for the NASA NeoWs API. 
    *   *Why?* Bypasses strict CORS policies from the NASA servers when requested directly from the browser, ensuring the frontend Asteroid Tracker functions reliably.

---

## 6. UI/UX Design System

*   **Visual Language:** "Sci-Fi Operator Console". Heavily relies on dark mode aesthetics, monospace fonts for data readouts, and high-contrast neon colors.
*   **Color Palette:**
    *   **Nominal/Safe:** Neon Green (#00ff00)
    *   **Caution/Warning:** Neon Yellow (#ffff00)
    *   **Critical/Danger:** Neon Red/Crimson (#ff0000)
*   **Layout Strategy:**
    *   **Top Bar:** Branding and global telemetry stats, centered dynamically.
    *   **Left/Right Flanks:** Floating translucent data panels (Sentinel and Nexus).
    *   **Center Stage:** Unobstructed view of the 3D WebGL Globe.

---

## 7. Next 24 Hours: Hackathon Roadmap

If we were to extend this sprint for another 24 hours, the immediate technical priorities would be:
1.  **WebAssembly (Wasm) Porting:** Port the heavy JavaScript calculations within `AstronomicalFeatures.jsx` (SGP4, Foster's Pc) to Rust or C++ compiled to Wasm. This would drastically improve frontend performance and prevent UI thread blocking during complex simulations.
2.  **Multiplayer Collaboration Mode:** Implement Socket.io rooms to allow multiple analysts (e.g., one in the US, one in Europe) to view and acknowledge the same conjunction alert simultaneously.
3.  **Real Hardware Integration:** Replace the Celestrak proxy feed with a simulated raw telemetry stream representing a direct ground-station downlink.
4.  **Database Persistence:** Add PostgreSQL or MongoDB to log historical conjunction events and mitigation actions, allowing for post-incident analysis and machine learning model training.
