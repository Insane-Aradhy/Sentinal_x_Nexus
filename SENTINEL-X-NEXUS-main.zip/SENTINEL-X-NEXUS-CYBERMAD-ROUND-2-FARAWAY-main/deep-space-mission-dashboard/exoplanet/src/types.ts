export interface Exoplanet {
  pl_name: string;
  hostname: string;
  discoverymethod: string;
  disc_year: number;
  pl_masse: number | null;
  pl_rade: number | null;
}

export type SortKey = keyof Exoplanet;
export type SortDir = "asc" | "desc";

export interface FilterState {
  search: string;
  method: string;
  minMass: string;
  maxMass: string;
}
