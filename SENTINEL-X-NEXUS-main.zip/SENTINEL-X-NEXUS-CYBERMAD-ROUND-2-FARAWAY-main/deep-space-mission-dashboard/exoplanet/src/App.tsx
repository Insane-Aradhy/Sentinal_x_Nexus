import { useState, useEffect, useMemo } from "react";
import type { Exoplanet, FilterState } from "./types";
import StarField from "./components/StarField";
import StatCards from "./components/StatCards";
import PlanetTable from "./components/PlanetTable";
import DetailPanel from "./components/DetailPanel";
import Charts from "./components/Charts";
import FilterBar from "./components/FilterBar";
import LoadingSkeleton from "./components/LoadingSkeleton";
import JudgeAssistDropdown from "./components/JudgeAssist/JudgeAssistDropdown";

// ─── Fallback Mock Data ───────────────────────────────────────────────────────
const mockData: Exoplanet[] = [
  { pl_name: "Kepler-22 b",    hostname: "Kepler-22",         discoverymethod: "Transit",        disc_year: 2011, pl_masse: 36.0,  pl_rade: 2.38 },
  { pl_name: "Proxima Cen b",  hostname: "Proxima Centauri",  discoverymethod: "Radial Velocity", disc_year: 2016, pl_masse: 1.27,  pl_rade: 1.03 },
  { pl_name: "TRAPPIST-1 e",   hostname: "TRAPPIST-1",        discoverymethod: "Transit",        disc_year: 2017, pl_masse: 0.69,  pl_rade: 0.92 },
  { pl_name: "K2-18 b",        hostname: "K2-18",             discoverymethod: "Transit",        disc_year: 2015, pl_masse: 8.63,  pl_rade: 2.61 },
  { pl_name: "HD 209458 b",    hostname: "HD 209458",         discoverymethod: "Transit",        disc_year: 1999, pl_masse: 219.3, pl_rade: 14.09},
  { pl_name: "55 Cnc e",       hostname: "55 Cnc",            discoverymethod: "Radial Velocity", disc_year: 2004, pl_masse: 8.08,  pl_rade: 1.92 },
  { pl_name: "GJ 1214 b",      hostname: "GJ 1214",           discoverymethod: "Transit",        disc_year: 2009, pl_masse: 6.26,  pl_rade: 2.68 },
  { pl_name: "WASP-39 b",      hostname: "WASP-39",           discoverymethod: "Transit",        disc_year: 2011, pl_masse: 90.3,  pl_rade: 13.9 },
  { pl_name: "HR 8799 b",      hostname: "HR 8799",           discoverymethod: "Imaging",        disc_year: 2008, pl_masse: 2231.0,pl_rade: 12.9 },
  { pl_name: "TRAPPIST-1 d",   hostname: "TRAPPIST-1",        discoverymethod: "Transit",        disc_year: 2016, pl_masse: 0.39,  pl_rade: 0.79 },
  { pl_name: "TRAPPIST-1 f",   hostname: "TRAPPIST-1",        discoverymethod: "Transit",        disc_year: 2017, pl_masse: 1.04,  pl_rade: 1.05 },
  { pl_name: "TRAPPIST-1 g",   hostname: "TRAPPIST-1",        discoverymethod: "Transit",        disc_year: 2017, pl_masse: 1.32,  pl_rade: 1.13 },
  { pl_name: "Tau Boo b",      hostname: "Tau Boo",           discoverymethod: "Radial Velocity", disc_year: 1996, pl_masse: 1338.0,pl_rade: null },
  { pl_name: "HD 40307 g",     hostname: "HD 40307",          discoverymethod: "Radial Velocity", disc_year: 2012, pl_masse: 7.1,   pl_rade: null },
  { pl_name: "TOI-700 d",      hostname: "TOI-700",           discoverymethod: "Transit",        disc_year: 2020, pl_masse: 1.72,  pl_rade: 1.14 },
  { pl_name: "LHS 1140 b",     hostname: "LHS 1140",          discoverymethod: "Transit",        disc_year: 2017, pl_masse: 6.38,  pl_rade: 1.43 },
  { pl_name: "Kepler-452 b",   hostname: "Kepler-452",        discoverymethod: "Transit",        disc_year: 2015, pl_masse: null,  pl_rade: 1.63 },
  { pl_name: "Wolf 1061 c",    hostname: "Wolf 1061",         discoverymethod: "Radial Velocity", disc_year: 2015, pl_masse: 4.25,  pl_rade: null },
  { pl_name: "GJ 667C c",      hostname: "GJ 667C",           discoverymethod: "Radial Velocity", disc_year: 2011, pl_masse: 3.8,   pl_rade: null },
  { pl_name: "Kepler-62 f",    hostname: "Kepler-62",         discoverymethod: "Transit",        disc_year: 2013, pl_masse: null,  pl_rade: 1.41 },
];

// ─── Data Source Badge ────────────────────────────────────────────────────────
function DataSourceBadge({ isLive }: { isLive: boolean | null }) {
  if (isLive === null) return null;
  return (
    <div
      className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${
        isLive
          ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-400"
          : "border-amber-500/40 bg-amber-500/10 text-amber-400"
      }`}
    >
      <span
        className={`w-1.5 h-1.5 rounded-full ${isLive ? "bg-emerald-400 animate-pulse" : "bg-amber-400"}`}
      />
      {isLive ? "NASA Live Data" : "Offline Fallback"}
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [planets, setPlanets] = useState<Exoplanet[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [_error, setError] = useState<string | null>(null);
  const [isLive, setIsLive] = useState<boolean | null>(null);
  const [selected, setSelected] = useState<Exoplanet | null>(null);
  const [filters, setFilters] = useState<FilterState>({
    search: "",
    method: "",
    minMass: "",
    maxMass: "",
  });
  const [activeTab, setActiveTab] = useState<"table" | "charts">("table");

  // ── Exact fetch logic as specified ──────────────────────────────────────────
  const fetchPlanets = async () => {
    setIsLoading(true);
    setError(null);

    const query =
      "select top 20 pl_name, hostname, discoverymethod, disc_year, pl_masse, pl_rade from ps where default_flag=1 order by releasedate desc";
    const url = `https://exoplanetarchive.ipac.caltech.edu/TAP/sync?query=${encodeURIComponent(query)}&format=json`;

    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error("API Response not OK");
      const data = await response.json();
      setPlanets(data);
      setIsLive(true);
    } catch (err) {
      console.warn("API blocked by iframe/CORS. Loading fallback data...", err);
      setPlanets(mockData); // Failsafe activation
      setIsLive(false);
    } finally {
      setIsLoading(false);
    }
  };

  // Run on mount
  useEffect(() => {
    fetchPlanets();
  }, []);

  // ── Filtered planets ─────────────────────────────────────────────────────
  const filtered = useMemo(() => {
    return planets.filter((p) => {
      const q = filters.search.toLowerCase();
      if (q && !p.pl_name?.toLowerCase().includes(q) && !p.hostname?.toLowerCase().includes(q))
        return false;
      if (filters.method && p.discoverymethod !== filters.method) return false;
      if (filters.minMass && (p.pl_masse == null || p.pl_masse < Number(filters.minMass)))
        return false;
      if (filters.maxMass && (p.pl_masse == null || p.pl_masse > Number(filters.maxMass)))
        return false;
      return true;
    });
  }, [planets, filters]);

  return (
    <div className="relative min-h-screen text-slate-100 overflow-x-hidden">
      <StarField />

      {/* Main content */}
      <div className="relative z-10 min-h-screen">
        <JudgeAssistDropdown />
        
        {/* ── Header ── */}
        <header className="glass border-b border-slate-700/40 sticky top-0 z-50">
          <div className="max-w-screen-2xl mx-auto px-4 md:px-6 py-3 flex flex-wrap items-center gap-3">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 flex-shrink-0">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-xl shadow-lg shadow-indigo-900/50">
                  🪐
                </div>
                <div className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full bg-cyan-400 border-2 border-slate-900 animate-pulse" />
              </div>
              <div>
                <h1 className="text-base font-bold text-white leading-none tracking-tight">
                  Exoplanet Dashboard
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">NASA Archive Explorer</p>
              </div>
            </div>

            {/* Source badge */}
            <div className="ml-2">
              <DataSourceBadge isLive={isLive} />
            </div>

            {/* Spacer */}
            <div className="flex-1" />

            {/* Tabs */}
            <div className="flex items-center gap-1 bg-slate-800/60 rounded-lg p-1 border border-slate-700/40">
              {(["table", "charts"] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all capitalize ${
                    activeTab === tab
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-900/50"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  {tab === "table" ? "📋 Catalog" : "📊 Charts"}
                </button>
              ))}
            </div>

            {/* NASA link */}
            <a
              href="https://exoplanetarchive.ipac.caltech.edu/"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden md:flex items-center gap-1.5 text-xs text-slate-400 hover:text-indigo-300 transition border border-slate-700/40 hover:border-indigo-500/40 px-3 py-1.5 rounded-lg"
            >
              <span>🌐</span> NASA Archive ↗
            </a>
          </div>
        </header>

        {/* ── Hero banner ── */}
        <div
          className="relative overflow-hidden"
          style={{
            background:
              "linear-gradient(180deg, rgba(99,102,241,0.06) 0%, transparent 100%)",
            borderBottom: "1px solid rgba(99,102,241,0.1)",
          }}
        >
          <div className="max-w-screen-2xl mx-auto px-4 md:px-6 py-8">
            <div className="flex flex-col md:flex-row md:items-center gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <div className="h-px flex-1 max-w-[40px] bg-gradient-to-r from-transparent to-indigo-500" />
                  <span className="text-xs text-indigo-400 font-semibold uppercase tracking-widest">
                    Live Exploration
                  </span>
                </div>
                <h2 className="text-2xl md:text-3xl font-bold text-white leading-tight">
                  Worlds Beyond Our Solar System
                </h2>
                <p className="text-slate-400 text-sm mt-2 max-w-lg">
                  Real-time data from the{" "}
                  <span className="text-indigo-300 font-medium">NASA Exoplanet Archive</span>.
                  Explore confirmed exoplanets — their masses, radii, hosts, and discovery methods.
                </p>
              </div>

              {/* Decorative system visual */}
              <div className="hidden lg:flex items-center justify-center w-40 h-24 relative">
                {/* Sun */}
                <div
                  className="absolute w-10 h-10 rounded-full"
                  style={{
                    background: "radial-gradient(circle at 35% 35%, #fbbf24, #f97316)",
                    boxShadow: "0 0 24px rgba(251,191,36,0.5), 0 0 48px rgba(251,191,36,0.2)",
                    left: "50%",
                    top: "50%",
                    transform: "translate(-50%,-50%)",
                  }}
                />
                {/* Orbit rings */}
                {[44, 64, 80].map((r, i) => (
                  <div
                    key={i}
                    className="absolute rounded-full border"
                    style={{
                      width: r,
                      height: r,
                      borderColor: `rgba(99,102,241,${0.2 - i * 0.05})`,
                      left: "50%",
                      top: "50%",
                      transform: "translate(-50%,-50%)",
                    }}
                  />
                ))}
                {/* Orbiting planets */}
                {[
                  { r: 22, color: "#6366f1", dur: "3s", delay: "0s" },
                  { r: 32, color: "#22d3ee", dur: "5s", delay: "1s" },
                  { r: 40, color: "#a78bfa", dur: "7s", delay: "2s" },
                ].map((planet, i) => (
                  <div
                    key={i}
                    className="absolute"
                    style={{
                      width: planet.r * 2,
                      height: planet.r * 2,
                      left: "50%",
                      top: "50%",
                      transform: "translate(-50%,-50%)",
                      animation: `orbit ${planet.dur} linear infinite`,
                      animationDelay: planet.delay,
                    }}
                  >
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{
                        background: planet.color,
                        boxShadow: `0 0 8px ${planet.color}`,
                        position: "absolute",
                        top: 0,
                        left: "50%",
                        transform: "translate(-50%, -50%)",
                      }}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ── Main content ── */}
        <main className="max-w-screen-2xl mx-auto px-4 md:px-6 py-6 space-y-5">
          {isLoading ? (
            <LoadingSkeleton />
          ) : (
            <>
              {/* Stat Cards */}
              <StatCards planets={filtered} />

              {/* Filter Bar */}
              <FilterBar
                filters={filters}
                onChange={setFilters}
                planets={planets}
                onRefresh={fetchPlanets}
                isLoading={isLoading}
              />

              {/* Filtered count notice */}
              {filtered.length !== planets.length && (
                <div className="flex items-center gap-2 text-xs text-amber-400 bg-amber-500/10 border border-amber-500/20 rounded-lg px-4 py-2">
                  <span>⚠️</span>
                  <span>
                    Showing <strong>{filtered.length}</strong> of <strong>{planets.length}</strong> planets matching your filters.
                  </span>
                  <button
                    onClick={() => setFilters({ search: "", method: "", minMass: "", maxMass: "" })}
                    className="ml-auto text-amber-300 hover:text-amber-100 underline"
                  >
                    Clear
                  </button>
                </div>
              )}

              {/* Tab content */}
              {activeTab === "table" ? (
                <div className="grid grid-cols-1 xl:grid-cols-[1fr_310px] gap-4">
                  <PlanetTable
                    planets={filtered}
                    selected={selected}
                    onSelect={setSelected}
                  />
                  <DetailPanel planet={selected} />
                </div>
              ) : (
                <Charts planets={filtered} />
              )}

              {/* Empty state */}
              {filtered.length === 0 && !isLoading && (
                <div className="glass-card rounded-2xl flex flex-col items-center justify-center py-16 text-center">
                  <div className="text-5xl mb-4">🌌</div>
                  <p className="text-slate-300 font-semibold text-lg">No planets found</p>
                  <p className="text-slate-500 text-sm mt-1">Try adjusting your filters</p>
                  <button
                    onClick={() => setFilters({ search: "", method: "", minMass: "", maxMass: "" })}
                    className="mt-4 px-4 py-2 bg-indigo-600/80 hover:bg-indigo-600 text-white text-sm rounded-lg transition"
                  >
                    Reset Filters
                  </button>
                </div>
              )}
            </>
          )}
        </main>

        {/* ── Footer ── */}
        <footer className="border-t border-slate-800/60 mt-8">
          <div className="max-w-screen-2xl mx-auto px-4 md:px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <span>🪐</span>
              <span>Exoplanet Dashboard — powered by NASA Exoplanet Archive TAP</span>
            </div>
            <div className="flex items-center gap-4">
              <span>Data restricted to top 20 entries</span>
              <span>•</span>
              <span className={isLive ? "text-emerald-600" : "text-amber-600"}>
                {isLive === null ? "Connecting…" : isLive ? "Live feed active" : "Fallback mode"}
              </span>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
