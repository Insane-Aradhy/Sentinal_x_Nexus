import type { FilterState, Exoplanet } from "../types";

interface Props {
  filters: FilterState;
  onChange: (f: FilterState) => void;
  planets: Exoplanet[];
  onRefresh: () => void;
  isLoading: boolean;
}

export default function FilterBar({ filters, onChange, planets, onRefresh, isLoading }: Props) {
  const methods = Array.from(
    new Set(planets.map((p) => p.discoverymethod).filter(Boolean))
  ).sort();

  const set = (key: keyof FilterState, value: string) =>
    onChange({ ...filters, [key]: value });

  return (
    <div className="glass-card rounded-xl px-4 py-3 flex flex-wrap items-center gap-3">
      {/* Search */}
      <div className="relative flex-1 min-w-[160px]">
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm">🔍</span>
        <input
          type="text"
          placeholder="Search planet or host…"
          value={filters.search}
          onChange={(e) => set("search", e.target.value)}
          className="w-full bg-slate-800/70 border border-slate-700/60 rounded-lg pl-8 pr-3 py-2 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500/70 focus:ring-1 focus:ring-indigo-500/30 transition"
        />
      </div>

      {/* Method filter */}
      <select
        value={filters.method}
        onChange={(e) => set("method", e.target.value)}
        className="bg-slate-800/70 border border-slate-700/60 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-indigo-500/70 focus:ring-1 focus:ring-indigo-500/30 transition cursor-pointer"
      >
        <option value="">All Methods</option>
        {methods.map((m) => (
          <option key={m} value={m}>{m}</option>
        ))}
      </select>

      {/* Min mass */}
      <div className="flex items-center gap-1.5">
        <span className="text-xs text-slate-500 whitespace-nowrap">Mass ≥</span>
        <input
          type="number"
          placeholder="0"
          value={filters.minMass}
          onChange={(e) => set("minMass", e.target.value)}
          className="w-20 bg-slate-800/70 border border-slate-700/60 rounded-lg px-2 py-2 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500/70 focus:ring-1 focus:ring-indigo-500/30 transition"
        />
        <span className="text-xs text-slate-500">M⊕</span>
      </div>

      {/* Max mass */}
      <div className="flex items-center gap-1.5">
        <span className="text-xs text-slate-500 whitespace-nowrap">≤</span>
        <input
          type="number"
          placeholder="∞"
          value={filters.maxMass}
          onChange={(e) => set("maxMass", e.target.value)}
          className="w-20 bg-slate-800/70 border border-slate-700/60 rounded-lg px-2 py-2 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500/70 focus:ring-1 focus:ring-indigo-500/30 transition"
        />
        <span className="text-xs text-slate-500">M⊕</span>
      </div>

      {/* Reset */}
      <button
        onClick={() => onChange({ search: "", method: "", minMass: "", maxMass: "" })}
        className="text-xs text-slate-400 hover:text-slate-200 transition px-2 py-2 rounded-lg hover:bg-slate-700/40"
      >
        ✕ Reset
      </button>

      {/* Refresh */}
      <button
        onClick={onRefresh}
        disabled={isLoading}
        className="ml-auto flex items-center gap-1.5 bg-indigo-600/80 hover:bg-indigo-600 disabled:opacity-40 text-white text-xs font-semibold px-3 py-2 rounded-lg transition-all"
      >
        <span className={isLoading ? "animate-spin inline-block" : ""}>🔄</span>
        {isLoading ? "Loading…" : "Refresh"}
      </button>
    </div>
  );
}
