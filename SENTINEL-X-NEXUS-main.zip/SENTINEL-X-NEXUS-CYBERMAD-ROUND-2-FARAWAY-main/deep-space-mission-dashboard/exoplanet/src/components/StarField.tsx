import { useMemo } from "react";

interface Star {
  id: number;
  x: number;
  y: number;
  size: number;
  dur: number;
  delay: number;
  opacity: number;
}

export default function StarField() {
  const stars = useMemo<Star[]>(() => {
    return Array.from({ length: 180 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2.5 + 0.5,
      dur: Math.random() * 4 + 2,
      delay: Math.random() * 5,
      opacity: Math.random() * 0.6 + 0.2,
    }));
  }, []);

  const nebulae = useMemo(() => {
    return [
      { x: 15, y: 20, w: 300, h: 200, color: "rgba(99,102,241,0.04)" },
      { x: 70, y: 60, w: 350, h: 250, color: "rgba(168,85,247,0.03)" },
      { x: 40, y: 80, w: 280, h: 180, color: "rgba(6,182,212,0.03)" },
      { x: 80, y: 10, w: 260, h: 200, color: "rgba(99,102,241,0.03)" },
    ];
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {/* Deep space gradient */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_#0f172a_0%,_#020617_60%,_#000000_100%)]" />

      {/* Nebula clouds */}
      {nebulae.map((n, i) => (
        <div
          key={i}
          className="absolute rounded-full blur-3xl"
          style={{
            left: `${n.x}%`,
            top: `${n.y}%`,
            width: n.w,
            height: n.h,
            background: n.color,
            transform: "translate(-50%, -50%)",
          }}
        />
      ))}

      {/* Stars */}
      <svg className="absolute inset-0 w-full h-full">
        {stars.map((s) => (
          <circle
            key={s.id}
            cx={`${s.x}%`}
            cy={`${s.y}%`}
            r={s.size}
            fill="white"
            opacity={s.opacity}
            className="star"
            style={
              {
                "--dur": `${s.dur}s`,
                animationDelay: `${s.delay}s`,
              } as React.CSSProperties
            }
          />
        ))}
      </svg>

      {/* Milky way band */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          background:
            "linear-gradient(105deg, transparent 20%, rgba(148,163,184,0.08) 40%, rgba(99,102,241,0.06) 50%, rgba(148,163,184,0.08) 60%, transparent 80%)",
        }}
      />
    </div>
  );
}
