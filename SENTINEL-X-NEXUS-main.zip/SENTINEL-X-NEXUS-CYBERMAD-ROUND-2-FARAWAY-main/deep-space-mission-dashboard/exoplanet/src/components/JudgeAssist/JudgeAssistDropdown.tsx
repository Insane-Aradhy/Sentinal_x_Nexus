'use client';

import React, { useState, useRef, useEffect } from 'react';
import { TOUR_PACKAGES, SPECIFIC_DIVISIONS, TourStep } from './tourSteps';
import JudgeGuider from './JudgeGuider';

export default function JudgeAssistDropdown() {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTourSteps, setActiveTourSteps] = useState<TourStep[] | null>(null);
  const [isTourActive, setIsTourActive] = useState(false);
  const [selectedDivisionId, setSelectedDivisionId] = useState(SPECIFIC_DIVISIONS[0].id);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const startTour = (steps: TourStep[]) => {
    setActiveTourSteps(steps);
    setIsTourActive(true);
    setIsOpen(false);
  };

  const handleStartDivision = () => {
    const division = SPECIFIC_DIVISIONS.find(d => d.id === selectedDivisionId);
    if (division) {
      startTour([division.step]);
    }
  };

  return (
    <>
      {/* Top-Center Header Trigger Bar */}
      <div 
        ref={dropdownRef} 
        className="fixed top-4 left-1/2 -translate-x-1/2 z-50 pointer-events-auto flex flex-col items-center select-none"
      >
        {/* Main Glowing Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="group relative flex items-center gap-2 px-5 py-2 rounded-full bg-gradient-to-r from-pink-500 via-purple-600 to-pink-500 bg-[length:200%_auto] hover:bg-right transition-all duration-300 font-extrabold text-xs tracking-wider uppercase text-white shadow-[0_0_20px_rgba(236,72,153,0.6)] hover:shadow-[0_0_28px_rgba(236,72,153,0.9)] hover:scale-105 active:scale-95 border border-pink-300/40 cursor-pointer"
        >
          <span className="text-amber-300 text-sm animate-pulse">★</span>
          <span>ASSIST JUDGES</span>
          <span className="text-[10px] text-pink-200 transition-transform duration-200">
            {isOpen ? '▲' : '▼'}
          </span>
        </button>

        {/* Dropdown Menu Modal */}
        {isOpen && (
          <div className="mt-2.5 w-[360px] bg-black/90 backdrop-blur-2xl border border-pink-500/40 rounded-2xl p-4 shadow-[0_10px_40px_rgba(0,0,0,0.8),0_0_25px_rgba(236,72,153,0.3)] animate-in fade-in slide-in-from-top-2 duration-200">
            {/* Top Monospace Tag */}
            <div className="text-center pb-3 border-b border-pink-500/20">
              <span className="text-[9px] font-mono font-bold tracking-widest text-amber-300/90 uppercase">
                MADE DURING 24 HRS FARAWAY 2ND ROUND
              </span>
            </div>

            {/* Quick Tour Options */}
            <div className="py-2.5 space-y-2">
              <button
                onClick={() => startTour(TOUR_PACKAGES.preferences.steps)}
                className="w-full flex items-center gap-3 p-2.5 rounded-xl bg-slate-900/60 hover:bg-pink-950/40 border border-white/5 hover:border-pink-500/40 transition-all text-left group cursor-pointer"
              >
                <span className="text-base p-1 rounded-lg bg-white/5 border border-white/10 group-hover:border-pink-400/40">
                  {TOUR_PACKAGES.preferences.icon}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold text-slate-200 group-hover:text-pink-300 truncate">
                    {TOUR_PACKAGES.preferences.name}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate">
                    Planetary 3D Viewport & HUD
                  </div>
                </div>
              </button>

              <button
                onClick={() => startTour(TOUR_PACKAGES.neo.steps)}
                className="w-full flex items-center gap-3 p-2.5 rounded-xl bg-slate-900/60 hover:bg-pink-950/40 border border-white/5 hover:border-pink-500/40 transition-all text-left group cursor-pointer"
              >
                <span className="text-base p-1 rounded-lg bg-white/5 border border-white/10 group-hover:border-pink-400/40">
                  {TOUR_PACKAGES.neo.icon}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold text-slate-200 group-hover:text-pink-300 truncate">
                    {TOUR_PACKAGES.neo.name}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate">
                    Live NASA Asteroid Radar & Hazard Logic
                  </div>
                </div>
              </button>
            </div>

            {/* Core Platform Header */}
            <div className="pt-2 pb-1.5">
              <span className="text-[8.5px] font-black tracking-widest text-pink-400 uppercase font-mono">
                EVERY FEATURE BUILT UNDER 24 HRS HACKATHON ROUND 2
              </span>
            </div>

            {/* Full Explanation Featured Card */}
            <button
              onClick={() => startTour(TOUR_PACKAGES.full.steps)}
              className="w-full p-3 rounded-xl bg-gradient-to-r from-pink-950/60 to-purple-950/60 hover:from-pink-900/80 hover:to-purple-900/80 border border-pink-500/50 hover:border-pink-400 shadow-[0_0_15px_rgba(236,72,153,0.2)] transition-all text-left group cursor-pointer"
            >
              <div className="flex items-center gap-2 mb-1">
                <span className="text-base">🚀</span>
                <span className="text-xs font-extrabold text-white group-hover:text-pink-200">
                  Full Walkthrough (Complete Explanation)
                </span>
              </div>
              <p className="text-[9.5px] text-pink-200/80 leading-snug">
                Complete walk-through of all deep space dashboard capabilities and NASA feeds
              </p>
            </button>

            {/* Specific Division Selector */}
            <div className="mt-3 pt-3 border-t border-pink-500/20">
              <label className="block text-[8.5px] font-black tracking-widest text-slate-400 uppercase font-mono mb-2">
                OR EXPLAIN SPECIFIC DIVISION:
              </label>
              <div className="flex items-center gap-2">
                <select
                  value={selectedDivisionId}
                  onChange={(e) => setSelectedDivisionId(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-700 hover:border-pink-400/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-pink-400 cursor-pointer font-sans"
                >
                  {SPECIFIC_DIVISIONS.map((div) => (
                    <option key={div.id} value={div.id} className="bg-slate-900 text-white">
                      {div.label}
                    </option>
                  ))}
                </select>
                <button
                  onClick={handleStartDivision}
                  className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 text-white font-bold text-xs shadow-md hover:shadow-pink-500/30 transition-all uppercase cursor-pointer"
                >
                  Explain
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Active Draggable Guider Modal */}
      {activeTourSteps && (
        <JudgeGuider
          steps={activeTourSteps}
          isOpen={isTourActive}
          onClose={() => {
            setIsTourActive(false);
            setActiveTourSteps(null);
          }}
        />
      )}
    </>
  );
}
