export interface TourStep {
  title: string;
  desc: string;
  targetId: string | null;
  requireClickId?: string;
  actionHint?: string;
  arrow: 'up' | 'down' | 'left' | 'right' | 'none';
  position: {
    top?: string;
    bottom?: string;
    left?: string;
    right?: string;
  };
}

export const TOUR_PACKAGES: Record<string, { name: string; icon: string; steps: TourStep[] }> = {
  preferences: {
    name: 'CATALOG & CHARTS',
    icon: '📊',
    steps: [
      {
        title: "NASA Data Telemetry",
        desc: "We pull a live TAP query directly from the NASA Exoplanet Archive.\\n\\nIf the iframe CORS blocks it, we immediately fallback to a local mock dataset so the dashboard never breaks.",
        targetId: null,
        arrow: "none",
        position: { top: '30%', left: '50%' }
      },
      {
        title: "Interactive Charts",
        desc: "Switch between the Catalog Table and the beautiful Recharts data visualizations.\\n\\nThe charts map Exoplanet Masses and Radii dynamically based on your search filters.",
        targetId: null,
        arrow: "none",
        position: { top: '40%', left: '50%' }
      }
    ]
  },
  neo: {
    name: 'HABITABILITY METRICS',
    icon: '🪐',
    steps: [
      {
        title: "Planet Detail Panel",
        desc: "Select any planet from the catalog to view its detailed habitability metrics.\\n\\nIt calculates Earth masses, Earth radii, and orbital parameters automatically.",
        targetId: null,
        arrow: "none",
        position: { top: '50%', left: '30%' }
      }
    ]
  },
  full: {
    name: 'Full Walkthrough (Complete Explanation)',
    icon: '🚀',
    steps: [
      {
        title: "Exoplanet Dashboard Live Feed",
        desc: "Welcome to the Exoplanet Dashboard!\\n\\nThis system tracks confirmed planets orbiting stars beyond our solar system.",
        targetId: null,
        arrow: "none",
        position: { top: '30%', left: '50%' }
      },
      {
        title: "Real-time Filtering Engine",
        desc: "The filter bar isn't just for show.\\n\\nSearch for 'Kepler' or filter by 'Transit' discovery methods, and the entire catalog and charts instantly re-render without network latency.",
        targetId: null,
        arrow: "none",
        position: { top: '30%', left: '50%' }
      },
      {
        title: "Responsive Data Viz",
        desc: "Our architecture prioritizes responsive UI.\\n\\nWhether you are looking at the planetary table or the mass distribution charts, everything adapts beautifully to the screen.",
        targetId: null,
        arrow: "none",
        position: { top: '30%', left: '50%' }
      }
    ]
  }
};

export const SPECIFIC_DIVISIONS = [
  { id: 'hud', label: 'Filter Bar', step: TOUR_PACKAGES.full.steps[1] },
  { id: 'sys', label: 'Charts Engine', step: TOUR_PACKAGES.preferences.steps[1] }
];
