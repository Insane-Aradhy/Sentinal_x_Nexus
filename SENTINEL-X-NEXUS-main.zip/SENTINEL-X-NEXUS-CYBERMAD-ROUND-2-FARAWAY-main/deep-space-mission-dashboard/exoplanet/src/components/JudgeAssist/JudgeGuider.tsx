'use client';

import React, { useEffect, useState, useRef } from 'react';
import { TourStep } from './tourSteps';

interface JudgeGuiderProps {
  steps: TourStep[];
  isOpen: boolean;
  onClose: () => void;
}

export default function JudgeGuider({ steps, isOpen, onClose }: JudgeGuiderProps) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isWaitingForInput, setIsWaitingForInput] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  
  // Dragging state
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef({ x: 0, y: 0 });
  const guiderRef = useRef<HTMLDivElement>(null);
  const currentHighlightedTargetRef = useRef<string | null>(null);

  const step = steps[currentStepIndex];

  // Reset when a new tour is opened
  useEffect(() => {
    if (isOpen) {
      setCurrentStepIndex(0);
      setDragOffset({ x: 0, y: 0 });
      setIsCollapsed(false);
    } else {
      // Clean up any remaining blink classes
      if (currentHighlightedTargetRef.current) {
        const el = document.getElementById(currentHighlightedTargetRef.current);
        if (el) el.classList.remove('tour-blink');
        currentHighlightedTargetRef.current = null;
      }
    }
  }, [isOpen]);

  // Handle step setup (highlights, scroll, mandatory clicks)
  useEffect(() => {
    if (!isOpen || !step) return;

    // Clean up previous highlight
    if (currentHighlightedTargetRef.current) {
      const prevEl = document.getElementById(currentHighlightedTargetRef.current);
      if (prevEl) prevEl.classList.remove('tour-blink');
      currentHighlightedTargetRef.current = null;
    }

    // Scroll & highlight current target
    if (step.targetId) {
      const target = document.getElementById(step.targetId);
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'center' });
        target.classList.add('tour-blink');
        currentHighlightedTargetRef.current = step.targetId;
      }
    }

    // Mandatory interaction gating
    if (step.requireClickId) {
      setIsWaitingForInput(true);
      const reqEl = document.getElementById(step.requireClickId);
      if (reqEl) {
        reqEl.classList.add('tour-blink');
        const handleInteraction = () => {
          setIsWaitingForInput(false);
          reqEl.classList.remove('tour-blink');
        };

        reqEl.addEventListener('click', handleInteraction, { once: true });
        reqEl.addEventListener('change', handleInteraction, { once: true });

        return () => {
          reqEl.removeEventListener('click', handleInteraction);
          reqEl.removeEventListener('change', handleInteraction);
        };
      }
    } else {
      setIsWaitingForInput(false);
    }
  }, [currentStepIndex, isOpen, step]);

  if (!isOpen || !step) return null;

  const handleNext = () => {
    if (currentStepIndex < steps.length - 1) {
      setCurrentStepIndex(prev => prev + 1);
      setIsCollapsed(false);
    } else {
      onClose();
    }
  };

  const dragHandleRef = useRef<HTMLDivElement>(null);

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if ((e.target as HTMLElement).tagName === 'BUTTON' || (e.target as HTMLElement).tagName === 'SELECT') {
      return;
    }
    setIsDragging(true);
    if (dragHandleRef.current) {
      dragHandleRef.current.setPointerCapture(e.pointerId);
    }
    dragStartRef.current = {
      x: e.clientX - dragOffset.x,
      y: e.clientY - dragOffset.y
    };
    e.preventDefault();
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    setDragOffset({
      x: e.clientX - dragStartRef.current.x,
      y: e.clientY - dragStartRef.current.y
    });
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    setIsDragging(false);
    if (dragHandleRef.current && dragHandleRef.current.hasPointerCapture(e.pointerId)) {
      dragHandleRef.current.releasePointerCapture(e.pointerId);
    }
  };

  const arrowIcons = {
    up: '↑',
    down: '↓',
    left: '←',
    right: '→',
    none: ''
  };

  const isLast = currentStepIndex === steps.length - 1;

  return (
    <div
      ref={guiderRef}
      className={`fixed z-[10000] flex flex-col items-center select-none pointer-events-auto`}
      style={{
        top: step.position.top || 'auto',
        bottom: step.position.bottom || 'auto',
        left: step.position.left || '50%',
        right: step.position.right || 'auto',
        transform: (!step.position.left || step.position.left === '50%')
          ? `translate(calc(-50% + ${dragOffset.x}px), ${dragOffset.y}px)`
          : `translate(${dragOffset.x}px, ${dragOffset.y}px)`,
        touchAction: 'none'
      }}
    >
      <div className={!isDragging && !isCollapsed ? 'tour-bouncing' : ''}>
        {/* Top Arrow if pointing up (hide if collapsed) */}
        {step.arrow === 'up' && !isCollapsed && (
          <div className="text-yellow-400 text-3xl font-black mb-1 animate-pulse drop-shadow-[0_0_12px_rgba(234,179,8,0.8)] text-center">
            {arrowIcons.up}
          </div>
        )}

        {/* Main Glassmorphism Card */}
        <div className={`bg-gradient-to-br from-yellow-600/95 via-amber-700/95 to-slate-900/95 text-white rounded-2xl shadow-[0_0_35px_rgba(234,179,8,0.45)] border border-yellow-400/40 backdrop-blur-xl transition-all overflow-hidden ${isCollapsed ? 'w-[240px]' : 'w-[340px]'}`}>
          
          {/* Drag Handle & Top Controls (Always Visible) */}
          <div 
            ref={dragHandleRef}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            className="flex items-center justify-between px-3 py-2 bg-yellow-950/40 border-b border-yellow-400/30 cursor-grab active:cursor-grabbing"
            title="Drag to move"
          >
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-yellow-300 uppercase tracking-widest flex items-center gap-1">
                <span className="opacity-50">⣿</span> DRAG TO MOVE
              </span>
            </div>
            <div className="flex gap-2">
              <button
                onClick={(e) => { e.stopPropagation(); setIsCollapsed(!isCollapsed); }}
                className="text-yellow-200 hover:text-white bg-white/10 hover:bg-white/20 p-1 rounded-sm text-[10px] font-mono leading-none transition-colors w-5 h-5 flex items-center justify-center"
                title={isCollapsed ? "Expand" : "Collapse"}
              >
                {isCollapsed ? '+' : '−'}
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); onClose(); }}
                className="text-yellow-200 hover:text-white bg-white/10 hover:bg-white/20 p-1 rounded-sm text-[10px] font-mono leading-none transition-colors w-5 h-5 flex items-center justify-center"
                title="Close tour"
              >
                ✕
              </button>
            </div>
          </div>

          {/* Collapsed State Title View */}
          {isCollapsed && (
            <div className="p-3">
              <h3 className="font-black text-xs tracking-wide text-white mb-2 flex items-start gap-2 line-clamp-1" title={step.title}>
                <span className="text-amber-400">★</span> {step.title}
              </h3>
              <div className="flex justify-between items-center mt-2">
                 <button
                  onClick={() => setIsCollapsed(false)}
                  className="px-2 py-1 bg-yellow-500/20 hover:bg-yellow-500/40 border border-yellow-400/50 rounded text-[10px] font-bold text-yellow-100 uppercase tracking-wider transition-colors w-full"
                >
                  EXPAND TO READ MORE
                </button>
              </div>
            </div>
          )}

          {/* Full Expanded View */}
          {!isCollapsed && (
            <div className="p-5 pt-4">
              {/* Badge */}
              <div className="flex items-center mb-3">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-yellow-950/60 border border-yellow-400/30 text-[9px] font-mono tracking-widest text-amber-300 font-bold uppercase shadow-sm">
                  <span>✓</span> BUILT UNDER 24 HRS HACKATHON ROUND 2
                </div>
              </div>

              {/* Title */}
              <h3 className="font-black text-sm tracking-wide text-white mb-2 flex items-center gap-2">
                <span className="text-amber-400">★</span> {step.title}
              </h3>

              {/* Description */}
              <div className="max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                <p className="text-xs leading-relaxed text-yellow-100/90 mb-4 font-normal whitespace-pre-wrap">
                  {step.desc}
                </p>
              </div>

              {/* Action hint if input is required */}
              {isWaitingForInput && step.actionHint && (
                <div className="mb-3.5 px-3 py-1.5 rounded-lg bg-amber-500/20 border border-amber-400/50 flex items-center gap-2 text-[10px] text-amber-300 font-bold animate-pulse">
                  <span>👉</span> {step.actionHint}
                </div>
              )}

              {/* Controls Footer */}
              <div className="flex justify-between items-center pt-3 border-t border-yellow-400/20">
                <button
                  onClick={onClose}
                  className="px-3 py-1.5 rounded-lg border border-yellow-300/40 hover:bg-yellow-500/20 text-yellow-200 text-xs font-bold transition-colors uppercase tracking-wider"
                >
                  Skip
                </button>

                <button
                  onClick={handleNext}
                  disabled={isWaitingForInput}
                  className={`px-4 py-1.5 rounded-lg font-black text-xs uppercase tracking-wider shadow-lg transition-all ${
                    isWaitingForInput
                      ? 'opacity-40 cursor-not-allowed bg-yellow-300/30 text-white'
                      : 'bg-white text-yellow-700 hover:bg-yellow-50 hover:scale-105 active:scale-95 shadow-[0_0_15px_rgba(255,255,255,0.4)]'
                  }`}
                >
                  {isWaitingForInput ? 'WAITING FOR INPUT...' : isLast ? 'FINISH' : 'NEXT'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Arrow if pointing down (hide if collapsed) */}
        {step.arrow === 'down' && !isCollapsed && (
          <div className="text-yellow-400 text-3xl font-black mt-1 animate-pulse drop-shadow-[0_0_12px_rgba(234,179,8,0.8)] text-center">
            {arrowIcons.down}
          </div>
        )}

        {/* Side Arrow Indicator (hide if collapsed) */}
        {step.arrow === 'left' && !isCollapsed && (
          <div className="absolute -left-7 top-1/2 -translate-y-1/2 text-yellow-400 text-3xl font-black animate-pulse drop-shadow-[0_0_12px_rgba(234,179,8,0.8)]">
            {arrowIcons.left}
          </div>
        )}

        {step.arrow === 'right' && !isCollapsed && (
          <div className="absolute -right-7 top-1/2 -translate-y-1/2 text-yellow-400 text-3xl font-black animate-pulse drop-shadow-[0_0_12px_rgba(234,179,8,0.8)]">
            {arrowIcons.right}
          </div>
        )}
      </div>
    </div>
  );
}
