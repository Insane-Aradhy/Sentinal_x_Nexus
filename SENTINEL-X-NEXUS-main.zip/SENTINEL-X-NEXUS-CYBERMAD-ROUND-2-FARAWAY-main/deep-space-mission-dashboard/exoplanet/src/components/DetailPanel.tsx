import type { Exoplanet } from "../types";

interface Props {
  planet: Exoplanet | null;
}

const PALETTES = [
  { from: "#3b82f6", to: "#6366f1", ring: "rgba(99,102,241,0.4)" },
  { from: "#6366f1", to: "#a855f7", ring: "rgba(168,85,247,0.4)" },
  { from: "#06b6d4", to: "#3b82f6", ring: "rgba(6,182,212,0.4)" },
  { from: "#a855f7", to: "#ec4899", ring: "rgba(168,85,247,0.4)" },
  { from: "#14b8a6", to: "#06b6d4", ring: "rgba(20,184,166,0.4)" },
  { from: "#10b981", to: "#14b8a6", ring: "rgba(16,185,129,0.4)" },
];

function getPalette(name: string) {
  return PALETTES[name.charCodeAt(0) % PALETTES.length];
}

function classify(mass: number | null, radius: number | null): { label: string; desc: string; emoji: string } {
  if (mass == null && radius == null) return { label: "Unknown", desc: "Insufficient data", emoji: "❓" };
  const m = mass ?? 0;
  const r = radius ?? 0;
  if (m < 2 && r < 1.25) return { label: "Earth-like", desc: "Rocky, terrestrial world", emoji: "🌍" };
  if (m < 10 && r < 2.5) return { label: "Super-Earth", desc: "Larger rocky or ocean world", emoji: "🌊" };
  if (m < 50 && r < 4) return { label: "Sub-Neptune", desc: "Gas-rich mini-Neptune", emoji: "🌫️" };
  if (m < 150) return { label: "Neptune-like", desc: "Ice giant class", emoji: "🔵" };
  return { label: "Gas Giant", desc: "Jupiter-class behemoth", emoji: "🪐" };
}

function Gauge({ value, max, label, color }: { value: number | null; max: number; label: string; color: string }) {
  const pct = value != null ? Math.min((value / max) * 100, 100) : 0;
  return (
    <div className="space-y-1.5">
      <div className="flex justify-between items-center">
        <span className="text-xs text-slate-400">{label}</span>
        <span className="text-xs font-mono font-semibold" style={{ color }}>
          {value != null ? value.toFixed(2) : "N/A"}
        </span>
      </div>
      <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-700 ease-out"
          style={{
            width: `${pct}%`,
            background: `linear-gradient(90deg, ${color}80, ${color})`,
          }}
        />
      </div>
    </div>
  );
}

export default function DetailPanel({ planet }: Props) {
  if (!planet) {
    return (
      <div className="glass-card rounded-2xl flex flex-col items-center justify-center text-center p-8 h-full min-h-[300px]">
        <div className="text-5xl mb-3 float-anim">🔭</div>
        <p className="text-slate-400 text-sm font-medium">Select a planet</p>
        <p className="text-slate-600 text-xs mt-1">Click any row to explore details</p>
      </div>
    );
  }

  const palette = getPalette(planet.pl_name);
  const type = classify(planet.pl_masse, planet.pl_rade);

  return (
    <div className="glass-card rounded-2xl overflow-hidden flex flex-col h-full fade-in-up">
      {/* Hero */}
      <div
        className="relative p-6 flex flex-col items-center gap-3"
        style={{
          background: `linear-gradient(135deg, ${palette.from}18, ${palette.to}25)`,
          borderBottom: `1px solid ${palette.ring}`,
        }}
      >
        {/* Orbit rings */}
        <div className="relative flex items-center justify-center" style={{ width: 80, height: 80 }}>
          <div
            className="orbit-ring absolute"
            style={{ width: 76, height: 76, borderColor: `${palette.from}30` }}
          />
          <div
            className="orbit-ring absolute"
            style={{ width: 60, height: 60, borderColor: `${palette.from}20` }}
          />
          {/* Planet sphere */}
          <div
            className="w-12 h-12 rounded-full relative float-anim"
            style={{
              background: `radial-gradient(circle at 35% 35%, ${palette.from}, ${palette.to})`,
              boxShadow: `0 0 24px ${palette.ring}, 0 0 48px ${palette.ring}50`,
            }}
          >
            {/* Highlight */}
            <div
              className="absolute top-2 left-2 w-3 h-3 rounded-full opacity-60"
              style={{ background: "rgba(255,255,255,0.4)" }}
            />
          </div>
          {/* Orbiting moon */}
          <div
            className="absolute w-2 h-2 rounded-full"
            style={{
              background: palette.from,
              boxShadow: `0 0 8px ${palette.ring}`,
              animation: "orbit 4s linear infinite",
            }}
          />
        </div>

        <div className="text-center">
          <h3 className="text-slate-100 font-bold text-lg leading-tight">{planet.pl_name}</h3>
          <p className="text-slate-400 text-xs mt-0.5">{planet.hostname}</p>
        </div>

        {/* Type badge */}
        <div
          className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold"
          style={{
            background: `${palette.from}20`,
            border: `1px solid ${palette.from}40`,
            color: palette.from,
          }}
        >
          <span>{type.emoji}</span>
          <span>{type.label}</span>
        </div>
      </div>

      {/* Data rows */}
      <div className="p-5 flex-1 space-y-4">
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: "Discovery Year", value: planet.disc_year ?? "—", icon: "📅" },
            { label: "Method", value: planet.discoverymethod || "—", icon: "🔬" },
          ].map((item) => (
            <div key={item.label} className="bg-slate-800/40 rounded-xl p-3 text-center">
              <p className="text-xs text-slate-500 mb-1">{item.icon} {item.label}</p>
              <p className="text-sm font-semibold text-slate-200 truncate">{item.value}</p>
            </div>
          ))}
        </div>

        {/* Gauges */}
        <div className="space-y-3">
          <p className="text-xs text-slate-500 uppercase tracking-wider font-semibold">Physical Properties</p>
          <Gauge
            value={planet.pl_masse}
            max={Math.max(300, (planet.pl_masse ?? 0) * 1.5)}
            label="Mass (Earth masses)"
            color="#22d3ee"
          />
          <Gauge
            value={planet.pl_rade}
            max={Math.max(15, (planet.pl_rade ?? 0) * 1.5)}
            label="Radius (Earth radii)"
            color="#a78bfa"
          />
        </div>

        {/* Classification */}
        <div
          className="rounded-xl p-3 text-xs"
          style={{
            background: `${palette.from}10`,
            border: `1px solid ${palette.from}20`,
          }}
        >
          <p className="text-slate-400 font-medium mb-0.5">Classification</p>
          <p className="text-slate-300">{type.desc}</p>
        </div>
      </div>
    </div>
  );
}
