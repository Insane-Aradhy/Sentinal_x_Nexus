import { useState } from "react";
import type { Exoplanet, SortKey, SortDir } from "../types";

interface Props {
  planets: Exoplanet[];
  selected: Exoplanet | null;
  onSelect: (p: Exoplanet) => void;
}

const METHOD_BADGES: Record<string, string> = {
  Transit: "badge-transit",
  "Radial Velocity": "badge-rv",
  "Direct Imaging": "badge-imaging",
  Imaging: "badge-imaging",
};

function getMethodBadge(method: string) {
  return METHOD_BADGES[method] ?? "badge-other";
}

function SortIcon({ active, dir }: { active: boolean; dir: SortDir }) {
  return (
    <span className={`ml-1 inline-block transition-transform ${active ? "opacity-100" : "opacity-30"}`}>
      {active && dir === "desc" ? "↓" : "↑"}
    </span>
  );
}

function PlanetOrb({ name, mass }: { name: string; mass: number | null }) {
  const palettes = [
    { bg: "from-blue-500 to-indigo-600", glow: "planet-glow-blue" },
    { bg: "from-indigo-500 to-purple-600", glow: "planet-glow-indigo" },
    { bg: "from-cyan-500 to-blue-600", glow: "planet-glow-cyan" },
    { bg: "from-purple-500 to-pink-600", glow: "planet-glow-purple" },
    { bg: "from-teal-500 to-cyan-600", glow: "planet-glow-teal" },
    { bg: "from-emerald-500 to-teal-600", glow: "planet-glow-emerald" },
  ];
  const idx = name.charCodeAt(0) % palettes.length;
  const { bg, glow } = palettes[idx];

  // Size relative to mass (clamped)
  const m = mass ?? 1;
  const size = Math.max(20, Math.min(36, 20 + Math.log10(m + 1) * 10));

  return (
    <div
      className={`rounded-full bg-gradient-to-br ${bg} ${glow} flex-shrink-0`}
      style={{ width: size, height: size }}
    />
  );
}

export default function PlanetTable({ planets, selected, onSelect }: Props) {
  const [sortKey, setSortKey] = useState<SortKey>("disc_year");
  const [sortDir, setSortDir] = useState<SortDir>("desc");

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("desc");
    }
  };

  const sorted = [...planets].sort((a, b) => {
    const av = a[sortKey];
    const bv = b[sortKey];
    if (av == null) return 1;
    if (bv == null) return -1;
    if (typeof av === "string" && typeof bv === "string") {
      return sortDir === "asc" ? av.localeCompare(bv) : bv.localeCompare(av);
    }
    return sortDir === "asc" ? (av as number) - (bv as number) : (bv as number) - (av as number);
  });

  const cols: { key: SortKey; label: string; align?: string }[] = [
    { key: "pl_name", label: "Planet" },
    { key: "hostname", label: "Host Star" },
    { key: "discoverymethod", label: "Method" },
    { key: "disc_year", label: "Year", align: "text-right" },
    { key: "pl_masse", label: "Mass (M⊕)", align: "text-right" },
    { key: "pl_rade", label: "Radius (R⊕)", align: "text-right" },
  ];

  return (
    <div className="glass-card rounded-2xl overflow-hidden">
      <div className="px-5 py-4 border-b border-slate-700/50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-indigo-400 text-lg">📋</span>
          <h2 className="text-slate-100 font-semibold text-sm tracking-wide uppercase">
            Exoplanet Catalog
          </h2>
        </div>
        <span className="text-xs text-slate-500 bg-slate-800/60 px-2 py-1 rounded-full">
          {planets.length} entries
        </span>
      </div>

      <div className="overflow-x-auto scrollbar-custom" style={{ maxHeight: "380px", overflowY: "auto" }}>
        <table className="w-full text-sm">
          <thead className="sticky top-0 z-10">
            <tr className="bg-slate-900/90 border-b border-slate-700/50">
              {cols.map((col) => (
                <th
                  key={col.key}
                  onClick={() => handleSort(col.key)}
                  className={`px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wider cursor-pointer hover:text-indigo-300 transition-colors select-none whitespace-nowrap ${col.align ?? ""}`}
                >
                  {col.label}
                  <SortIcon active={sortKey === col.key} dir={sortDir} />
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sorted.map((planet, i) => {
              const isSelected = selected?.pl_name === planet.pl_name;
              return (
                <tr
                  key={`${planet.pl_name}-${i}`}
                  onClick={() => onSelect(planet)}
                  className={`border-b border-slate-800/60 cursor-pointer transition-all hover:bg-indigo-900/20 ${
                    isSelected ? "selected-row" : ""
                  }`}
                  style={{ animationDelay: `${i * 0.04}s` }}
                >
                  {/* Planet name + orb */}
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <PlanetOrb name={planet.pl_name} mass={planet.pl_masse} />
                      <span className="font-medium text-slate-100 whitespace-nowrap">
                        {planet.pl_name}
                      </span>
                    </div>
                  </td>
                  {/* Host */}
                  <td className="px-4 py-3 text-slate-300 whitespace-nowrap">
                    {planet.hostname || "—"}
                  </td>
                  {/* Method badge */}
                  <td className="px-4 py-3">
                    <span
                      className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium whitespace-nowrap ${getMethodBadge(planet.discoverymethod)}`}
                    >
                      {planet.discoverymethod || "Unknown"}
                    </span>
                  </td>
                  {/* Year */}
                  <td className="px-4 py-3 text-right text-slate-300 font-mono">
                    {planet.disc_year ?? "—"}
                  </td>
                  {/* Mass */}
                  <td className="px-4 py-3 text-right font-mono text-cyan-300">
                    {planet.pl_masse != null ? planet.pl_masse.toFixed(2) : "—"}
                  </td>
                  {/* Radius */}
                  <td className="px-4 py-3 text-right font-mono text-purple-300">
                    {planet.pl_rade != null ? planet.pl_rade.toFixed(2) : "—"}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
