export default function LoadingSkeleton() {
  return (
    <div className="space-y-4 animate-pulse">
      {/* Stat cards skeleton */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="glass rounded-xl p-4 h-24 shimmer-bg" />
        ))}
      </div>

      {/* Charts row skeleton */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="glass rounded-2xl h-64 shimmer-bg" />
        ))}
      </div>

      {/* Table + detail skeleton */}
      <div className="grid grid-cols-1 xl:grid-cols-[1fr_300px] gap-4">
        <div className="glass rounded-2xl h-80 shimmer-bg" />
        <div className="glass rounded-2xl h-80 shimmer-bg" />
      </div>
    </div>
  );
}
