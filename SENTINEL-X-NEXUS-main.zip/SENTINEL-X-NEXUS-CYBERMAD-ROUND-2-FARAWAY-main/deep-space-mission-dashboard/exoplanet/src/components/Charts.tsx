import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
  PieChart,
  Pie,
  Legend,
  LabelList,
} from "recharts";
import type { Exoplanet } from "../types";

interface Props {
  planets: Exoplanet[];
}

const COLORS = ["#6366f1", "#22d3ee", "#a78bfa", "#34d399", "#fb923c", "#f472b6", "#facc15"];

const CustomTooltipStyle = {
  contentStyle: {
    background: "rgba(2,6,23,0.95)",
    border: "1px solid rgba(99,102,241,0.4)",
    borderRadius: "10px",
    color: "#e2e8f0",
    fontSize: "12px",
    padding: "10px 14px",
  },
  labelStyle: { color: "#94a3b8" },
  itemStyle: { color: "#a5b4fc" },
};

// ─── Mass vs Radius Scatter ───────────────────────────────────────────────────
function ScatterPlot({ planets }: Props) {
  const data = planets
    .filter((p) => p.pl_masse != null && p.pl_rade != null)
    .map((p) => ({
      x: p.pl_masse!,
      y: p.pl_rade!,
      name: p.pl_name,
    }));

  return (
    <div className="glass-card rounded-2xl p-5 flex flex-col gap-3">
      <div className="flex items-center gap-2">
        <span className="text-base">📊</span>
        <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wide">
          Mass vs Radius
        </h3>
        <span className="ml-auto text-xs text-slate-500">Earth units</span>
      </div>
      <ResponsiveContainer width="100%" height={210}>
        <ScatterChart margin={{ top: 4, right: 10, bottom: 10, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(99,102,241,0.1)" />
          <XAxis
            dataKey="x"
            name="Mass"
            type="number"
            tick={{ fill: "#64748b", fontSize: 11 }}
            label={{ value: "Mass (M⊕)", position: "insideBottom", offset: -4, fill: "#475569", fontSize: 11 }}
            tickLine={false}
            axisLine={{ stroke: "rgba(99,102,241,0.2)" }}
          />
          <YAxis
            dataKey="y"
            name="Radius"
            type="number"
            tick={{ fill: "#64748b", fontSize: 11 }}
            label={{ value: "Radius (R⊕)", angle: -90, position: "insideLeft", fill: "#475569", fontSize: 11 }}
            tickLine={false}
            axisLine={{ stroke: "rgba(99,102,241,0.2)" }}
          />
          <Tooltip
            {...CustomTooltipStyle}
            cursor={{ fill: "rgba(99,102,241,0.1)" }}
            content={({ payload }) => {
              if (!payload?.length) return null;
              const d = payload[0]?.payload;
              return (
                <div style={CustomTooltipStyle.contentStyle}>
                  <p className="font-bold text-indigo-300 mb-1">{d.name}</p>
                  <p>Mass: <span className="text-cyan-300">{d.x?.toFixed(2)} M⊕</span></p>
                  <p>Radius: <span className="text-purple-300">{d.y?.toFixed(2)} R⊕</span></p>
                </div>
              );
            }}
          />
          <Scatter
            data={data}
            fill="#6366f1"
            shape={(props: any) => {
              const { cx, cy } = props;
              return (
                <g>
                  <circle cx={cx} cy={cy} r={7} fill="#6366f1" fillOpacity={0.2} />
                  <circle cx={cx} cy={cy} r={4} fill="#818cf8" />
                </g>
              );
            }}
          />
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  );
}

// ─── Discovery Methods Pie ────────────────────────────────────────────────────
function MethodPie({ planets }: Props) {
  const counts: Record<string, number> = {};
  planets.forEach((p) => {
    const m = p.discoverymethod || "Unknown";
    counts[m] = (counts[m] ?? 0) + 1;
  });
  const data = Object.entries(counts).map(([name, value]) => ({ name, value }));

  const renderCustomLabel = ({
    cx, cy, midAngle, outerRadius, value,
  }: any) => {
    const RADIAN = Math.PI / 180;
    const r = outerRadius + 22;
    const x = cx + r * Math.cos(-midAngle * RADIAN);
    const y = cy + r * Math.sin(-midAngle * RADIAN);
    return (
      <text x={x} y={y} textAnchor={x > cx ? "start" : "end"} dominantBaseline="central" fill="#94a3b8" fontSize={10}>
        {value}
      </text>
    );
  };

  return (
    <div className="glass-card rounded-2xl p-5 flex flex-col gap-3">
      <div className="flex items-center gap-2">
        <span className="text-base">🥧</span>
        <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wide">
          Discovery Methods
        </h3>
      </div>
      <ResponsiveContainer width="100%" height={210}>
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            cx="50%"
            cy="50%"
            innerRadius={50}
            outerRadius={75}
            paddingAngle={3}
            labelLine={false}
            label={renderCustomLabel}
          >
            {data.map((_, i) => (
              <Cell key={i} fill={COLORS[i % COLORS.length]} stroke="transparent" />
            ))}
          </Pie>
          <Tooltip
            content={({ payload }) => {
              if (!payload?.length) return null;
              const d = payload[0];
              return (
                <div style={CustomTooltipStyle.contentStyle}>
                  <p className="font-bold" style={{ color: d.payload.fill ?? "#a5b4fc" }}>{d.name}</p>
                  <p className="text-slate-300">{d.value} planet{d.value !== 1 ? "s" : ""}</p>
                </div>
              );
            }}
          />
          <Legend
            iconType="circle"
            iconSize={8}
            formatter={(value) => (
              <span style={{ color: "#94a3b8", fontSize: 11 }}>{value}</span>
            )}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

// ─── Discovery Year Bar ───────────────────────────────────────────────────────
function YearBar({ planets }: Props) {
  const counts: Record<number, number> = {};
  planets.forEach((p) => {
    if (p.disc_year) counts[p.disc_year] = (counts[p.disc_year] ?? 0) + 1;
  });
  const data = Object.entries(counts)
    .map(([year, count]) => ({ year: Number(year), count }))
    .sort((a, b) => a.year - b.year);

  return (
    <div className="glass-card rounded-2xl p-5 flex flex-col gap-3">
      <div className="flex items-center gap-2">
        <span className="text-base">📅</span>
        <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wide">
          Discoveries by Year
        </h3>
      </div>
      <ResponsiveContainer width="100%" height={210}>
        <BarChart data={data} margin={{ top: 4, right: 10, bottom: 10, left: -20 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(99,102,241,0.1)" vertical={false} />
          <XAxis
            dataKey="year"
            tick={{ fill: "#64748b", fontSize: 11 }}
            tickLine={false}
            axisLine={{ stroke: "rgba(99,102,241,0.2)" }}
          />
          <YAxis
            tick={{ fill: "#64748b", fontSize: 11 }}
            tickLine={false}
            axisLine={false}
            allowDecimals={false}
          />
          <Tooltip
            content={({ payload, label }) => {
              if (!payload?.length) return null;
              return (
                <div style={CustomTooltipStyle.contentStyle}>
                  <p className="font-bold text-indigo-300 mb-1">{label}</p>
                  <p className="text-slate-300">{payload[0].value} discovery(s)</p>
                </div>
              );
            }}
          />
          <Bar dataKey="count" radius={[4, 4, 0, 0]}>
            {data.map((_, i) => (
              <Cell key={i} fill={COLORS[i % COLORS.length]} fillOpacity={0.85} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

// ─── Mass Distribution Bar ────────────────────────────────────────────────────
function MassDistribution({ planets }: Props) {
  const bins = [
    { label: "0–1", min: 0, max: 1 },
    { label: "1–5", min: 1, max: 5 },
    { label: "5–20", min: 5, max: 20 },
    { label: "20–100", min: 20, max: 100 },
    { label: "100+", min: 100, max: Infinity },
  ];

  const data = bins.map((bin) => ({
    label: bin.label,
    count: planets.filter(
      (p) => p.pl_masse != null && p.pl_masse > bin.min && p.pl_masse <= bin.max
    ).length,
  }));

  return (
    <div className="glass-card rounded-2xl p-5 flex flex-col gap-3">
      <div className="flex items-center gap-2">
        <span className="text-base">⚖️</span>
        <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wide">
          Mass Distribution
        </h3>
        <span className="ml-auto text-xs text-slate-500">Earth masses</span>
      </div>
      <ResponsiveContainer width="100%" height={210}>
        <BarChart data={data} margin={{ top: 4, right: 10, bottom: 10, left: -20 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(99,102,241,0.1)" vertical={false} />
          <XAxis
            dataKey="label"
            tick={{ fill: "#64748b", fontSize: 11 }}
            tickLine={false}
            axisLine={{ stroke: "rgba(99,102,241,0.2)" }}
            label={{ value: "Mass range (M⊕)", position: "insideBottom", offset: -4, fill: "#475569", fontSize: 10 }}
          />
          <YAxis
            tick={{ fill: "#64748b", fontSize: 11 }}
            tickLine={false}
            axisLine={false}
            allowDecimals={false}
          />
          <Tooltip
            content={({ payload, label }) => {
              if (!payload?.length) return null;
              return (
                <div style={CustomTooltipStyle.contentStyle}>
                  <p className="font-bold text-cyan-300 mb-1">{label} M⊕</p>
                  <p className="text-slate-300">{payload[0].value} planet{payload[0].value !== 1 ? "s" : ""}</p>
                </div>
              );
            }}
          />
          <Bar dataKey="count" radius={[4, 4, 0, 0]} fill="#22d3ee" fillOpacity={0.8}>
            <LabelList dataKey="count" position="top" style={{ fill: "#94a3b8", fontSize: 11 }} />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

// ─── Main export ──────────────────────────────────────────────────────────────
export default function Charts({ planets }: Props) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
      <ScatterPlot planets={planets} />
      <MethodPie planets={planets} />
      <YearBar planets={planets} />
      <MassDistribution planets={planets} />
    </div>
  );
}
