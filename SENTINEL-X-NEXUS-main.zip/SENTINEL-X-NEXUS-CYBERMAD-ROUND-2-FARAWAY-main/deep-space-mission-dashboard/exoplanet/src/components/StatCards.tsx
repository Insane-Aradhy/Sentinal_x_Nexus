import { useMemo } from "react";
import type { Exoplanet } from "../types";

interface Props {
  planets: Exoplanet[];
}

export default function StatCards({ planets }: Props) {
  const stats = useMemo(() => {
    if (!planets.length) return null;

    const validMasses = planets.filter((p) => p.pl_masse != null && p.pl_masse > 0);
    const validRadii = planets.filter((p) => p.pl_rade != null && p.pl_rade > 0);

    const avgMass =
      validMasses.length > 0
        ? validMasses.reduce((s, p) => s + p.pl_masse!, 0) / validMasses.length
        : 0;

    const avgRadius =
      validRadii.length > 0
        ? validRadii.reduce((s, p) => s + p.pl_rade!, 0) / validRadii.length
        : 0;

    const methods = new Set(planets.map((p) => p.discoverymethod).filter(Boolean));
    const years = planets.map((p) => p.disc_year).filter(Boolean);
    const latestYear = years.length ? Math.max(...years) : "—";

    return {
      total: planets.length,
      avgMass: avgMass.toFixed(2),
      avgRadius: avgRadius.toFixed(2),
      methods: methods.size,
      latestYear,
    };
  }, [planets]);

  if (!stats) return null;

  const cards = [
    {
      label: "Planets Loaded",
      value: stats.total,
      unit: "",
      sub: "From NASA Archive",
      color: "#6366f1",
      icon: "🪐",
      glow: "glow-indigo",
    },
    {
      label: "Avg. Mass",
      value: stats.avgMass,
      unit: "M⊕",
      sub: "Earth Masses",
      color: "#22d3ee",
      icon: "⚖️",
      glow: "glow-cyan",
    },
    {
      label: "Avg. Radius",
      value: stats.avgRadius,
      unit: "R⊕",
      sub: "Earth Radii",
      color: "#a78bfa",
      icon: "📏",
      glow: "glow-purple",
    },
    {
      label: "Discovery Methods",
      value: stats.methods,
      unit: "",
      sub: "Unique techniques",
      color: "#34d399",
      icon: "🔭",
      glow: "",
    },
    {
      label: "Most Recent",
      value: stats.latestYear,
      unit: "",
      sub: "Discovery year",
      color: "#fb923c",
      icon: "📅",
      glow: "",
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
      {cards.map((card, i) => (
        <div
          key={card.label}
          className={`glass-card rounded-xl p-4 flex flex-col gap-2 fade-in-up ${card.glow}`}
          style={{ animationDelay: `${i * 0.07}s` }}
        >
          <div className="flex items-center justify-between">
            <span className="text-xl">{card.icon}</span>
            <div
              className="w-2 h-2 rounded-full animate-pulse"
              style={{ background: card.color }}
            />
          </div>
          <div>
            <div className="flex items-baseline gap-1">
              <span
                className="text-2xl font-bold tracking-tight"
                style={{ color: card.color }}
              >
                {card.value}
              </span>
              {card.unit && (
                <span className="text-xs text-slate-400 font-medium">{card.unit}</span>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-0.5 leading-tight">{card.sub}</p>
          </div>
          <p className="text-xs font-semibold text-slate-300 truncate">{card.label}</p>
        </div>
      ))}
    </div>
  );
}
