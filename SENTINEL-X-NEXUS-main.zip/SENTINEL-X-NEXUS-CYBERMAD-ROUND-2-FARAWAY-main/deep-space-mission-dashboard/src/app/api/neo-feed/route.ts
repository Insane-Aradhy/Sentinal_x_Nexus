import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

interface NeoObject {
  id: string;
  name: string;
  estimated_diameter: {
    kilometers: {
      estimated_diameter_min: number;
      estimated_diameter_max: number;
    };
  };
  is_potentially_hazardous_asteroid: boolean;
  close_approach_data: Array<{
    close_approach_date: string;
    relative_velocity: {
      kilometers_per_hour: string;
    };
    miss_distance: {
      kilometers: string;
      lunar: string;
    };
  }>;
}

interface NeoFeedResponse {
  element_count: number;
  near_earth_objects: {
    [date: string]: NeoObject[];
  };
}

export async function GET(request: NextRequest) {
  try {
    const apiKey = process.env.NASA_API_KEY || 'DEMO_KEY';
    // Get today and 7 days from now for the feed window
    const today = new Date();
    const endDate = new Date();
    endDate.setDate(today.getDate() + 7);

    const startDateStr = today.toISOString().split('T')[0];
    const endDateStr = endDate.toISOString().split('T')[0];

    const url = `https://api.nasa.gov/neo/rest/v1/feed?start_date=${startDateStr}&end_date=${endDateStr}&api_key=${apiKey}`;

    const response = await fetch(url, {
      next: { revalidate: 300 }, // Cache for 5 minutes
    });

    if (!response.ok) {
      if (response.status === 429) {
        return NextResponse.json(
          { error: 'Rate limit exceeded. Please try again later.' },
          { status: 429 }
        );
      }
      throw new Error(`NASA API error: ${response.status}`);
    }

    const data: NeoFeedResponse = await response.json();

    // Transform the data for easier consumption
    const asteroids: Array<{
      id: string;
      name: string;
      diameterMin: number;
      diameterMax: number;
      isHazardous: boolean;
      approachDate: string;
      velocity: number;
      missDistanceKm: number;
      missDistanceLunar: number;
    }> = [];

    // Flatten the date-grouped objects
    Object.values(data.near_earth_objects).forEach(dateGroup => {
      dateGroup.forEach(neo => {
        if (neo.close_approach_data.length > 0) {
          const approach = neo.close_approach_data[0];
          asteroids.push({
            id: neo.id,
            name: neo.name.replace(/[()]/g, ''),
            diameterMin: neo.estimated_diameter.kilometers.estimated_diameter_min,
            diameterMax: neo.estimated_diameter.kilometers.estimated_diameter_max,
            isHazardous: neo.is_potentially_hazardous_asteroid,
            approachDate: approach.close_approach_date,
            velocity: parseFloat(approach.relative_velocity.kilometers_per_hour),
            missDistanceKm: parseFloat(approach.miss_distance.kilometers),
            missDistanceLunar: parseFloat(approach.miss_distance.lunar),
          });
        }
      });
    });

    // Sort by closest approach (miss distance)
    asteroids.sort((a, b) => a.missDistanceKm - b.missDistanceKm);

    // Return top 15 closest asteroids
    return NextResponse.json({
      success: true,
      count: asteroids.length,
      asteroids: asteroids.slice(0, 15),
    });

  } catch (error) {
    console.error('Error fetching NEO data:', error);
    return NextResponse.json(
      { 
        error: 'Failed to fetch asteroid data',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}
