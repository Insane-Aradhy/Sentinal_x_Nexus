import LoadingScreen from '@/components/LoadingScreen';
import MissionHUD from '@/components/MissionHUD';
import JudgeAssistDropdown from '@/components/JudgeAssist/JudgeAssistDropdown';

export const dynamic = 'force-dynamic';

export default function HomePage() {
  return (
    <div className="relative w-screen h-screen overflow-hidden">
      {/* Loading Screen - Shows for 3 seconds */}
      <LoadingScreen />

      {/* Layer 0: NASA Eyes on the Solar System - Full Background */}
      <div id="nasa-eyes-container" className="absolute inset-0 w-full h-full bg-[url('https://images.unsplash.com/photo-1462331940025-496dfbfc7564?q=80&w=2048&auto=format&fit=crop')] bg-cover bg-center" style={{ zIndex: 0 }}>
        <iframe
          src="https://eyes.nasa.gov/apps/solar-system/"
          className="w-full h-full border-0"
          title="NASA Eyes on the Solar System"
          allowFullScreen
          style={{
            width: '100vw',
            height: '100vh',
            border: 'none',
          }}
        />
      </div>

      {/* Top Center Judge Assist Trigger & Dropdown Modal */}
      <JudgeAssistDropdown />

      {/* Layer 10: Mission Control HUD Overlay */}
      <MissionHUD />
    </div>
  );
}

