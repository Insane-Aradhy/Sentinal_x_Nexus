'use client';

import { useEffect, useState } from 'react';

interface Asteroid {
  id: string;
  name: string;
  diameterMin: number;
  diameterMax: number;
  isHazardous: boolean;
  approachDate: string;
  velocity: number;
  missDistanceKm: number;
  missDistanceLunar: number;
}

interface NeoData {
  success: boolean;
  count: number;
  asteroids: Asteroid[];
}

export default function MissionHUD() {
  const [neoData, setNeoData] = useState<NeoData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const [activeAlert, setActiveAlert] = useState<{title: string, message: string} | null>(null);

  const fetchNeoData = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await fetch('/api/neo-feed');
      
      if (!response.ok) {
        throw new Error('Failed to fetch asteroid data');
      }
      
      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error);
      }
      
      setNeoData(data);
      setLastUpdate(new Date());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNeoData();
    
    // Refresh every 30 seconds
    const interval = setInterval(fetchNeoData, 30000);
    
    return () => clearInterval(interval);
  }, []);

  const formatNumber = (num: number): string => {
    return new Intl.NumberFormat('en-US', {
      maximumFractionDigits: 2,
    }).format(num);
  };

  const formatDate = (dateStr: string): string => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const getThreatLevel = (missDistanceLunar: number): { level: string; color: string } => {
    if (missDistanceLunar < 1) return { level: 'CRITICAL', color: 'text-red-500' };
    if (missDistanceLunar < 5) return { level: 'HIGH', color: 'text-orange-500' };
    if (missDistanceLunar < 10) return { level: 'MODERATE', color: 'text-yellow-500' };
    return { level: 'LOW', color: 'text-green-500' };
  };

  const hazardousCount = neoData?.asteroids.filter(a => a.isHazardous).length || 0;

  return (
    <div className="fixed inset-0 z-10 pointer-events-none">
      {/* Reduced Threat Alert Trigger Button - Now Top Left */}
      <div className="absolute top-6 left-6 pointer-events-auto">
        <button
          id="neo-trigger-btn"
          onClick={() => setIsPanelOpen(true)}
          className={`flex items-center gap-3 px-4 py-3 rounded-xl glass-panel transition-all hover:scale-105 active:scale-95 group border-cyan-500/30 ${isPanelOpen ? 'opacity-0 scale-90 pointer-events-none' : 'opacity-100'}`}
        >
          <div className="relative">
            <div className={`w-3 h-3 ${hazardousCount > 0 ? 'bg-red-500 pulse-glow' : 'bg-green-400'} rounded-full`} />
            {hazardousCount > 0 && <div className="absolute inset-0 w-3 h-3 bg-red-400 rounded-full animate-ping opacity-40" />}
          </div>
          <span className="text-[11px] font-black text-cyan-400 text-shadow uppercase tracking-widest">
            NEO STATUS: <span className={hazardousCount > 0 ? 'text-red-400' : 'text-green-400'}>
              {hazardousCount > 0 ? 'THREAT DETECTED' : 'NOMINAL'}
            </span>
          </span>
          <div className={`${hazardousCount > 0 ? 'bg-red-500' : 'bg-cyan-500'} text-white text-[9px] font-bold px-2 py-0.5 rounded-full min-w-[18px] text-center`}>
            {hazardousCount}
          </div>
        </button>
      </div>

      {/* Compact Side Pop-up - Now Top Left */}
      <div 
        id="neo-panel"
        className={`absolute top-6 left-6 w-80 pointer-events-auto transition-all duration-500 ease-in-out transform origin-top-left ${
          isPanelOpen ? 'scale-100 opacity-100' : 'scale-90 opacity-0 pointer-events-none'
        }`}
      >
        <div className={`${hazardousCount > 0 ? 'glass-panel-warning border-red-500/50' : 'glass-panel border-cyan-500/50'} rounded-xl flex flex-col max-h-[85vh] overflow-hidden shadow-2xl`}>
          {/* Compact Header (No Main Heading) */}
          <div className="p-3 border-b border-white/10 flex items-center justify-between bg-black/20">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 ${hazardousCount > 0 ? 'bg-red-500 animate-pulse' : 'bg-cyan-400'} rounded-full`} />
              <span className="text-[10px] font-black text-white/70 uppercase tracking-widest">Live Telemetry</span>
            </div>
            <button 
              onClick={() => setIsPanelOpen(false)}
              className="p-1.5 hover:bg-white/10 rounded-lg transition-colors group"
            >
              <svg className="w-4 h-4 text-white/50 group-hover:text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* Content Area */}
          <div id="asteroid-list-container" className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-3">
            {loading && !neoData && (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <div className="w-12 h-12 border-4 border-red-500/20 border-t-red-500 rounded-full animate-spin mx-auto" />
                  <p className="text-red-300/60 text-xs font-bold mt-4 tracking-tighter uppercase">Interrogating NASA Telemetry...</p>
                </div>
              </div>
            )}

            {error && (
              <div className="bg-red-900/40 border border-red-500/50 rounded-xl p-4">
                <p className="text-red-400 text-sm font-black uppercase">⚠ System Failure</p>
                <p className="text-red-200/80 text-xs mt-2 font-mono">{error}</p>
                <button onClick={fetchNeoData} className="mt-4 text-[10px] font-bold uppercase text-red-400 hover:text-red-300">Retry Fetch</button>
              </div>
            )}

            {neoData && (
              <>
                {/* Stats Summary Panel */}
                <div id="neo-stats-summary" className="grid grid-cols-2 gap-2">
                  <div className="bg-slate-900/50 border border-white/10 rounded-lg p-2.5">
                    <p className="text-[8px] text-blue-300/60 uppercase font-black tracking-widest">Tracked</p>
                    <p className="text-xl font-black text-white">{neoData.count}</p>
                  </div>
                  <div className={`${hazardousCount > 0 ? 'bg-red-950/40 border-red-500/30' : 'bg-slate-900/50 border-white/10'} rounded-lg p-2.5`}>
                    <p className="text-[8px] text-red-400 uppercase font-black tracking-widest">Hazard</p>
                    <p className={`text-xl font-black ${hazardousCount > 0 ? 'text-red-500' : 'text-white'}`}>{hazardousCount}</p>
                  </div>
                </div>

                <div className="h-px bg-white/5 my-1" />

                {/* Asteroid List */}
                {neoData.asteroids.map((asteroid) => {
                  const threat = getThreatLevel(asteroid.missDistanceLunar);
                  const isCritical = asteroid.isHazardous || asteroid.missDistanceLunar < 2;
                  
                  return (
                    <div
                      key={asteroid.id}
                      onDoubleClick={() => {
                        const target = document.getElementById('nasa-eyes-container');
                        if (target) {
                          setIsPanelOpen(false);
                          setActiveAlert({
                            title: `DSN UPLINK SECURED: ${asteroid.name}`,
                            message: 'NASA JPL Mainframe protocols restrict external camera control. Initiate manual override: Click the Search icon (🔍) in the top right of the 3D viewport and input the asteroid designation.'
                          });
                          setTimeout(() => setActiveAlert(null), 12000);
                        }
                      }}
                      className={`relative transition-all hover:bg-white/10 border rounded-lg p-3 cursor-pointer active:scale-95 ${
                        isCritical 
                          ? 'bg-red-950/20 border-red-500/30 hover:border-red-400' 
                          : 'bg-black/20 border-white/5 hover:border-cyan-400'
                      }`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div className="max-w-[65%]">
                          <h3 className="text-[11px] font-black text-white uppercase truncate">
                            {asteroid.name}
                          </h3>
                        </div>
                        <div className={`text-[9px] font-black uppercase ${threat.color}`}>
                          {threat.level}
                        </div>
                      </div>

                      <div className="flex justify-between items-end">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[8px] text-white/40 uppercase font-bold">Dist</span>
                            <span className="text-[11px] font-mono text-cyan-400 font-bold">{formatNumber(asteroid.missDistanceLunar)} LD</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-[8px] text-white/40 uppercase font-bold">Velo</span>
                            <span className="text-[11px] font-mono text-blue-300">{formatNumber(asteroid.velocity / 1000)}k <span className="text-[7px]">KM/H</span></span>
                          </div>
                        </div>
                        <div className="text-right">
                           <span className="text-[8px] text-white/40 uppercase block mb-0.5">Date</span>
                           <span className="text-[9px] font-mono text-white/80">{asteroid.approachDate.split('-').slice(1).join('/')}</span>
                        </div>
                      </div>

                      {/* Small Indicator Bar */}
                      <div className="mt-2 h-0.5 bg-white/5 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${isCritical ? 'bg-red-500' : 'bg-cyan-500'}`}
                          style={{ width: `${Math.min((10 / Math.max(asteroid.missDistanceLunar, 0.1)) * 10, 100)}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </>
            )}
          </div>
          
          {/* Footer Controls */}
          <button 
            id="neo-collapse-btn"
            onClick={() => setIsPanelOpen(false)}
            className="p-3 bg-white/5 border-t border-white/10 text-[9px] font-black uppercase tracking-widest text-white/40 hover:text-white hover:bg-white/10 transition-all"
          >
            Collapse Telemetry
          </button>
        </div>
      </div>

      {/* Immersive HUD Toast Notification */}
      {activeAlert && (
        <div className="absolute top-6 right-6 pointer-events-auto z-50 animate-in fade-in slide-in-from-right-4 duration-300">
          <div className="bg-black/80 backdrop-blur-md border border-cyan-500/50 rounded-xl p-4 shadow-[0_0_20px_rgba(6,182,212,0.3)] max-w-sm">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
              <h4 className="text-cyan-400 text-xs font-black uppercase tracking-widest">{activeAlert.title}</h4>
            </div>
            <p className="text-cyan-100/80 text-[11px] font-mono leading-relaxed">
              {activeAlert.message}
            </p>
          </div>
        </div>
      )}

    </div>
  );
}


