export interface TourStep {
  title: string;
  desc: string;
  arrow: 'up' | 'down' | 'left' | 'right' | 'none';
  position: {
    top?: string;
    bottom?: string;
    left?: string;
    right?: string;
  };
  targetId?: string;
  requireClickId?: string;
  actionHint?: string;
}

export interface TourPackage {
  id: string;
  name: string;
  badge?: string;
  icon?: string;
  description?: string;
  steps: TourStep[];
}

export const TOUR_PACKAGES: Record<string, TourPackage> = {
  full: {
    id: 'full',
    name: 'Full Mission Control Walkthrough',
    badge: 'RECOMMENDED',
    icon: '🚀',
    description: 'Complete step-by-step tour of all deep space dashboard capabilities and NASA feeds',
    steps: [
      {
        title: 'STEP 1: NASA Eyes on the Solar System (1/5)',
        desc: 'This is the core planetary physics engine powered by NASA JPL! It renders live celestial bodies, orbits, and trajectories across the solar system in true 3D. \n\n🔭 TRUSTED & VITAL: Space agencies rely on these exact orbital mechanics to calculate intercept vectors, launch windows, and threat mitigation strategies. Having this engine running natively in the browser is what gives this dashboard unprecedented simulation accuracy.\n\n👇 YOUR TURN (PLEASE TRY THIS):\n1️⃣ Hover over the solar system and click and drag to rotate the camera.\n2️⃣ Double-click on any planet or asteroid (like Earth or Mars) to fly to it and get real-time planetary data!\n3️⃣ Look at the bottom of the viewport for the TIME CONTROLS. You can speed up time, reverse it, or jump to a specific date to predict future orbital alignments!',
        arrow: 'down',
        position: { top: '15%', left: '50%' },
        targetId: 'nasa-eyes-container'
      },
      {
        title: 'STEP 2: Live NEO Status Trigger (2/5)',
        desc: '🚨 MISSION CRITICAL ALARM: This is the Near Earth Object (NEO) threat status trigger! It constantly listens to the NASA NeoWs (Near Earth Object Web Service) REST API to monitor hazardous asteroids in real-time.\n\n🛡️ PLANETARY DEFENSE: If a massive asteroid crosses a critical distance threshold, this button instantly pulses RED to alert commanders. It\'s the first line of defense!\n\n👇 YOUR TURN (PLEASE TRY THIS):\n1️⃣ Click the pulsing \'NEO STATUS\' button below to deploy the full telemetry readout panel and inspect the active threats.',
        arrow: 'left',
        position: { top: '80px', left: '320px' },
        targetId: 'neo-trigger-btn',
        requireClickId: 'neo-trigger-btn',
        actionHint: 'Click NEO STATUS to open live telemetry'
      },
      {
        title: 'STEP 3: Telemetry Radar & Summary (3/5)',
        desc: '📊 TACTICAL DASHBOARD: The telemetry summary gives commanders a split-second overview of the celestial battlefield! It aggregates the total number of tracked bodies and isolates the ones flagged as \'Potentially Hazardous Asteroids\' (PHAs) by NASA.\n\n⚡ WHY IT MATTERS: In a high-stakes scenario, you don\'t have time to read raw JSON data. This summarizes massive datasets into an instant threat assessment.\n\n👇 YOUR TURN:\n1️⃣ Look at the \'HAZARDOUS\' count. If it\'s greater than 0, planetary defense protocols must be initiated immediately!',
        arrow: 'left',
        position: { top: '140px', left: '380px' },
        targetId: 'neo-stats-summary'
      },
      {
        title: 'STEP 4: Asteroid Threat Classification (4/5)',
        desc: '☄️ THREAT TRAJECTORY ANALYSIS: This is where the magic happens! For every asteroid, the engine calculates its exact miss distance in Lunar Distances (LD) and relative approach velocity in kilometers per hour.\n\n🔴 AUTOMATED TRIAGE: The system automatically color-codes threats. Asteroids coming closer than 2 LD turn warning-red so commanders can focus their attention immediately on the most imminent dangers.\n\n👇 YOUR TURN:\n1️⃣ Scroll through the active asteroid list. Notice how the speed (often 50,000+ km/h) and distance are dynamically formatted for instant readability!',
        arrow: 'left',
        position: { top: '240px', left: '380px' },
        targetId: 'asteroid-list-container'
      },
      {
        title: 'STEP 5: Real-Time Telemetry Controls (5/5)',
        desc: '🔄 ZERO-LATENCY AUTO-SYNC: Deep space missions can\'t afford stale data! This module features a fault-tolerant background polling engine that seamlessly pulls fresh orbital data from NASA every 30 seconds—with absolutely zero page reloads.\n\n🛠️ UX EXCELLENCE: We built this with glassmorphism overlays so you never lose sight of the 3D physics viewport behind the data.\n\n👇 YOUR TURN:\n1️⃣ Click the \'COLLAPSE\' button to stow the telemetry panel and return to full viewport operations. The tour is complete!',
        arrow: 'left',
        position: { top: '480px', left: '380px' },
        targetId: 'neo-collapse-btn'
      }
    ]
  },
  neo: {
    id: 'neo',
    name: 'NEO Asteroid Tracker Feature',
    icon: '☄️',
    description: 'Focused tour on NASA Near-Earth Object live telemetry and hazard analysis',
    steps: [
      {
        title: 'STEP 1: Threat Radar Status (1/3)',
        desc: '🚨 MISSION CRITICAL ALARM: This is the Near Earth Object (NEO) threat status trigger! It constantly listens to the NASA NeoWs (Near Earth Object Web Service) REST API to monitor hazardous asteroids in real-time.\n\n🛡️ PLANETARY DEFENSE: If a massive asteroid crosses a critical distance threshold, this button instantly pulses RED to alert commanders. It\'s the first line of defense!\n\n👇 YOUR TURN (PLEASE TRY THIS):\n1️⃣ Click the pulsing \'NEO STATUS\' button below to deploy the full telemetry readout panel and inspect the active threats.',
        arrow: 'down',
        position: { top: '70px', left: '200px' },
        targetId: 'neo-trigger-btn',
        requireClickId: 'neo-trigger-btn',
        actionHint: 'Click to open the telemetry panel'
      },
      {
        title: 'STEP 2: Real-time Lunar Proximity & Hazard Metric (2/3)',
        desc: '☄️ THREAT TRAJECTORY ANALYSIS: This is where the magic happens! For every asteroid, the engine calculates its exact miss distance in Lunar Distances (LD) and relative approach velocity in kilometers per hour.\n\n🔴 AUTOMATED TRIAGE: The system automatically color-codes threats. Asteroids coming closer than 2 LD turn warning-red so commanders can focus their attention immediately on the most imminent dangers.\n\n👇 YOUR TURN:\n1️⃣ Scroll through the active asteroid list. Notice how the speed (often 50,000+ km/h) and distance are dynamically formatted for instant readability!',
        arrow: 'left',
        position: { top: '200px', left: '380px' },
        targetId: 'asteroid-list-container'
      },
      {
        title: 'STEP 3: Automated NASA Sync & Collapse (3/3)',
        desc: '🔄 ZERO-LATENCY AUTO-SYNC: Deep space missions can\'t afford stale data! This module features a fault-tolerant background polling engine that seamlessly pulls fresh orbital data from NASA every 30 seconds—with absolutely zero page reloads.\n\n🛠️ UX EXCELLENCE: We built this with glassmorphism overlays so you never lose sight of the 3D physics viewport behind the data.\n\n👇 YOUR TURN:\n1️⃣ Click the \'COLLAPSE\' button to stow the telemetry panel and return to full viewport operations. The tour is complete!',
        arrow: 'left',
        position: { top: '420px', left: '380px' },
        targetId: 'neo-collapse-btn'
      }
    ]
  },
  preferences: {
    id: 'preferences',
    name: 'Mission Control & Solar System Core',
    icon: '⚖️',
    description: 'Tour of planetary physics viewport and deep space mission layout',
    steps: [
      {
        title: 'STEP 1: Interactive Celestial Viewport (1/2)',
        desc: 'This is the core planetary physics engine powered by NASA JPL! It renders live celestial bodies, orbits, and trajectories across the solar system in true 3D.\n\n🔭 TRUSTED & VITAL: Space agencies rely on these exact orbital mechanics to calculate intercept vectors, launch windows, and threat mitigation strategies. Having this engine running natively in the browser is what gives this dashboard unprecedented simulation accuracy.\n\n👇 YOUR TURN (PLEASE TRY THIS):\n1️⃣ Hover over the solar system and click and drag to rotate the camera.\n2️⃣ Double-click on any planet or asteroid (like Earth or Mars) to fly to it and get real-time planetary data!\n3️⃣ Look at the bottom of the viewport for the TIME CONTROLS. You can speed up time, reverse it, or jump to a specific date to predict future orbital alignments!',
        arrow: 'down',
        position: { top: '20%', left: '50%' },
        targetId: 'nasa-eyes-container'
      },
      {
        title: 'STEP 2: HUD Overlay & Telemetry Dock (2/2)',
        desc: '🚨 MISSION CRITICAL ALARM: This is the Near Earth Object (NEO) threat status trigger! It constantly listens to the NASA NeoWs (Near Earth Object Web Service) REST API to monitor hazardous asteroids in real-time.\n\n🛡️ PLANETARY DEFENSE: If a massive asteroid crosses a critical distance threshold, this button instantly pulses RED to alert commanders. It\'s the first line of defense!\n\n👇 YOUR TURN (PLEASE TRY THIS):\n1️⃣ Click the pulsing \'NEO STATUS\' button below to deploy the full telemetry readout panel and inspect the active threats.',
        arrow: 'left',
        position: { top: '70px', left: '260px' },
        targetId: 'neo-trigger-btn'
      }
    ]
  }
};

export const SPECIFIC_DIVISIONS = [
  {
    id: 'div_01',
    label: '01 3D Solar System Viewport',
    step: {
      title: 'DIVISION 01: 3D Solar System Viewport (1/1)',
      desc: 'This is the core planetary physics engine powered by NASA JPL! It renders live celestial bodies, orbits, and trajectories across the solar system in true 3D.\n\n🔭 TRUSTED & VITAL: Space agencies rely on these exact orbital mechanics to calculate intercept vectors, launch windows, and threat mitigation strategies. Having this engine running natively in the browser is what gives this dashboard unprecedented simulation accuracy.\n\n👇 YOUR TURN (PLEASE TRY THIS):\n1️⃣ Hover over the solar system and click and drag to rotate the camera.\n2️⃣ Double-click on any planet or asteroid (like Earth or Mars) to fly to it and get real-time planetary data!\n3️⃣ Look at the bottom of the viewport for the TIME CONTROLS. You can speed up time, reverse it, or jump to a specific date to predict future orbital alignments!',
      arrow: 'down' as const,
      position: { top: '20%', left: '50%' },
      targetId: 'nasa-eyes-container'
    }
  },
  {
    id: 'div_02',
    label: '02 Live Asteroid Threat Status',
    step: {
      title: 'DIVISION 02: Threat Status Trigger (1/1)',
      desc: '🚨 MISSION CRITICAL ALARM: This is the Near Earth Object (NEO) threat status trigger! It constantly listens to the NASA NeoWs (Near Earth Object Web Service) REST API to monitor hazardous asteroids in real-time.\n\n🛡️ PLANETARY DEFENSE: If a massive asteroid crosses a critical distance threshold, this button instantly pulses RED to alert commanders. It\'s the first line of defense!\n\n👇 YOUR TURN (PLEASE TRY THIS):\n1️⃣ Click the pulsing \'NEO STATUS\' button below to deploy the full telemetry readout panel and inspect the active threats.',
      arrow: 'left' as const,
      position: { top: '80px', left: '320px' },
      targetId: 'neo-trigger-btn',
      requireClickId: 'neo-trigger-btn',
      actionHint: 'Click to expand the telemetry readout'
    }
  },
  {
    id: 'div_03',
    label: '03 Telemetry & Stats Summary',
    step: {
      title: 'DIVISION 03: Telemetry Stats Summary (1/1)',
      desc: '📊 TACTICAL DASHBOARD: The telemetry summary gives commanders a split-second overview of the celestial battlefield! It aggregates the total number of tracked bodies and isolates the ones flagged as \'Potentially Hazardous Asteroids\' (PHAs) by NASA.\n\n⚡ WHY IT MATTERS: In a high-stakes scenario, you don\'t have time to read raw JSON data. This summarizes massive datasets into an instant threat assessment.\n\n👇 YOUR TURN:\n1️⃣ Look at the \'HAZARDOUS\' count. If it\'s greater than 0, planetary defense protocols must be initiated immediately!',
      arrow: 'left' as const,
      position: { top: '150px', left: '380px' },
      targetId: 'neo-stats-summary'
    }
  },
  {
    id: 'div_04',
    label: '04 Hazard Classification & Lunar Distance',
    step: {
      title: 'DIVISION 04: Hazard Classification (1/1)',
      desc: '☄️ THREAT TRAJECTORY ANALYSIS: This is where the magic happens! For every asteroid, the engine calculates its exact miss distance in Lunar Distances (LD) and relative approach velocity in kilometers per hour.\n\n🔴 AUTOMATED TRIAGE: The system automatically color-codes threats. Asteroids coming closer than 2 LD turn warning-red so commanders can focus their attention immediately on the most imminent dangers.\n\n👇 YOUR TURN:\n1️⃣ Scroll through the active asteroid list. Notice how the speed (often 50,000+ km/h) and distance are dynamically formatted for instant readability!',
      arrow: 'left' as const,
      position: { top: '250px', left: '380px' },
      targetId: 'asteroid-list-container'
    }
  },
  {
    id: 'div_05',
    label: '05 Real-time NASA API Sync',
    step: {
      title: 'DIVISION 05: NASA NeoWs API Auto-Sync (1/1)',
      desc: '🔄 ZERO-LATENCY AUTO-SYNC: Deep space missions can\'t afford stale data! This module features a fault-tolerant background polling engine that seamlessly pulls fresh orbital data from NASA every 30 seconds—with absolutely zero page reloads.\n\n🛠️ UX EXCELLENCE: We built this with glassmorphism overlays so you never lose sight of the 3D physics viewport behind the data.\n\n👇 YOUR TURN:\n1️⃣ Click the \'COLLAPSE\' button to stow the telemetry panel and return to full viewport operations. The tour is complete!',
      arrow: 'left' as const,
      position: { top: '450px', left: '380px' },
      targetId: 'neo-collapse-btn'
    }
  }
];
