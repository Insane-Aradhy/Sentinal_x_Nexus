'use client';

import { useEffect, useState } from 'react';

export default function LoadingScreen() {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    // Show loading screen for 3 seconds
    const timer = setTimeout(() => {
      setIsVisible(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  if (!isVisible) return null;

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center bg-black ${!isVisible ? 'fade-out' : ''}`}>
      {/* Scan line effect */}
      <div className="scan-line absolute left-0 w-full h-px bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-30" />
      
      {/* Central loading animation */}
      <div className="relative flex flex-col items-center">
        {/* Orbital rings */}
        <div className="relative w-48 h-48">
          {/* Outer ring */}
          <div className="absolute inset-0 rounded-full border border-blue-500/30" />
          
          {/* Middle ring with orbit animation */}
          <div className="absolute inset-4 rounded-full border border-cyan-500/40">
            <div className="orbit-ring absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-cyan-400 rounded-full pulse-glow" />
          </div>
          
          {/* Inner ring */}
          <div className="absolute inset-8 rounded-full border border-blue-400/50" />
          
          {/* Core */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-full pulse-glow shadow-[0_0_40px_rgba(34,211,238,0.6)]" />
        </div>

        {/* Loading text */}
        <div className="mt-12 text-center">
          <h2 className="text-2xl font-bold text-cyan-400 neon-text tracking-wider uppercase">
            Mission Control
          </h2>
          <p className="mt-3 text-sm text-blue-300/80 tracking-widest uppercase">
            Initializing Deep Space Telemetry
          </p>
          <div className="mt-4 flex gap-1.5 justify-center">
            <div className="w-2 h-2 bg-cyan-400 rounded-full pulse-glow" style={{ animationDelay: '0s' }} />
            <div className="w-2 h-2 bg-cyan-400 rounded-full pulse-glow" style={{ animationDelay: '0.2s' }} />
            <div className="w-2 h-2 bg-cyan-400 rounded-full pulse-glow" style={{ animationDelay: '0.4s' }} />
          </div>
        </div>
      </div>

      {/* Grid overlay */}
      <div className="absolute inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(rgba(59, 130, 246, 0.3) 1px, transparent 1px),
            linear-gradient(90deg, rgba(59, 130, 246, 0.3) 1px, transparent 1px)
          `,
          backgroundSize: '50px 50px'
        }}
      />
    </div>
  );
}
